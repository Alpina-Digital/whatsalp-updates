<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Install\Schema as DbSchema;
use WhatsAlp\Integrations\AbstractIntegration;
use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Integrations\Pipedrive\PipedriveIntegration;
use WhatsAlp\Integrations\Webhook\WebhookIntegration;
use WhatsAlp\Settings\Schema;
use WhatsAlp\Support\Logger;

final class IntegrationsPage {

	public const ACTION = 'whatsalp_save_integration';

	public function register(): void {
		add_action( 'admin_post_' . self::ACTION, [ $this, 'save' ] );
	}

	public function save(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'whatsalp' ), 403 );
		}
		check_admin_referer( self::ACTION );
		$id          = isset( $_POST['integration'] ) ? sanitize_key( wp_unslash( $_POST['integration'] ) ) : '';
		$integration = IntegrationRegistry::get( $id );
		if ( $integration instanceof AbstractIntegration && ! $integration->is_internal() ) {
			$input = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$integration->save_from_input( $input );
			$plain = null;
			if ( $integration instanceof WebhookIntegration ) {
				if ( ! empty( $_POST['rotate_secret'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$integration->forget_secret();
				}
				$plain = $integration->ensure_secret();
				if ( $plain ) {
					set_transient( 'whatsalp_webhook_secret_' . get_current_user_id(), \WhatsAlp\Security\Crypto::encrypt( $plain ), 120 );
				}
			}
			IntegrationRegistry::flush();
		}
		$args = [ 'page' => Menu::SLUG_INTEGRATIONS, 'integration' => $id, 'saved' => 1 ];
		if ( $integration instanceof WebhookIntegration && ! empty( $input['url'] ) && '' === (string) $integration->setting( 'url' ) ) {
			$args['error'] = 'url';
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	public function render(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			return;
		}
		$selected = isset( $_GET['integration'] ) ? sanitize_key( wp_unslash( $_GET['integration'] ) ) : 'pipedrive'; // phpcs:ignore WordPress.Security.NonceVerification
		$current  = IntegrationRegistry::get( $selected );
		if ( ! $current instanceof AbstractIntegration || $current->is_internal() ) {
			$current = IntegrationRegistry::get( 'pipedrive' );
		}
		?>
		<div class="wrap whatsalp-wrap">
			<?php Menu::header( Menu::SLUG_INTEGRATIONS ); ?>
			<?php if ( ! empty( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Integração salva.', 'whatsalp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['error'] ) && 'url' === $_GET['error'] ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'A URL do webhook é inválida e não foi salva. Use um endereço público começando com https://.', 'whatsalp' ); ?></p></div>
			<?php endif; ?>
			<?php
			$secret = get_transient( 'whatsalp_webhook_secret_' . get_current_user_id() );
			$secret = is_string( $secret ) ? \WhatsAlp\Security\Crypto::decrypt( $secret ) : null;
			if ( $secret ) :
				delete_transient( 'whatsalp_webhook_secret_' . get_current_user_id() );
				?>
				<div class="notice notice-warning"><p><strong><?php esc_html_e( 'Segredo do webhook (exibido uma única vez):', 'whatsalp' ); ?></strong> <code><?php echo esc_html( $secret ); ?></code></p></div>
			<?php endif; ?>

			<div class="whatsalp-cards">
				<?php foreach ( IntegrationRegistry::all() as $integration ) : ?>
					<?php
					if ( $integration->is_internal() ) {
						continue; }
					?>
					<?php $this->card( $integration, $current && $current->id() === $integration->id() ); ?>
				<?php endforeach; ?>
				<?php $this->soon_card( 'RD Station', __( 'Conversões no RD Station Marketing com identificador configurável.', 'whatsalp' ) ); ?>
				<?php $this->soon_card( 'HubSpot', __( 'Cria contatos no HubSpot CRM com origem e UTMs.', 'whatsalp' ) ); ?>
			</div>

			<?php
			if ( $current instanceof AbstractIntegration ) {
				$this->config_form( $current ); }
			?>

			<?php $this->log_table(); ?>
		</div>
		<?php
	}

	private function card( \WhatsAlp\Integrations\IntegrationInterface $integration, bool $active ): void {
		$badge = __( 'Não configurado', 'whatsalp' );
		$class = 'is-off';
		if ( $integration instanceof AbstractIntegration && $integration->auth_failed() ) {
			$badge = __( 'Credenciais inválidas', 'whatsalp' );
			$class = 'is-error';
		} elseif ( $integration->is_enabled() && $integration->is_configured() ) {
			$badge = __( 'Conectado', 'whatsalp' );
			$class = 'is-on';
		} elseif ( $integration->is_configured() ) {
			$badge = __( 'Desligado', 'whatsalp' );
		}
		?>
		<article class="whatsalp-card whatsalp-integration <?php echo $active ? 'is-active' : ''; ?>">
			<header>
				<span class="whatsalp-int-icon whatsalp-int-icon--<?php echo esc_attr( $integration->id() ); ?>" aria-hidden="true"><?php echo esc_html( mb_substr( $integration->label(), 0, 1 ) ); ?></span>
				<strong><?php echo esc_html( $integration->label() ); ?></strong>
				<span class="whatsalp-badge <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $badge ); ?></span>
			</header>
			<p class="description"><?php echo esc_html( $this->description( $integration->id() ) ); ?></p>
			<footer>
				<a class="button button-primary" href="<?php echo esc_url( add_query_arg( [ 'page' => Menu::SLUG_INTEGRATIONS, 'integration' => $integration->id() ], admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Configurar', 'whatsalp' ); ?></a>
				<?php if ( $integration->is_configured() ) : ?>
					<button type="button" class="button whatsalp-test" data-integration="<?php echo esc_attr( $integration->id() ); ?>"><?php esc_html_e( 'Testar conexão', 'whatsalp' ); ?></button>
				<?php endif; ?>
				<span class="whatsalp-test-result" aria-live="polite"></span>
			</footer>
		</article>
		<?php
	}

	private function soon_card( string $label, string $description ): void {
		?>
		<article class="whatsalp-card whatsalp-integration is-soon">
			<header><span class="whatsalp-int-icon" aria-hidden="true"><?php echo esc_html( mb_substr( $label, 0, 2 ) ); ?></span><strong><?php echo esc_html( $label ); ?></strong><span class="whatsalp-badge is-off"><?php esc_html_e( 'Em breve', 'whatsalp' ); ?></span></header>
			<p class="description"><?php echo esc_html( $description ); ?></p>
			<footer><button type="button" class="button" disabled><?php esc_html_e( 'Conectar', 'whatsalp' ); ?></button></footer>
		</article>
		<?php
	}

	private function description( string $id ): string {
		switch ( $id ) {
			case 'pipedrive':
				return __( 'Cria Pessoa e Lead (ou Negócio) no pipeline escolhido, com nota de origem e UTMs em campos personalizados.', 'whatsalp' );
			case 'webhook':
				return __( 'Envia cada lead em JSON assinado para uma URL. Compatível com Zapier, Make e n8n.', 'whatsalp' );
		}
		return '';
	}

	private function config_form( AbstractIntegration $integration ): void {
		$schema = $integration->settings_schema();
		$vals   = $integration->settings();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="whatsalp-card whatsalp-int-form" data-integration="<?php echo esc_attr( $integration->id() ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<input type="hidden" name="integration" value="<?php echo esc_attr( $integration->id() ); ?>">
			<header class="whatsalp-int-form-head">
				<h2><?php echo esc_html( $integration->label() ); ?></h2>
				<?php // Na primeira configuração o toggle já vem marcado: salvar o token sem ligar o envio é a armadilha mais comum. ?>
				<label class="whatsalp-toggle"><input type="checkbox" name="settings[enabled]" value="1" <?php checked( $integration->is_enabled() || ! $integration->is_configured() ); ?>> <?php esc_html_e( 'Enviar novos leads automaticamente', 'whatsalp' ); ?></label>
			</header>
			<?php if ( $integration->is_configured() && ! $integration->is_enabled() ) : ?>
				<div class="notice notice-warning inline"><p><?php esc_html_e( 'Integração configurada, mas desligada: novos leads NÃO estão sendo enviados. Marque "Enviar novos leads automaticamente" e salve.', 'whatsalp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( $integration->auth_failed() ) : ?>
				<div class="notice notice-error inline"><p><?php esc_html_e( 'As credenciais foram recusadas. Reinsira o token: salvar um token novo ou testar a conexão com sucesso libera os leads em espera.', 'whatsalp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( $integration instanceof PipedriveIntegration && $integration->is_configured() ) : ?>
				<p><button type="button" class="button whatsalp-pd-refresh"><?php esc_html_e( 'Atualizar listas do Pipedrive', 'whatsalp' ); ?></button> <span class="description"><?php esc_html_e( 'Pipelines, etapas, usuários e rótulos. Cache de 1 hora.', 'whatsalp' ); ?></span></p>
			<?php endif; ?>
			<div class="whatsalp-grid-2">
			<?php
			foreach ( $schema as $key => $field ) {
				if ( 'utm' === ( $field['group'] ?? '' ) ) {
					continue; // renderizado na seção de rastreio, abaixo
				}
				$this->field( $integration, (string) $key, $field, $vals );
			}
			?>
			</div>
			<?php if ( $integration instanceof PipedriveIntegration ) : ?>
				<?php $this->utm_section( $integration, $schema, $vals ); ?>
				<p class="description"><?php esc_html_e( 'Mapeamento fixo nesta versão: Nome → Pessoa, Telefone → Pessoa (celular), E-mail → Pessoa (trabalho), página de origem e UTMs → nota anexada ao lead/negócio.', 'whatsalp' ); ?></p>
			<?php endif; ?>
			<?php if ( $integration instanceof WebhookIntegration ) : ?>
				<p class="description"><?php esc_html_e( 'Assinatura: X-WhatsAlp-Signature: t=<unix>,v1=HMAC_SHA256(t + "." + body, segredo). Rejeite t fora de 5 minutos.', 'whatsalp' ); ?></p>
				<label class="whatsalp-toggle"><input type="checkbox" name="rotate_secret" value="1"> <?php esc_html_e( 'Gerar um novo segredo ao salvar (o atual deixa de valer; o novo é exibido uma única vez).', 'whatsalp' ); ?></label>
			<?php endif; ?>
			<p>
				<?php submit_button( __( 'Salvar integração', 'whatsalp' ), 'primary', 'submit', false ); ?>
				<?php if ( $integration->is_configured() ) : ?>
					<button type="button" class="button whatsalp-test" data-integration="<?php echo esc_attr( $integration->id() ); ?>"><?php esc_html_e( 'Testar conexão', 'whatsalp' ); ?></button>
					<span class="whatsalp-test-result" aria-live="polite"></span>
				<?php endif; ?>
			</p>
		</form>
		<?php
	}

	/**
	 * @param array<string,mixed> $field
	 * @param array<string,mixed> $vals
	 */
	private function field( AbstractIntegration $integration, string $key, array $field, array $vals ): void {
		$id        = 'int_' . $key;
		$show_when = $field['show_when'] ?? [];
		$attr_show = $show_when ? ' data-show-when="' . esc_attr( (string) wp_json_encode( $show_when ) ) . '"' : '';
		?>
		<div class="whatsalp-field"<?php echo $attr_show; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( (string) ( $field['label'] ?? $key ) ); ?></label>
			<?php if ( ! empty( $field['secret'] ) ) : ?>
				<input type="password" id="<?php echo esc_attr( $id ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $integration->display_value( $key ) ); ?>" class="regular-text" autocomplete="new-password">
				<?php if ( $integration->secret_unreadable( $key ) ) : ?>
					<p class="description whatsalp-error"><?php esc_html_e( 'O valor salvo não pôde ser decifrado (chaves do site mudaram). Insira novamente.', 'whatsalp' ); ?></p>
				<?php endif; ?>
			<?php elseif ( Schema::TYPE_ENUM === $field['type'] ) : ?>
				<select id="<?php echo esc_attr( $id ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" data-key="<?php echo esc_attr( $key ); ?>">
					<?php foreach ( $field['options'] as $opt ) : ?>
						<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $vals[ $key ], $opt ); ?>><?php echo esc_html( $this->enum_label( $key, $opt ) ); ?></option>
					<?php endforeach; ?>
				</select>
			<?php elseif ( ! empty( $field['options_callback'] ) ) : ?>
				<select id="<?php echo esc_attr( $id ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" class="whatsalp-dynamic" data-source="<?php echo esc_attr( $field['options_callback'] ); ?>" data-value="<?php echo esc_attr( (string) $vals[ $key ] ); ?>">
					<option value="<?php echo esc_attr( (string) $vals[ $key ] ); ?>"><?php echo esc_html( $vals[ $key ] ? (string) $vals[ $key ] : __( '— padrão —', 'whatsalp' ) ); ?></option>
				</select>
			<?php elseif ( Schema::TYPE_BOOL === $field['type'] ) : ?>
				<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $vals[ $key ] ); ?>>
			<?php else : ?>
				<input type="text" id="<?php echo esc_attr( $id ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $vals[ $key ] ); ?>" class="regular-text">
			<?php endif; ?>
			<?php if ( ! empty( $field['help'] ) ) : ?>
				<p class="description"><?php echo esc_html( (string) $field['help'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Rastreio de campanha: um campo personalizado do Pipedrive por parâmetro de UTM.
	 *
	 * @param array<string,mixed> $schema
	 * @param array<string,mixed> $vals
	 */
	private function utm_section( PipedriveIntegration $integration, array $schema, array $vals ): void {
		$mapped = count( array_filter( $integration->utm_mapping(), static fn( $v ) => '' !== $v ) );
		?>
		<details class="whatsalp-utm" <?php echo $mapped ? 'open' : ''; ?>>
			<summary>
				<strong><?php esc_html_e( 'Rastreio de campanha (UTMs)', 'whatsalp' ); ?></strong>
				<?php if ( $mapped ) : ?>
					<span class="whatsalp-badge is-on">
						<?php
						// translators: %d = quantidade de parâmetros mapeados.
						printf( esc_html__( '%d mapeados', 'whatsalp' ), (int) $mapped );
						?>
					</span>
				<?php endif; ?>
			</summary>
			<p class="description"><?php esc_html_e( 'Os UTMs capturados na URL vão para campos personalizados do Pipedrive, que podem ser filtrados e usados em relatório. Sem mapeamento, eles continuam aparecendo apenas na nota.', 'whatsalp' ); ?></p>
			<?php if ( $integration->is_configured() ) : ?>
				<p>
					<button type="button" class="button whatsalp-pd-utm"><?php esc_html_e( 'Criar campos no Pipedrive', 'whatsalp' ); ?></button>
					<span class="whatsalp-pd-utm-result description" aria-live="polite"><?php esc_html_e( 'Cria o que faltar (UTM Source, Medium, Campaign, Term, Content, GCLID, FBCLID) e reaproveita campos de mesmo nome.', 'whatsalp' ); ?></span>
				</p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Informe o token da API e salve a integração para criar ou escolher os campos.', 'whatsalp' ); ?></p>
			<?php endif; ?>
			<div class="whatsalp-grid-2">
				<?php
				foreach ( $schema as $key => $field ) {
					if ( 'utm' === ( $field['group'] ?? '' ) ) {
						$this->field( $integration, (string) $key, $field, $vals );
					}
				}
				?>
			</div>
		</details>
		<?php
	}

	private function enum_label( string $key, string $opt ): string {
		$labels = [ 'lead' => __( 'Lead (caixa de entrada de leads)', 'whatsalp' ), 'deal' => __( 'Negócio (pipeline)', 'whatsalp' ) ];
		return $labels[ $opt ] ?? $opt;
	}

	private function log_table(): void {
		global $wpdb;
		$log    = DbSchema::sync_log_table();
		$leads  = DbSchema::leads_table();
		$filter_int    = isset( $_GET['log_integration'] ) ? sanitize_key( wp_unslash( $_GET['log_integration'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$filter_status = isset( $_GET['log_status'] ) ? sanitize_key( wp_unslash( $_GET['log_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$where  = [ 'l.created_at >= UTC_TIMESTAMP() - INTERVAL 7 DAY' ];
		$params = [];
		if ( $filter_int ) {
			$where[]  = 'l.integration = %s';
			$params[] = $filter_int;
		}
		if ( $filter_status ) {
			$where[]  = 'l.status = %s';
			$params[] = $filter_status;
		}
		$sql  = "SELECT l.*, d.name AS lead_name FROM {$log} l LEFT JOIN {$leads} d ON d.id = l.lead_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY l.updated_at DESC LIMIT 50';
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$statuses = [ 'pending' => __( 'Pendente', 'whatsalp' ), 'running' => __( 'Em andamento', 'whatsalp' ), 'success' => __( 'Sucesso', 'whatsalp' ), 'error' => __( 'Erro', 'whatsalp' ), 'skipped' => __( 'Ignorado', 'whatsalp' ) ];
		?>
		<section class="whatsalp-card">
			<header class="whatsalp-log-head">
				<h2><?php esc_html_e( 'Log de envios', 'whatsalp' ); ?> <span class="description"><?php esc_html_e( 'Últimos 50 envios · 7 dias', 'whatsalp' ); ?></span></h2>
				<form method="get" class="whatsalp-inline">
					<input type="hidden" name="page" value="<?php echo esc_attr( Menu::SLUG_INTEGRATIONS ); ?>">
					<select name="log_integration" aria-label="<?php esc_attr_e( 'Integração', 'whatsalp' ); ?>">
						<option value=""><?php esc_html_e( 'Todas as integrações', 'whatsalp' ); ?></option>
						<?php
						foreach ( IntegrationRegistry::all() as $i ) :
							?>
							<option value="<?php echo esc_attr( $i->id() ); ?>" <?php selected( $filter_int, $i->id() ); ?>><?php echo esc_html( $i->label() ); ?></option><?php endforeach; ?>
					</select>
					<select name="log_status" aria-label="<?php esc_attr_e( 'Status', 'whatsalp' ); ?>">
						<option value=""><?php esc_html_e( 'Todos os status', 'whatsalp' ); ?></option>
						<?php
						foreach ( $statuses as $k => $v ) :
							?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $filter_status, $k ); ?>><?php echo esc_html( $v ); ?></option><?php endforeach; ?>
					</select>
					<button class="button"><?php esc_html_e( 'Filtrar', 'whatsalp' ); ?></button>
					<?php if ( Logger::enabled() ) : ?>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=whatsalp_download_log' ), 'whatsalp_download_log' ) ); ?>"><?php esc_html_e( 'Baixar log de depuração', 'whatsalp' ); ?></a>
					<?php endif; ?>
				</form>
			</header>
			<table class="widefat striped whatsalp-log">
				<thead><tr><th><?php esc_html_e( 'Data', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Contato', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Integração', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Status', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Detalhe', 'whatsalp' ); ?></th><th class="whatsalp-right"><?php esc_html_e( 'Ação', 'whatsalp' ); ?></th></tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'Nenhum envio nos últimos 7 dias.', 'whatsalp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows ?: [] as $r ) : ?>
					<?php $integration = IntegrationRegistry::get( (string) $r['integration'] ); ?>
					<tr class="whatsalp-log-row is-<?php echo esc_attr( (string) $r['status'] ); ?>">
						<td><?php echo esc_html( wp_date( 'd/m H:i', strtotime( $r['updated_at'] . ' UTC' ) ) ); ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Menu::SLUG_CONTACTS . '&lead=' . (int) $r['lead_id'] ) ); ?>"><?php echo esc_html( (string) ( $r['lead_name'] ?: '#' . $r['lead_id'] ) ); ?></a></td>
						<td><?php echo esc_html( $integration ? $integration->label() : (string) $r['integration'] ); ?></td>
						<td><span class="whatsalp-badge is-<?php echo esc_attr( (string) $r['status'] ); ?>"><?php echo esc_html( $statuses[ $r['status'] ] ?? (string) $r['status'] ); ?></span></td>
						<td class="whatsalp-detail">
							<?php
							$detail = [];
							if ( $r['external_id'] ) {
								$detail[] = 'ID ' . $r['external_id'];
							}
							if ( $r['last_error'] ) {
								$detail[] = $r['last_error'];
							}
							if ( (int) $r['attempts'] > 1 ) {
								// translators: %s/%d = número de tentativas ou data da próxima tentativa.
								$detail[] = sprintf( __( '%d tentativas', 'whatsalp' ), (int) $r['attempts'] );
							}
							if ( 'pending' === $r['status'] && $r['next_attempt_at'] ) {
								// translators: %s/%d = número de tentativas ou data da próxima tentativa.
								$detail[] = sprintf( __( 'próxima %s', 'whatsalp' ), wp_date( 'd/m H:i', strtotime( $r['next_attempt_at'] . ' UTC' ) ) );
							}
							echo esc_html( implode( ' · ', $detail ) );
							if ( $r['response_excerpt'] ) :
								?>
								<details><summary><?php esc_html_e( 'resposta', 'whatsalp' ); ?></summary><code><?php echo esc_html( (string) $r['response_excerpt'] ); ?></code></details>
							<?php endif; ?>
						</td>
						<td class="whatsalp-right">
							<?php if ( in_array( $r['status'], [ 'error', 'skipped' ], true ) ) : ?>
								<button type="button" class="button button-small whatsalp-resend" data-log="<?php echo (int) $r['id']; ?>"><?php esc_html_e( 'Reenviar', 'whatsalp' ); ?></button>
							<?php elseif ( 'success' === $r['status'] && $integration && ! $integration->is_internal() ) : ?>
								<button type="button" class="button-link whatsalp-resend" data-log="<?php echo (int) $r['id']; ?>" data-as-new="1"><?php esc_html_e( 'Enviar novamente como novo', 'whatsalp' ); ?></button>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</section>
		<?php
	}
}
