<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Http\ExportController;
use WhatsAlp\Install\Schema;
use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Integrations\SyncLogRepository;
use WhatsAlp\Leads\LeadRepository;
use WhatsAlp\Leads\PhoneBR;

final class ContactsPage {

	private ?ContactsListTable $table = null;

	public function register(): void {
		add_filter( 'set_screen_option_whatsalp_leads_per_page', static fn( $s, $o, $v ) => (int) $v, 10, 3 );
	}

	/**
	 * load-{hook}: ações em massa antes de qualquer output.
	 */
	public function load(): void {
		add_screen_option( 'per_page', [ 'label' => __( 'Contatos por página', 'whatsalp' ), 'default' => 20, 'option' => 'whatsalp_leads_per_page' ] );
		$this->table = new ContactsListTable();
		$action      = $this->table->current_action();
		if ( ! $action ) {
			return;
		}
		check_admin_referer( 'bulk-whatsalp_leads' );
		$ids = isset( $_REQUEST['lead'] ) ? array_map( 'intval', (array) $_REQUEST['lead'] ) : []; // phpcs:ignore WordPress.Security
		if ( ! $ids ) {
			return;
		}
		if ( 'export' === $action ) {
			$key = bin2hex( random_bytes( 6 ) ); // minúsculas: sobrevive ao sanitize_key no destino
			set_transient( 'whatsalp_export_' . $key, $ids, 5 * MINUTE_IN_SECONDS );
			wp_safe_redirect( wp_nonce_url( add_query_arg( [ 'action' => ExportController::ACTION, 'ids' => $key ], admin_url( 'admin-post.php' ) ), ExportController::ACTION ) );
			exit;
		}
		if ( 'delete' === $action ) {
			$repo = new LeadRepository();
			foreach ( $ids as $id ) {
				$repo->delete( $id );
			}
			wp_safe_redirect( add_query_arg( [ 'page' => Menu::SLUG_CONTACTS, 'deleted' => count( $ids ) ], admin_url( 'admin.php' ) ) );
			exit;
		}
		if ( 'resync' === $action ) {
			$dispatcher = new Dispatcher();
			$log        = new SyncLogRepository();
			$deadline = microtime( true ) + Dispatcher::BUDGET_SECONDS;
			foreach ( $ids as $id ) {
				$dispatcher->enqueue_missing( $id );
				foreach ( $log->for_lead( $id ) as $row ) {
					if ( in_array( $row['status'], [ 'error', 'skipped' ], true ) ) {
						$dispatcher->resend( (int) $row['id'] );
					}
				}
				// Processa já o que couber no orçamento; o restante fica para o sweeper.
				if ( microtime( true ) < $deadline - 3 ) {
					$dispatcher->process( $id, 10, $deadline );
				}
			}
			wp_safe_redirect( add_query_arg( [ 'page' => Menu::SLUG_CONTACTS, 'resynced' => count( $ids ) ], admin_url( 'admin.php' ) ) );
			exit;
		}
	}

	public function render(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			return;
		}
		$lead_id = isset( $_GET['lead'] ) ? absint( $_GET['lead'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$table   = $this->table ?? new ContactsListTable();
		$table->prepare_items();
		global $wpdb;
		$leads_table = Schema::leads_table();
		$total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$leads_table}" ); // phpcs:ignore WordPress.DB
		$week    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$leads_table} WHERE created_at >= UTC_TIMESTAMP() - INTERVAL 7 DAY" ); // phpcs:ignore WordPress.DB
		$filters = ContactsListTable::filters();
		$export  = wp_nonce_url( add_query_arg( array_merge( [ 'action' => ExportController::ACTION ], array_filter( [ 's' => $filters['search'], 'from' => $filters['from'], 'to' => $filters['to'], 'source' => $filters['source'], 'sync' => $filters['sync'] ] ) ), admin_url( 'admin-post.php' ) ), ExportController::ACTION );
		?>
		<div class="wrap whatsalp-wrap">
			<?php Menu::header( Menu::SLUG_CONTACTS ); ?>
			<?php if ( ! empty( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<?php // translators: %d = quantidade de contatos. ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( __( '%d contato(s) excluído(s).', 'whatsalp' ), absint( $_GET['deleted'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></p></div>
			<?php endif; ?>
			<?php if ( ! empty( $_GET['resynced'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<?php // translators: %d = quantidade de contatos. ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( __( '%d contato(s) reenviado(s). O que não coube agora é processado em até 5 minutos.', 'whatsalp' ), absint( $_GET['resynced'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></p></div>
			<?php endif; ?>
			<div class="whatsalp-contacts-head">
				<?php // translators: %d = quantidade de contatos. ?>
				<p class="description"><?php echo esc_html( sprintf( __( '%1$d leads capturados · %2$d nos últimos 7 dias', 'whatsalp' ), $total, $week ) ); ?></p>
				<a class="button" href="<?php echo esc_url( $export ); ?>"><?php esc_html_e( 'Exportar CSV', 'whatsalp' ); ?></a>
				<a class="button-link" href="<?php echo esc_url( add_query_arg( 'delimiter', ',', $export ) ); ?>"><?php esc_html_e( 'CSV com vírgula', 'whatsalp' ); ?></a>
			</div>
			<div class="whatsalp-columns">
				<div class="whatsalp-main">
					<form method="get">
						<input type="hidden" name="page" value="<?php echo esc_attr( Menu::SLUG_CONTACTS ); ?>">
						<?php $table->search_box( __( 'Buscar', 'whatsalp' ), 'whatsalp' ); ?>
						<?php $table->display(); ?>
					</form>
				</div>
				<?php
				if ( $lead_id ) {
					$this->detail( $lead_id ); }
				?>
			</div>
		</div>
		<?php
	}

	private function detail( int $id ): void {
		$lead = ( new LeadRepository() )->find( $id );
		if ( ! $lead ) {
			echo '<aside class="whatsalp-side whatsalp-detail-panel"><p>' . esc_html__( 'Contato não encontrado. Ele pode ter sido excluído.', 'whatsalp' ) . '</p></aside>';
			return;
		}
		$logs     = ( new SyncLogRepository() )->for_lead( $id );
		$parts    = preg_split( '/\s+/', trim( $lead->name ) ) ?: [];
		$initials = mb_strtoupper( mb_substr( $parts[0] ?? 'W', 0, 1 ) . ( count( $parts ) > 1 ? mb_substr( (string) end( $parts ), 0, 1 ) : '' ) );
		$close    = remove_query_arg( 'lead' );
		?>
		<aside class="whatsalp-side whatsalp-detail-panel" aria-label="<?php esc_attr_e( 'Detalhes do contato', 'whatsalp' ); ?>">
			<header>
				<span class="whatsalp-avatar-initials"><?php echo esc_html( trim( $initials ) ); ?></span>
				<div>
					<strong><?php echo esc_html( $lead->name ?: PhoneBR::format( $lead->phone ) ); ?></strong>
					<div class="description">Lead #<?php echo (int) $lead->id; ?> · <?php echo esc_html( wp_date( 'd/m/Y H:i', strtotime( $lead->created_at . ' UTC' ) ) ); ?></div>
				</div>
				<a class="button button-small" href="<?php echo esc_url( $close ); ?>" aria-label="<?php esc_attr_e( 'Fechar detalhes', 'whatsalp' ); ?>">×</a>
			</header>
			<a class="button button-primary whatsalp-wa-button" href="https://wa.me/<?php echo esc_attr( $lead->phone ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Conversar no WhatsApp', 'whatsalp' ); ?></a>
			<dl class="whatsalp-dl">
				<dt><?php esc_html_e( 'Telefone', 'whatsalp' ); ?></dt><dd><?php echo esc_html( PhoneBR::format( $lead->phone ) ); ?></dd>
				<dt><?php esc_html_e( 'E-mail', 'whatsalp' ); ?></dt><dd><?php echo esc_html( $lead->email ?: '—' ); ?></dd>
				<?php if ( $lead->company ) : ?>
					<dt><?php esc_html_e( 'Empresa', 'whatsalp' ); ?></dt><dd><?php echo esc_html( $lead->company ); ?></dd>
				<?php endif; ?>
				<?php if ( $lead->menu_option ) : ?>
					<dt><?php esc_html_e( 'Escolha no menu', 'whatsalp' ); ?></dt><dd><?php echo esc_html( $lead->menu_option ); ?></dd>
				<?php endif; ?>
				<dt><?php esc_html_e( 'Consentimento', 'whatsalp' ); ?></dt><dd><?php echo $lead->consent ? esc_html__( 'Aceito', 'whatsalp' ) : '—'; ?>
				<?php
				if ( $lead->consent_text ) :
					?>
					<br><small class="description"><?php echo esc_html( $lead->consent_text ); ?></small><?php endif; ?></dd>
				<dt><?php esc_html_e( 'Página de origem', 'whatsalp' ); ?></dt><dd>
				<?php
				if ( $lead->source_url ) :
					?>
					<a href="<?php echo esc_url( $lead->source_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $lead->source_title ?: $lead->source_path ?: $lead->source_url ); ?></a>
					<?php
else :
	?>
					—<?php endif; ?></dd>
				<?php foreach ( $lead->utm as $k => $v ) : ?>
					<dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $v ); ?></dd>
				<?php endforeach; ?>
			</dl>
			<h3><?php esc_html_e( 'Linha do tempo', 'whatsalp' ); ?></h3>
			<ul class="whatsalp-timeline">
				<li class="is-info"><span><?php esc_html_e( 'Formulário enviado', 'whatsalp' ); ?></span><small><?php echo esc_html( wp_date( 'd/m/Y H:i', strtotime( $lead->created_at . ' UTC' ) ) ); ?>
				<?php
				if ( $lead->user_agent ) :
					?>
					· <?php echo esc_html( mb_substr( $lead->user_agent, 0, 60 ) ); ?><?php endif; ?></small></li>
				<?php foreach ( $logs as $row ) : ?>
					<?php $integration = IntegrationRegistry::get( (string) $row['integration'] ); ?>
					<li class="is-<?php echo esc_attr( (string) $row['status'] ); ?>">
						<span><?php echo esc_html( $integration ? $integration->label() : (string) $row['integration'] ); ?>: <?php echo wp_kses_post( ContactsListTable::status_badge( (string) $row['status'] ) ); ?>
						<?php
						if ( $row['external_id'] ) :
							?>
							· ID <?php echo esc_html( (string) $row['external_id'] ); ?><?php endif; ?></span>
						<small><?php echo esc_html( wp_date( 'd/m/Y H:i', strtotime( $row['updated_at'] . ' UTC' ) ) ); ?>
						<?php
						if ( $row['last_error'] ) :
							?>
							· <?php echo esc_html( (string) $row['last_error'] ); ?><?php endif; ?></small>
						<?php if ( in_array( $row['status'], [ 'error', 'skipped' ], true ) ) : ?>
							<button type="button" class="button button-small whatsalp-resend" data-log="<?php echo (int) $row['id']; ?>"><?php esc_html_e( 'Reenviar', 'whatsalp' ); ?></button>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
				<?php if ( $lead->wa_clicked_at ) : ?>
					<li class="is-success"><span><?php esc_html_e( 'Clicou em "Abrir WhatsApp"', 'whatsalp' ); ?></span><small><?php echo esc_html( wp_date( 'd/m/Y H:i', strtotime( $lead->wa_clicked_at . ' UTC' ) ) ); ?></small></li>
				<?php endif; ?>
			</ul>
			<footer class="whatsalp-detail-actions">
				<button type="button" class="button whatsalp-resync" data-lead="<?php echo (int) $lead->id; ?>"><?php esc_html_e( 'Reenviar ao CRM', 'whatsalp' ); ?></button>
				<button type="button" class="button whatsalp-delete is-destructive" data-lead="<?php echo (int) $lead->id; ?>"><?php esc_html_e( 'Excluir contato', 'whatsalp' ); ?></button>
			</footer>
			<p class="description"><?php esc_html_e( 'Excluir remove o contato e o histórico deste site. O dado já enviado ao CRM ou ao webhook permanece lá.', 'whatsalp' ); ?></p>
		</aside>
		<?php
	}
}
