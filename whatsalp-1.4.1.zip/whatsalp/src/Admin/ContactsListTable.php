<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Http\ExportController;
use WhatsAlp\Install\Schema;
use WhatsAlp\Leads\PhoneBR;

if ( ! class_exists( '\WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

final class ContactsListTable extends \WP_List_Table {

	private const SORTABLE = [ 'id', 'name', 'created_at', 'sync_status' ];

	public function __construct() {
		parent::__construct( [ 'singular' => 'whatsalp_lead', 'plural' => 'whatsalp_leads', 'ajax' => false ] );
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns(): array {
		return [
			'cb'          => '<input type="checkbox">',
			'name'        => __( 'Nome', 'whatsalp' ),
			'phone'       => __( 'Telefone', 'whatsalp' ),
			'email'       => __( 'E-mail', 'whatsalp' ),
			'company'     => __( 'Empresa', 'whatsalp' ),
			'menu_option' => __( 'Escolha', 'whatsalp' ),
			'source_path' => __( 'Origem', 'whatsalp' ),
			'created_at'  => __( 'Data', 'whatsalp' ),
			'sync_status' => __( 'CRM', 'whatsalp' ),
			'actions'     => '',
		];
	}

	/**
	 * @return array<string, array{0:string,1:bool}>
	 */
	protected function get_sortable_columns(): array {
		return [ 'name' => [ 'name', false ], 'created_at' => [ 'created_at', true ], 'sync_status' => [ 'sync_status', false ] ];
	}

	/**
	 * @return array<string,string>
	 */
	protected function get_bulk_actions(): array {
		return [
			'export' => __( 'Exportar selecionados', 'whatsalp' ),
			'resync' => __( 'Reenviar ao CRM', 'whatsalp' ),
			'delete' => __( 'Excluir', 'whatsalp' ),
		];
	}

	/**
	 * @return array<string,string>
	 */
	public static function filters(): array {
		// phpcs:disable WordPress.Security.NonceVerification
		return [
			'search' => isset( $_REQUEST['s'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) : '',
			'from'   => isset( $_REQUEST['from'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['from'] ) ) : '',
			'to'     => isset( $_REQUEST['to'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['to'] ) ) : '',
			'source' => isset( $_REQUEST['source'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['source'] ) ) : '',
			'sync'   => isset( $_REQUEST['sync'] ) ? sanitize_key( wp_unslash( $_REQUEST['sync'] ) ) : '',
		];
		// phpcs:enable
	}

	public function prepare_items(): void {
		global $wpdb;
		$table    = Schema::leads_table();
		$per_page = $this->get_items_per_page( 'whatsalp_leads_per_page', 20 );
		$paged    = max( 1, $this->get_pagenum() );
		$where    = [ '1=1' ];
		$params   = [];
		ExportController::build_where( self::filters(), $where, $params );

		$orderby = isset( $_GET['orderby'] ) && in_array( $_GET['orderby'], self::SORTABLE, true ) ? (string) $_GET['orderby'] : 'id'; // phpcs:ignore WordPress.Security.NonceVerification
		$order   = isset( $_GET['order'] ) && 'asc' === strtolower( (string) $_GET['order'] ) ? 'ASC' : 'DESC'; // phpcs:ignore WordPress.Security.NonceVerification

		$where_sql = implode( ' AND ', $where );
		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$sql   = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$rows  = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, [ $per_page, ( $paged - 1 ) * $per_page ] ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$this->items = $rows ?: [];
		$this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns(), 'name' ];
		$this->set_pagination_args( [ 'total_items' => $total, 'per_page' => $per_page ] );
	}

	public function no_items(): void {
		echo '<strong>' . esc_html__( 'Nenhum contato ainda.', 'whatsalp' ) . '</strong> ' . esc_html__( 'Confira se o número do WhatsApp está configurado e se o botão aparece no site.', 'whatsalp' );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_cb( $item ): string {
		return sprintf( '<input type="checkbox" name="lead[]" value="%d" aria-label="%s">', (int) $item['id'], esc_attr( sprintf( __( 'Selecionar %s', 'whatsalp' ), $item['name'] ) ) );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_name( $item ): string {
		$url = add_query_arg( [ 'page' => Menu::SLUG_CONTACTS, 'lead' => (int) $item['id'] ], admin_url( 'admin.php' ) );
		return sprintf( '<a href="%s"><strong>%s</strong></a>', esc_url( $url ), esc_html( $item['name'] ?: '—' ) );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_phone( $item ): string {
		return esc_html( PhoneBR::format( (string) $item['phone'] ) );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_created_at( $item ): string {
		return esc_html( wp_date( 'd/m/Y H:i', strtotime( $item['created_at'] . ' UTC' ) ) );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_sync_status( $item ): string {
		return self::status_badge( (string) $item['sync_status'] );
	}

	public static function status_badge( string $status ): string {
		$labels = [ 'none' => __( 'Sem CRM', 'whatsalp' ), 'pending' => __( 'Pendente', 'whatsalp' ), 'success' => __( 'Sincronizado', 'whatsalp' ), 'error' => __( 'Erro', 'whatsalp' ) ];
		return sprintf( '<span class="whatsalp-badge is-%s">%s</span>', esc_attr( $status ), esc_html( $labels[ $status ] ?? $status ) );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_actions( $item ): string {
		$id   = (int) $item['id'];
		$view = add_query_arg( [ 'page' => Menu::SLUG_CONTACTS, 'lead' => $id ], admin_url( 'admin.php' ) );
		return sprintf(
			'<span class="whatsalp-row-actions"><a class="button button-small" href="https://wa.me/%1$s" target="_blank" rel="noopener" aria-label="%2$s">WA</a> <a class="button button-small" href="%3$s" aria-label="%4$s">%5$s</a> <button type="button" class="button button-small whatsalp-delete" data-lead="%6$d" aria-label="%7$s">×</button></span>',
			esc_attr( (string) $item['phone'] ),
			esc_attr__( 'Abrir WhatsApp', 'whatsalp' ),
			esc_url( $view ),
			esc_attr__( 'Ver detalhes', 'whatsalp' ),
			esc_html__( 'Ver', 'whatsalp' ),
			$id,
			esc_attr__( 'Excluir', 'whatsalp' )
		);
	}

	/**
	 * @param array<string,mixed> $item
	 */
	protected function column_default( $item, $column_name ): string {
		return esc_html( (string) ( $item[ $column_name ] ?? '' ) );
	}

	protected function extra_tablenav( $which ): void {
		if ( 'top' !== $which ) {
			return;
		}
		global $wpdb;
		$f       = self::filters();
		$table   = Schema::leads_table();
		$sources = $wpdb->get_col( "SELECT DISTINCT source_path FROM {$table} WHERE source_path IS NOT NULL ORDER BY source_path LIMIT 200" ); // phpcs:ignore WordPress.DB
		?>
		<div class="alignleft actions whatsalp-filters">
			<input type="date" name="from" value="<?php echo esc_attr( $f['from'] ); ?>" aria-label="<?php esc_attr_e( 'De', 'whatsalp' ); ?>">
			<input type="date" name="to" value="<?php echo esc_attr( $f['to'] ); ?>" aria-label="<?php esc_attr_e( 'Até', 'whatsalp' ); ?>">
			<select name="source" aria-label="<?php esc_attr_e( 'Página de origem', 'whatsalp' ); ?>">
				<option value=""><?php esc_html_e( 'Todas as páginas', 'whatsalp' ); ?></option>
				<?php
				foreach ( $sources as $src ) :
					?>
					<option value="<?php echo esc_attr( (string) $src ); ?>" <?php selected( $f['source'], $src ); ?>><?php echo esc_html( (string) $src ); ?></option><?php endforeach; ?>
			</select>
			<select name="sync" aria-label="<?php esc_attr_e( 'Status no CRM', 'whatsalp' ); ?>">
				<option value=""><?php esc_html_e( 'Status no CRM', 'whatsalp' ); ?></option>
				<?php foreach ( [ 'success' => __( 'Sincronizado', 'whatsalp' ), 'error' => __( 'Erro', 'whatsalp' ), 'pending' => __( 'Pendente', 'whatsalp' ), 'none' => __( 'Sem CRM', 'whatsalp' ) ] as $k => $v ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $f['sync'], $k ); ?>><?php echo esc_html( $v ); ?></option>
				<?php endforeach; ?>
			</select>
			<?php submit_button( __( 'Filtrar', 'whatsalp' ), 'secondary', 'filter_action', false ); ?>
		</div>
		<?php
	}
}
