<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Integrations\AbstractIntegration;

final class Menu {

	public const SLUG_SETTINGS     = 'whatsalp';
	public const SLUG_INTEGRATIONS = 'whatsalp-integrations';
	public const SLUG_CONTACTS     = 'whatsalp-contacts';

	private SettingsPage $settings;
	private IntegrationsPage $integrations;
	private ContactsPage $contacts;

	public function __construct() {
		$this->settings     = new SettingsPage();
		$this->integrations = new IntegrationsPage();
		$this->contacts     = new ContactsPage();
	}

	public function register(): void {
		add_action( 'admin_menu', [ $this, 'menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
		add_action( 'admin_notices', [ $this, 'notices' ] );
		add_filter( 'plugin_action_links_' . WHATSALP_BASENAME, [ $this, 'action_links' ] );
		$this->integrations->register();
		$this->contacts->register();
	}

	public function menu(): void {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#a7aaad" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>' );
		add_menu_page( 'WhatsAlp', 'WhatsAlp', Capabilities::CAP, self::SLUG_SETTINGS, [ $this->settings, 'render' ], $icon, 58 );
		add_submenu_page( self::SLUG_SETTINGS, __( 'Configurações', 'whatsalp' ), __( 'Configurações', 'whatsalp' ), Capabilities::CAP, self::SLUG_SETTINGS, [ $this->settings, 'render' ] );
		add_submenu_page( self::SLUG_SETTINGS, __( 'Integrações', 'whatsalp' ), __( 'Integrações', 'whatsalp' ), Capabilities::CAP, self::SLUG_INTEGRATIONS, [ $this->integrations, 'render' ] );
		$hook = add_submenu_page( self::SLUG_SETTINGS, __( 'Contatos', 'whatsalp' ), __( 'Contatos', 'whatsalp' ), Capabilities::CAP, self::SLUG_CONTACTS, [ $this->contacts, 'render' ] );
		if ( $hook ) {
			add_action( 'load-' . $hook, [ $this->contacts, 'load' ] );
		}
	}

	public function assets( string $hook ): void {
		if ( ! str_contains( $hook, 'whatsalp' ) ) {
			return;
		}
		$ver = is_file( WHATSALP_DIR . 'assets/dist/admin.js' ) ? (string) filemtime( WHATSALP_DIR . 'assets/dist/admin.js' ) : WHATSALP_VERSION;
		wp_enqueue_style( 'whatsalp-admin', WHATSALP_URL . 'assets/dist/admin.css', [], $ver );
		wp_enqueue_script( 'whatsalp-admin', WHATSALP_URL . 'assets/dist/admin.js', [ 'wp-api-fetch' ], $ver, true );
		if ( 'toplevel_page_whatsalp' === $hook ) {
			wp_enqueue_media();
		}
		wp_add_inline_script(
			'whatsalp-admin',
			'window.WhatsAlpAdmin = ' . wp_json_encode(
				[
					'restBase'     => esc_url_raw( rest_url( 'whatsalp/v1/' ) ),
					'nonce'        => wp_create_nonce( 'wp_rest' ),
					'previewUrl'   => add_query_arg( [ 'whatsalp_preview' => 1, '_wpnonce' => wp_create_nonce( 'whatsalp_preview' ) ], home_url( '/' ) ),
					'i18n'         => [
						'testing'   => __( 'Testando...', 'whatsalp' ),
						'resending' => __( 'Reenviando...', 'whatsalp' ),
						'confirmDelete' => __( 'Excluir este contato definitivamente? O dado continua no CRM e no destino do webhook.', 'whatsalp' ),
						'confirmAsNew'  => __( 'Isso cria um NOVO lead/negócio no CRM para este contato. Continuar?', 'whatsalp' ),
						'chooseImage'   => __( 'Escolher avatar', 'whatsalp' ),
						'useImage'      => __( 'Usar esta imagem', 'whatsalp' ),
						'done'          => __( 'Feito.', 'whatsalp' ),
						'saveFirst'     => __( 'Salve a integração antes de testar: o teste usa o token gravado.', 'whatsalp' ),
						'defaultOption' => __( '— padrão —', 'whatsalp' ),
						'listUnavailable' => __( 'lista indisponível', 'whatsalp' ),
						'listsUpdated'  => __( 'Listas atualizadas.', 'whatsalp' ),
						'confirmUtmFields' => __( 'Isso cria campos personalizados no seu Pipedrive (UTM Source, Medium, Campaign, Term, Content, GCLID, FBCLID). Campos de mesmo nome são reaproveitados. Continuar?', 'whatsalp' ),
						'creatingFields' => __( 'Criando campos no Pipedrive...', 'whatsalp' ),
						'error'         => __( 'Algo deu errado. Tente novamente.', 'whatsalp' ),
					],
				],
				JSON_UNESCAPED_UNICODE
			) . ';',
			'before'
		);
	}

	public function notices(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && str_contains( (string) $screen->id, 'whatsalp' ) && '' === (string) \WhatsAlp\Settings\Settings::get( 'phone_number' ) ) {
			printf(
				'<div class="notice notice-warning"><p><strong>WhatsAlp:</strong> %s <a href="%s">%s</a></p></div>',
				esc_html__( 'o botão só aparece no site depois de informar o número do WhatsApp.', 'whatsalp' ),
				esc_url( admin_url( 'admin.php?page=' . self::SLUG_SETTINGS . '#phone_number' ) ),
				esc_html__( 'Configurar número', 'whatsalp' )
			);
		}
		foreach ( IntegrationRegistry::all() as $integration ) {
			if ( $integration instanceof AbstractIntegration && $integration->is_enabled() && $integration->auth_failed() ) {
				printf(
					'<div class="notice notice-error"><p><strong>WhatsAlp:</strong> %s <a href="%s">%s</a></p></div>',
					// translators: %s = nome da integração.
					esc_html( sprintf( __( 'a integração %s recusou as credenciais. Novos leads ficam em espera até você reinserir o token.', 'whatsalp' ), $integration->label() ) ),
					esc_url( admin_url( 'admin.php?page=' . self::SLUG_INTEGRATIONS . '&integration=' . $integration->id() ) ),
					esc_html__( 'Corrigir agora', 'whatsalp' )
				);
			}
		}
	}

	/**
	 * @param string[] $links
	 * @return string[]
	 */
	public function action_links( array $links ): array {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG_SETTINGS ) ) . '">' . esc_html__( 'Configurações', 'whatsalp' ) . '</a>' );
		return $links;
	}

	public static function header( string $active ): void {
		$tabs = [
			self::SLUG_SETTINGS     => __( 'Configurações', 'whatsalp' ),
			self::SLUG_INTEGRATIONS => __( 'Integrações', 'whatsalp' ),
			self::SLUG_CONTACTS     => __( 'Contatos', 'whatsalp' ),
		];
		?>
		<div class="whatsalp-header">
			<div class="whatsalp-logo" aria-hidden="true"></div>
			<div>
				<h1>WhatsAlp</h1>
				<p class="description"><?php esc_html_e( 'Botão de WhatsApp com captura de leads', 'whatsalp' ); ?> · <a href="https://alpina.digital" target="_blank" rel="noopener">Alpina Digital</a></p>
			</div>
		</div>
		<nav class="nav-tab-wrapper whatsalp-tabs">
			<?php foreach ( $tabs as $slug => $label ) : ?>
				<a class="nav-tab <?php echo $slug === $active ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=' . $slug ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php
	}
}
