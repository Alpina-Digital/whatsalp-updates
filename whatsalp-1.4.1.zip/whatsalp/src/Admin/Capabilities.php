<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

/**
 * manage_whatsalp concedida dinamicamente a quem tem manage_options.
 * Nada persistido no role: funciona mesmo quando o hook de ativação não rodou.
 */
final class Capabilities {

	public const CAP = 'manage_whatsalp';

	public function register(): void {
		add_filter( 'user_has_cap', [ $this, 'grant' ], 10, 3 );
	}

	/**
	 * @param array<string,bool> $allcaps
	 * @param string[] $caps
	 * @param array<int,mixed> $args
	 * @return array<string,bool>
	 */
	public function grant( array $allcaps, array $caps, array $args ): array {
		if ( in_array( self::CAP, $caps, true ) && ! empty( $allcaps['manage_options'] ) ) {
			$allcaps[ self::CAP ] = true;
		}
		return $allcaps;
	}
}
