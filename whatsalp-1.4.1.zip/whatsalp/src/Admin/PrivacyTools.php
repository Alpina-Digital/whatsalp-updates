<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Leads\LeadRepository;
use WhatsAlp\Leads\PhoneBR;

/**
 * Exportador e apagador de dados pessoais do WP (por e-mail), com paginação.
 */
final class PrivacyTools {

	private const PER_PAGE = 100;

	public function register(): void {
		add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ $this, 'eraser' ] );
	}

	/**
	 * @param array<string, array<string,mixed>> $exporters
	 * @return array<string, array<string,mixed>>
	 */
	public function exporter( array $exporters ): array {
		$exporters['whatsalp'] = [ 'exporter_friendly_name' => 'WhatsAlp', 'callback' => [ $this, 'export' ] ];
		return $exporters;
	}

	/**
	 * @param array<string, array<string,mixed>> $erasers
	 * @return array<string, array<string,mixed>>
	 */
	public function eraser( array $erasers ): array {
		$erasers['whatsalp'] = [ 'eraser_friendly_name' => 'WhatsAlp', 'callback' => [ $this, 'erase' ] ];
		return $erasers;
	}

	/**
	 * @return array{data: array<int, array<string,mixed>>, done: bool}
	 */
	public function export( string $email, int $page = 1 ): array {
		$leads = ( new LeadRepository() )->find_by_email( $email, $page, self::PER_PAGE );
		$data  = [];
		foreach ( $leads as $lead ) {
			$data[] = [
				'group_id'    => 'whatsalp_leads',
				'group_label' => __( 'Contatos via WhatsApp (WhatsAlp)', 'whatsalp' ),
				'item_id'     => 'whatsalp-lead-' . $lead->id,
				'data'        => [
					[ 'name' => __( 'Nome', 'whatsalp' ), 'value' => $lead->name ],
					[ 'name' => __( 'Telefone', 'whatsalp' ), 'value' => PhoneBR::format( $lead->phone ) ],
					[ 'name' => __( 'E-mail', 'whatsalp' ), 'value' => (string) $lead->email ],
					[ 'name' => __( 'Página de origem', 'whatsalp' ), 'value' => (string) $lead->source_url ],
					[ 'name' => __( 'Consentimento', 'whatsalp' ), 'value' => (string) $lead->consent_text ],
					[ 'name' => __( 'Data', 'whatsalp' ), 'value' => $lead->created_at . ' UTC' ],
				],
			];
		}
		return [ 'data' => $data, 'done' => count( $leads ) < self::PER_PAGE ];
	}

	/**
	 * @return array{items_removed: int, items_retained: int, messages: string[], done: bool}
	 */
	public function erase( string $email, int $page = 1 ): array {
		$repo  = new LeadRepository();
		$leads = $repo->find_by_email( $email, 1, self::PER_PAGE );
		foreach ( $leads as $lead ) {
			$repo->delete( $lead->id );
		}
		return [ 'items_removed' => count( $leads ), 'items_retained' => 0, 'messages' => [], 'done' => count( $leads ) < self::PER_PAGE ];
	}
}
