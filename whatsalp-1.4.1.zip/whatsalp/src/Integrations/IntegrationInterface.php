<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

use WhatsAlp\Leads\Lead;

interface IntegrationInterface {

	public function id(): string;

	public function label(): string;

	/** URL de ícone ou SVG inline. */
	public function icon(): string;

	/**
	 * Campos exibidos no admin. Mesmo formato de Settings\Schema::fields(),
	 * com chaves extras: label, help, secret (bool), options_callback.
	 *
	 * @return array<string, array<string,mixed>>
	 */
	public function settings_schema(): array;

	public function is_enabled(): bool;

	public function is_configured(): bool;

	/** Integrações internas não entram no cálculo de sync_status. */
	public function is_internal(): bool;

	public function test_connection(): PushResult;

	public function push_lead( Lead $lead, SyncContext $ctx ): PushResult;
}
