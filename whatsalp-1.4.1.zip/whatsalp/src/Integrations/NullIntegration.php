<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

use WhatsAlp\Leads\Lead;

/**
 * Integração de teste: só registra o lead no log. Não aparece no admin.
 */
final class NullIntegration extends AbstractIntegration {

	/** @var callable|null */
	public static $handler = null;

	public function id(): string {
		return 'null';
	}

	public function label(): string {
		return 'Null';
	}

	public function settings_schema(): array {
		return [];
	}

	public function is_enabled(): bool {
		return true;
	}

	public function is_configured(): bool {
		return true;
	}

	public function test_connection(): PushResult {
		return PushResult::success();
	}

	public function push_lead( Lead $lead, SyncContext $ctx ): PushResult {
		if ( is_callable( self::$handler ) ) {
			return ( self::$handler )( $lead, $ctx );
		}
		return PushResult::success( 'null-' . $lead->id, [ 'step' => 'done' ] );
	}
}
