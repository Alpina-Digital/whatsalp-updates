<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

use WhatsAlp\Security\Crypto;
use WhatsAlp\Settings\Schema;

/**
 * Persistência das configurações por integração em whatsalp_integrations
 * (autoload no), com segredos cifrados e flag auth_failed.
 */
abstract class AbstractIntegration implements IntegrationInterface {

	public const OPTION = 'whatsalp_integrations';

	/** @var array<string,mixed>|null */
	private ?array $settings = null;

	public function icon(): string {
		return '';
	}

	public function is_internal(): bool {
		return false;
	}

	public function is_enabled(): bool {
		return (bool) $this->setting( 'enabled' );
	}

	public function auth_failed(): bool {
		return (bool) $this->setting( 'auth_failed' );
	}

	public function set_auth_failed( bool $failed ): void {
		$this->save_settings( [ 'auth_failed' => $failed ] );
	}

	/**
	 * @return mixed
	 */
	public function setting( string $key ) {
		$all = $this->settings();
		return $all[ $key ] ?? null;
	}

	/**
	 * Segredo decifrado; null quando não é possível decifrar (salts rotacionados).
	 */
	public function secret( string $key ): ?string {
		$raw = $this->setting( $key );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return null;
		}
		$plain = Crypto::decrypt( $raw );
		if ( null === $plain ) {
			return null;
		}
		$rekeyed = Crypto::rekeyed_payload();
		if ( null !== $rekeyed ) {
			$this->save_settings( [ $key => $rekeyed ], false );
			if ( null !== $this->settings ) {
				$this->settings[ $key ] = $rekeyed;
			}
		}
		return $plain;
	}

	/**
	 * Verdadeiro quando há um segredo gravado mas indecifrável.
	 */
	public function secret_unreadable( string $key ): bool {
		$raw = $this->setting( $key );
		return is_string( $raw ) && '' !== $raw && null === Crypto::decrypt( $raw );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function settings(): array {
		if ( null === $this->settings ) {
			$all            = get_option( self::OPTION, [] );
			$mine           = is_array( $all ) && isset( $all[ $this->id() ] ) && is_array( $all[ $this->id() ] ) ? $all[ $this->id() ] : [];
			$defaults       = [ 'enabled' => false, 'auth_failed' => false ];
			foreach ( $this->settings_schema() as $key => $field ) {
				$defaults[ $key ] = Schema::resolve_default( $field['default'] ?? '' );
			}
			$this->settings = array_merge( $defaults, $mine );
		}
		return $this->settings;
	}

	/**
	 * Sanitiza e grava um POST do admin. Segredos que chegam como máscara são preservados.
	 *
	 * @param array<string,mixed> $input
	 */
	public function save_from_input( array $input ): void {
		$data = [ 'enabled' => ! empty( $input['enabled'] ) ];
		foreach ( $this->settings_schema() as $key => $field ) {
			$is_secret = ! empty( $field['secret'] );
			if ( $is_secret ) {
				$value = isset( $input[ $key ] ) ? trim( (string) $input[ $key ] ) : '';
				if ( '' === $value || self::MASK === $value ) {
					continue; // preserva o anterior
				}
				$data[ $key ]        = Crypto::encrypt( $value );
				$data['auth_failed'] = false;
				continue;
			}
			if ( Schema::TYPE_BOOL === ( $field['type'] ?? '' ) ) {
				$data[ $key ] = ! empty( $input[ $key ] );
				continue;
			}
			if ( array_key_exists( $key, $input ) ) {
				$data[ $key ] = Schema::sanitize( $input[ $key ], $field );
			}
		}
		$this->save_settings( $data );
	}

	public const MASK = '••••••••••••';

	/**
	 * Valor para exibir no formulário: segredos viram máscara.
	 *
	 * @return mixed
	 */
	public function display_value( string $key ) {
		$field = $this->settings_schema()[ $key ] ?? [];
		if ( ! empty( $field['secret'] ) ) {
			$raw = $this->setting( $key );
			return is_string( $raw ) && '' !== $raw ? self::MASK : '';
		}
		return $this->setting( $key );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	protected function save_settings( array $data, bool $flush = true ): void {
		$all = get_option( self::OPTION, [] );
		$all = is_array( $all ) ? $all : [];
		$all[ $this->id() ] = array_merge( $all[ $this->id() ] ?? [], $data );
		update_option( self::OPTION, $all, false );
		if ( $flush ) {
			$this->settings = null;
		}
	}
}
