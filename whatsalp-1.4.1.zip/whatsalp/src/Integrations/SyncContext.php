<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

final class SyncContext {

	public int $attempt;
	public int $log_id;
	/** @var array<string,mixed> */
	public array $previous_state;
	private float $deadline;
	/** @var callable(array<string,mixed>):void */
	private $saver;

	/**
	 * @param array<string,mixed> $previous_state
	 * @param callable(array<string,mixed>):void $saver
	 */
	public function __construct( int $log_id, int $attempt, array $previous_state, float $deadline, callable $saver ) {
		$this->log_id         = $log_id;
		$this->attempt        = $attempt;
		$this->previous_state = $previous_state;
		$this->deadline       = $deadline;
		$this->saver          = $saver;
	}

	/**
	 * Persiste step/external_* no meio do push (idempotência em retry).
	 *
	 * @param array<string,mixed> $state
	 */
	public function save_state( array $state ): void {
		$this->previous_state = array_merge( $this->previous_state, $state );
		( $this->saver )( $this->previous_state );
	}

	public function time_left(): int {
		return max( 0, (int) floor( $this->deadline - microtime( true ) ) );
	}

	/**
	 * Há tempo para mais uma chamada HTTP de até $seconds?
	 */
	public function can_continue( int $seconds = 8 ): bool {
		return $this->time_left() >= $seconds;
	}
}
