<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations\Webhook;

use WhatsAlp\Integrations\AbstractIntegration;
use WhatsAlp\Integrations\PushResult;
use WhatsAlp\Integrations\SyncContext;
use WhatsAlp\Leads\Lead;
use WhatsAlp\Settings\Schema;

/**
 * POST JSON assinado com HMAC-SHA256. wp_safe_remote_post bloqueia redes privadas.
 */
final class WebhookIntegration extends AbstractIntegration {

	public function id(): string {
		return 'webhook';
	}

	public function label(): string {
		return 'Webhook';
	}

	public function settings_schema(): array {
		return [
			'url'    => [ 'type' => Schema::TYPE_URL, 'default' => '', 'label' => __( 'URL de destino', 'whatsalp' ), 'help' => __( 'Recebe um POST JSON por lead. Compatível com Zapier, Make e n8n.', 'whatsalp' ) ],
			'secret' => [ 'type' => Schema::TYPE_TEXT, 'default' => '', 'secret' => true, 'label' => __( 'Segredo de assinatura', 'whatsalp' ), 'help' => __( 'Gerado automaticamente. Valide o header X-WhatsAlp-Signature no destino.', 'whatsalp' ) ],
		];
	}

	public function is_configured(): bool {
		$url = (string) $this->setting( 'url' );
		// Segredo indecifrável (salts rotacionados) conta como não configurado: nunca assinar com chave vazia.
		return '' !== $url && false !== wp_http_validate_url( $url ) && null !== $this->secret( 'secret' );
	}

	/**
	 * Garante um segredo; devolve-o em claro apenas nesta chamada (exibido uma vez).
	 */
	public function ensure_secret(): ?string {
		if ( null !== $this->secret( 'secret' ) ) {
			return null;
		}
		$plain = bin2hex( random_bytes( 24 ) );
		$this->save_from_input( [ 'secret' => $plain, 'enabled' => $this->is_enabled(), 'url' => $this->setting( 'url' ) ] );
		return $plain;
	}

	/** Descarta o segredo atual para que ensure_secret() gere outro. */
	public function forget_secret(): void {
		$this->save_settings( [ 'secret' => '' ] );
	}

	public function test_connection(): PushResult {
		if ( ! $this->is_configured() ) {
			return PushResult::failure( 'unconfigured', __( 'Informe uma URL válida.', 'whatsalp' ) );
		}
		$lead             = new Lead();
		$lead->id         = 0;
		$lead->name       = 'Teste WhatsAlp';
		$lead->phone      = '5511999999999';
		$lead->email      = 'teste@example.com';
		$lead->created_at = gmdate( 'Y-m-d H:i:s' );
		return $this->send( $lead, 'test' );
	}

	public function push_lead( Lead $lead, SyncContext $ctx ): PushResult {
		return $this->send( $lead, 'lead.created' );
	}

	private function send( Lead $lead, string $event ): PushResult {
		$url    = (string) $this->setting( 'url' );
		$secret = $this->secret( 'secret' ) ?? '';
		$body   = (string) wp_json_encode(
			[
				'event' => $event,
				'site'  => home_url(),
				'lead'  => $lead->to_array(),
			],
			JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		);
		$ts  = (string) time();
		$sig = hash_hmac( 'sha256', $ts . '.' . $body, $secret );
		$res = wp_safe_remote_post(
			$url,
			[
				'timeout' => 8,
				'headers' => [
					'Content-Type'         => 'application/json',
					'User-Agent'           => 'WhatsAlp/' . WHATSALP_VERSION,
					'X-WhatsAlp-Event'     => $event,
					'X-WhatsAlp-Signature' => 't=' . $ts . ',v1=' . $sig,
				],
				'body'    => $body,
			]
		);
		if ( is_wp_error( $res ) ) {
			return PushResult::retry( 'network', $res->get_error_message() );
		}
		$status  = (int) wp_remote_retrieve_response_code( $res );
		$excerpt = 'HTTP ' . $status . ' ' . substr( (string) wp_remote_retrieve_body( $res ), 0, 300 );
		if ( $status >= 200 && $status < 300 ) {
			return PushResult::success( null, [ 'step' => 'sent' ], $excerpt );
		}
		if ( in_array( $status, [ 408, 425, 429 ], true ) || $status >= 500 ) {
			$retry_after = wp_remote_retrieve_header( $res, 'retry-after' );
			return PushResult::retry( (string) $status, $excerpt, is_numeric( $retry_after ) ? (int) $retry_after : null );
		}
		return PushResult::failure( (string) $status, $excerpt );
	}
}
