<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations\Pipedrive;

use WhatsAlp\Integrations\AbstractIntegration;
use WhatsAlp\Integrations\PushResult;
use WhatsAlp\Integrations\SyncContext;
use WhatsAlp\Leads\Lead;
use WhatsAlp\Leads\PhoneBR;
use WhatsAlp\Settings\Schema;

/**
 * Máquina de estados: find_person → create_person → create_item → create_note.
 * step guarda o último passo concluído; retry retoma do seguinte.
 */
final class PipedriveIntegration extends AbstractIntegration {

	public const STEP_PERSON = 'person';
	public const STEP_ITEM   = 'item';
	public const STEP_NOTE   = 'note';

	/**
	 * Parâmetro de rastreio → nome do campo personalizado criado no Pipedrive.
	 * Leads e negócios compartilham os mesmos campos (dealFields).
	 *
	 * @var array<string,string>
	 */
	public const UTM_FIELDS = [
		'utm_source'   => 'UTM Source',
		'utm_medium'   => 'UTM Medium',
		'utm_campaign' => 'UTM Campaign',
		'utm_term'     => 'UTM Term',
		'utm_content'  => 'UTM Content',
		'gclid'        => 'GCLID',
		'fbclid'       => 'FBCLID',
	];

	/** Chave de configuração que guarda a hash do campo no Pipedrive. */
	public static function utm_setting_key( string $utm ): string {
		return 'utm_field_' . $utm;
	}

	public function id(): string {
		return 'pipedrive';
	}

	public function label(): string {
		return 'Pipedrive';
	}

	public function settings_schema(): array {
		$fields = [
			'api_token'      => [ 'type' => Schema::TYPE_TEXT, 'default' => '', 'secret' => true, 'label' => __( 'Token da API', 'whatsalp' ), 'help' => __( 'Em Pipedrive: Configurações pessoais › API. Use um usuário de serviço. O token fica criptografado no banco.', 'whatsalp' ) ],
			'company_domain' => [ 'type' => Schema::TYPE_TEXT, 'default' => '', 'label' => __( 'Domínio da empresa', 'whatsalp' ), 'help' => __( 'Só o prefixo: empresa (de empresa.pipedrive.com).', 'whatsalp' ) ],
			'create_as'      => [ 'type' => Schema::TYPE_ENUM, 'default' => 'lead', 'options' => [ 'lead', 'deal' ], 'label' => __( 'Criar como', 'whatsalp' ) ],
			'pipeline_id'    => [ 'type' => Schema::TYPE_INT, 'default' => 0, 'label' => __( 'Pipeline', 'whatsalp' ), 'options_callback' => 'pipelines', 'show_when' => [ 'create_as' => 'deal' ] ],
			'stage_id'       => [ 'type' => Schema::TYPE_INT, 'default' => 0, 'label' => __( 'Etapa inicial', 'whatsalp' ), 'options_callback' => 'stages', 'show_when' => [ 'create_as' => 'deal' ] ],
			'owner_id'       => [ 'type' => Schema::TYPE_INT, 'default' => 0, 'label' => __( 'Responsável', 'whatsalp' ), 'options_callback' => 'users' ],
			'label_id'       => [ 'type' => Schema::TYPE_TEXT, 'default' => '', 'label' => __( 'Rótulo do lead', 'whatsalp' ), 'options_callback' => 'lead_labels', 'show_when' => [ 'create_as' => 'lead' ] ],
			'title_template' => [ 'type' => Schema::TYPE_TEXT, 'default' => '{nome} · Site', 'label' => __( 'Título do lead/negócio', 'whatsalp' ), 'help' => __( 'Variáveis: {nome} {empresa} {opcao} {telefone} {email} {site} {pagina}. Ex.: [SITE {site}] {empresa} - {opcao}', 'whatsalp' ) ],
			'title_uppercase' => [ 'type' => Schema::TYPE_BOOL, 'default' => false, 'label' => __( 'Título em caixa alta', 'whatsalp' ), 'help' => __( 'Converte o título inteiro para MAIÚSCULAS antes de enviar.', 'whatsalp' ) ],
		];
		// Rastreio de campanha: cada parâmetro vai para um campo personalizado, que o
		// Pipedrive sabe filtrar e somar em relatório — a nota continua sendo só leitura.
		foreach ( self::UTM_FIELDS as $utm => $label ) {
			$fields[ self::utm_setting_key( $utm ) ] = [
				'type'             => Schema::TYPE_TEXT,
				'default'          => '',
				'group'            => 'utm',
				// translators: %s = nome do parâmetro de rastreio (ex.: utm_source).
				'label'            => sprintf( __( 'Campo para %s', 'whatsalp' ), $utm ),
				'options_callback' => 'deal_fields',
			];
		}
		return $fields;
	}

	/** @var string|false|null false = ainda não resolvido. */
	private $token_cache = false;

	private function token(): ?string {
		if ( false === $this->token_cache ) {
			$this->token_cache = $this->secret( 'api_token' );
		}
		return $this->token_cache;
	}

	public function is_configured(): bool {
		return null !== $this->token();
	}

	public function client(): ?PipedriveClient {
		$token = $this->token();
		return null === $token ? null : new PipedriveClient( $token, (string) $this->setting( 'company_domain' ) );
	}

	public function test_connection(): PushResult {
		$client = $this->client();
		if ( ! $client ) {
			return PushResult::failure( 'unconfigured', __( 'Informe o token da API.', 'whatsalp' ) );
		}
		$res = $client->get( '/v1/users/me' );
		if ( 200 === $res['status'] && ! empty( $res['body']['data']['email'] ) ) {
			$this->set_auth_failed( false );
			return PushResult::success( (string) $res['body']['data']['id'], [], (string) $res['body']['data']['email'] );
		}
		return $this->classify( $res, 'users/me' );
	}

	/**
	 * Listas dinâmicas para o admin, com cache de 1 h.
	 *
	 * @return array<int|string,string>
	 */
	public function options( string $which, bool $refresh = false ): array {
		$key = $this->options_cache_key( $which );
		if ( ! $refresh ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$client = $this->client();
		if ( ! $client ) {
			return [];
		}
		$out = [];
		switch ( $which ) {
			case 'pipelines':
				$res = $client->get( '/api/v2/pipelines', [ 'limit' => 100 ] );
				foreach ( (array) ( $res['body']['data'] ?? [] ) as $row ) {
					if ( is_array( $row ) && isset( $row['id'], $row['name'] ) ) {
						$out[ (int) $row['id'] ] = (string) $row['name'];
					}
				}
				break;
			case 'stages':
				$res = $client->get( '/api/v2/stages', [ 'limit' => 500 ] );
				foreach ( (array) ( $res['body']['data'] ?? [] ) as $row ) {
					if ( is_array( $row ) && isset( $row['id'], $row['name'] ) ) {
						$out[ (int) $row['id'] ] = (string) $row['name'] . ' (' . (int) ( $row['pipeline_id'] ?? 0 ) . ')';
					}
				}
				break;
			case 'users':
				$res = $client->get( '/v1/users' );
				foreach ( (array) ( $res['body']['data'] ?? [] ) as $row ) {
					if ( is_array( $row ) && ! empty( $row['active_flag'] ) && isset( $row['id'], $row['name'] ) ) {
						$out[ (int) $row['id'] ] = (string) $row['name'];
					}
				}
				break;
			case 'lead_labels':
				$res = $client->get( '/v1/leadLabels' );
				foreach ( (array) ( $res['body']['data'] ?? [] ) as $row ) {
					if ( is_array( $row ) && isset( $row['id'], $row['name'] ) ) {
						$out[ (string) $row['id'] ] = (string) $row['name'];
					}
				}
				break;
			case 'deal_fields':
				// Paginado: instalações grandes passam de 100 campos e os de UTM ficariam de fora.
				for ( $page = 0, $start = 0; $page < 5; $page++, $start += 100 ) {
					$res = $client->get( '/v1/dealFields', [ 'start' => $start, 'limit' => 100 ] );
					if ( 200 !== $res['status'] ) {
						break;
					}
					foreach ( (array) ( $res['body']['data'] ?? [] ) as $row ) {
						if ( ! is_array( $row ) || ! isset( $row['key'], $row['name'] ) ) {
							continue;
						}
						// Só personalizados de texto: os nativos têm key legível e tipo fixo.
						if ( ! in_array( (string) ( $row['field_type'] ?? '' ), [ 'varchar', 'varchar_auto', 'text' ], true ) ) {
							continue;
						}
						if ( ! preg_match( '/^[a-f0-9]{40}$/', (string) $row['key'] ) ) {
							continue;
						}
						$out[ (string) $row['key'] ] = (string) $row['name'];
					}
					if ( empty( $res['body']['additional_data']['pagination']['more_items_in_collection'] ) ) {
						break;
					}
				}
				break;
		}
		if ( ! isset( $res ) || 200 !== $res['status'] ) {
			return []; // falha de API: não cacheia, o admin pode tentar de novo
		}
		set_transient( $key, $out, HOUR_IN_SECONDS );
		return $out;
	}

	private function options_cache_key( string $which ): string {
		return 'whatsalp_pd_' . $which . '_' . substr( md5( (string) $this->setting( 'company_domain' ) ), 0, 8 );
	}

	/**
	 * Garante um campo personalizado no Pipedrive para cada parâmetro de rastreio e
	 * grava o mapeamento. Reaproveita campo existente de mesmo nome antes de criar —
	 * clicar duas vezes não duplica nada no CRM.
	 *
	 * @return array{ok:bool, created:int, reused:int, message:string}
	 */
	public function ensure_utm_fields(): array {
		$client = $this->client();
		if ( ! $client ) {
			return [ 'ok' => false, 'created' => 0, 'reused' => 0, 'message' => __( 'Informe o token da API e salve antes de criar os campos.', 'whatsalp' ) ];
		}
		$existing = $this->options( 'deal_fields', true );
		$by_name  = [];
		foreach ( $existing as $hash => $name ) {
			$by_name[ self::normalize_name( (string) $name ) ] = (string) $hash;
		}
		$patch   = [];
		$created = 0;
		$reused  = 0;
		foreach ( self::UTM_FIELDS as $utm => $label ) {
			$setting = self::utm_setting_key( $utm );
			$current = (string) $this->setting( $setting );
			if ( '' !== $current && isset( $existing[ $current ] ) ) {
				continue; // já mapeado para um campo que existe
			}
			$name = self::normalize_name( $label );
			if ( isset( $by_name[ $name ] ) ) {
				$patch[ $setting ] = $by_name[ $name ];
				++$reused;
				continue;
			}
			$res = $client->post( '/v1/dealFields', [ 'name' => $label, 'field_type' => 'varchar' ] );
			if ( 201 !== $res['status'] && 200 !== $res['status'] ) {
				$this->persist_utm_mapping( $patch );
				if ( 401 === $res['status'] || 403 === $res['status'] ) {
					$this->set_auth_failed( true );
				}
				return [
					'ok'      => false,
					'created' => $created,
					'reused'  => $reused,
					// translators: 1 = nome do campo, 2 = resposta do Pipedrive.
					'message' => sprintf( __( 'Falha ao criar o campo "%1$s": %2$s', 'whatsalp' ), $label, (string) ( $res['error'] ?? substr( $res['raw'], 0, 200 ) ) ),
				];
			}
			$hash = (string) ( $res['body']['data']['key'] ?? '' );
			if ( '' === $hash ) {
				$this->persist_utm_mapping( $patch );
				return [
					'ok'      => false,
					'created' => $created,
					'reused'  => $reused,
					// translators: %s = nome do campo.
					'message' => sprintf( __( 'O Pipedrive criou "%s" mas não devolveu a chave do campo.', 'whatsalp' ), $label ),
				];
			}
			$patch[ $setting ] = $hash;
			$by_name[ $name ]  = $hash;
			++$created;
		}
		$this->persist_utm_mapping( $patch );
		return [
			'ok'      => true,
			'created' => $created,
			'reused'  => $reused,
			'message' => $created || $reused
				// translators: 1 = campos criados, 2 = campos reaproveitados.
				? sprintf( __( '%1$d campos criados, %2$d reaproveitados. Confira o mapeamento e salve a integração.', 'whatsalp' ), $created, $reused )
				: __( 'Todos os campos de UTM já estavam mapeados.', 'whatsalp' ),
		];
	}

	/**
	 * @param array<string,string> $patch
	 */
	private function persist_utm_mapping( array $patch ): void {
		if ( ! $patch ) {
			return;
		}
		$this->save_settings( $patch );
		delete_transient( $this->options_cache_key( 'deal_fields' ) );
	}

	private static function normalize_name( string $name ): string {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $name ), 'UTF-8' ) : strtolower( trim( $name ) );
	}

	/**
	 * Mapeamento atual, no formato esperado pelo formulário do admin.
	 *
	 * @return array<string,string> chave de configuração => hash do campo.
	 */
	public function utm_mapping(): array {
		$out = [];
		foreach ( array_keys( self::UTM_FIELDS ) as $utm ) {
			$key         = self::utm_setting_key( $utm );
			$out[ $key ] = (string) $this->setting( $key );
		}
		return $out;
	}

	/**
	 * Valores de rastreio deste lead, já endereçados pela hash do campo no Pipedrive.
	 *
	 * @return array<string,string>
	 */
	public function utm_custom_fields( Lead $lead ): array {
		$out = [];
		foreach ( array_keys( self::UTM_FIELDS ) as $utm ) {
			$hash  = trim( (string) $this->setting( self::utm_setting_key( $utm ) ) );
			$value = isset( $lead->utm[ $utm ] ) && is_scalar( $lead->utm[ $utm ] ) ? trim( (string) $lead->utm[ $utm ] ) : '';
			if ( '' === $hash || '' === $value ) {
				continue;
			}
			$out[ $hash ] = mb_substr( $value, 0, 255 );
		}
		return $out;
	}

	public function push_lead( Lead $lead, SyncContext $ctx ): PushResult {
		$client = $this->client();
		if ( ! $client ) {
			return PushResult::failure( 'unconfigured', null, [], false );
		}
		$state     = $ctx->previous_state;
		$step      = (string) ( $state['step'] ?? '' );
		$person_id = isset( $state['external_person_id'] ) ? (int) $state['external_person_id'] : 0;
		$item_id   = isset( $state['external_id'] ) ? (string) $state['external_id'] : '';
		$owner_id  = (int) $this->setting( 'owner_id' );

		// Passo 1 + 2: pessoa.
		if ( ! $person_id ) {
			if ( ! $ctx->can_continue() ) {
				return PushResult::retry( 'budget' );
			}
			$found = $this->find_person( $client, $lead );
			if ( $found instanceof PushResult ) {
				return $found;
			}
			if ( $found ) {
				$person_id = $found;
			} else {
				if ( ! $ctx->can_continue() ) {
					return PushResult::retry( 'budget' );
				}
				$payload = [
					'name'   => '' !== $lead->name ? $lead->name : PhoneBR::format( $lead->phone ),
					'phones' => [ [ 'value' => $lead->phone, 'primary' => true, 'label' => 'mobile' ] ],
				];
				if ( $lead->email ) {
					$payload['emails'] = [ [ 'value' => $lead->email, 'primary' => true, 'label' => 'work' ] ];
				}
				if ( $owner_id ) {
					$payload['owner_id'] = $owner_id;
				}
				$res = $client->post( '/api/v2/persons', $payload );
				if ( 201 !== $res['status'] && 200 !== $res['status'] ) {
					return $this->classify( $res, 'persons' );
				}
				$person_id = (int) ( $res['body']['data']['id'] ?? 0 );
				if ( ! $person_id ) {
					return PushResult::retry( 'persons_no_id', substr( $res['raw'], 0, 500 ) );
				}
			}
			$ctx->save_state( [ 'step' => self::STEP_PERSON, 'external_person_id' => (string) $person_id ] );
			$step = self::STEP_PERSON;
		}

		// Passo 3: lead ou negócio.
		if ( '' === $item_id ) {
			if ( ! $ctx->can_continue() ) {
				return PushResult::retry( 'budget', null, null, [ 'step' => $step, 'external_person_id' => (string) $person_id ] );
			}
			$title   = $this->render_title( $lead );
			$as_deal = 'deal' === $this->setting( 'create_as' );
			$utm     = $this->utm_custom_fields( $lead );
			if ( $as_deal ) {
				$payload = [ 'title' => $title, 'person_id' => $person_id ];
				if ( (int) $this->setting( 'pipeline_id' ) ) {
					$payload['pipeline_id'] = (int) $this->setting( 'pipeline_id' );
				}
				if ( (int) $this->setting( 'stage_id' ) ) {
					$payload['stage_id'] = (int) $this->setting( 'stage_id' );
				}
				if ( $owner_id ) {
					$payload['owner_id'] = $owner_id;
				}
				// Negócios usam a v2: campos personalizados vão aninhados em custom_fields.
				if ( $utm ) {
					$payload['custom_fields'] = $utm;
				}
				$payload = (array) apply_filters( 'whatsalp_lead_payload_pipedrive', $payload, $lead, 'deal' );
				$res     = $client->post( '/api/v2/deals', $payload );
			} else {
				$payload = [ 'title' => $title, 'person_id' => $person_id ];
				if ( '' !== (string) $this->setting( 'label_id' ) ) {
					$payload['label_ids'] = [ (string) $this->setting( 'label_id' ) ];
				}
				if ( $owner_id ) {
					$payload['owner_id'] = $owner_id;
				}
				// Leads usam a v1: a hash do campo é a própria chave na raiz do corpo.
				foreach ( $utm as $hash => $value ) {
					if ( ! isset( $payload[ $hash ] ) ) {
						$payload[ $hash ] = $value;
					}
				}
				$payload = (array) apply_filters( 'whatsalp_lead_payload_pipedrive', $payload, $lead, 'lead' );
				$res     = $client->post( '/v1/leads', $payload );
			}
			if ( 201 !== $res['status'] && 200 !== $res['status'] ) {
				return $this->classify( $res, $as_deal ? 'deals' : 'leads', [ 'step' => self::STEP_PERSON, 'external_person_id' => (string) $person_id ] );
			}
			$item_id = (string) ( $res['body']['data']['id'] ?? '' );
			if ( '' === $item_id ) {
				return PushResult::retry( 'item_no_id', substr( $res['raw'], 0, 500 ), null, [ 'step' => self::STEP_PERSON, 'external_person_id' => (string) $person_id ] );
			}
			$ctx->save_state( [ 'step' => self::STEP_ITEM, 'external_id' => $item_id ] );
			$step = self::STEP_ITEM;
		}

		// Passo 4: nota. Falha aqui não repete os anteriores.
		$final_state = [ 'step' => self::STEP_NOTE, 'external_person_id' => (string) $person_id ];
		if ( self::STEP_NOTE !== $step ) {
			if ( ! $ctx->can_continue() ) {
				return PushResult::retry( 'budget', null, null, [ 'step' => self::STEP_ITEM, 'external_person_id' => (string) $person_id ] );
			}
			$note = [ 'content' => $this->render_note( $lead ) ];
			if ( 'deal' === $this->setting( 'create_as' ) ) {
				$note['deal_id'] = (int) $item_id;
			} else {
				$note['lead_id'] = $item_id;
			}
			$res = $client->post( '/v1/notes', $note );
			if ( 201 !== $res['status'] && 200 !== $res['status'] ) {
				$final_state['warning'] = 'note_failed';
			}
		}
		return PushResult::success( $item_id, $final_state );
	}

	/**
	 * @return int|PushResult|null id da pessoa, null se não achou, PushResult em erro.
	 */
	private function find_person( PipedriveClient $client, Lead $lead ) {
		if ( $lead->email ) {
			$res = $client->get( '/api/v2/persons/search', [ 'term' => $lead->email, 'fields' => 'email', 'exact_match' => 'true', 'limit' => 1 ] );
			if ( 200 !== $res['status'] ) {
				return $this->classify( $res, 'persons/search' );
			}
			$id = (int) ( $res['body']['data']['items'][0]['item']['id'] ?? 0 );
			if ( $id ) {
				return $id;
			}
		}
		foreach ( PhoneBR::search_variants( $lead->phone ) as $variant ) {
			$res = $client->get( '/api/v2/persons/search', [ 'term' => $variant, 'fields' => 'phone', 'exact_match' => 'true', 'limit' => 1 ] );
			if ( 200 !== $res['status'] ) {
				return $this->classify( $res, 'persons/search' );
			}
			$id = (int) ( $res['body']['data']['items'][0]['item']['id'] ?? 0 );
			if ( $id ) {
				return $id;
			}
		}
		return null;
	}

	/**
	 * @param array{status:int, body:array<string,mixed>|null, raw:string, retry_after:?int, error:?string} $res
	 * @param array<string,mixed> $state
	 */
	private function classify( array $res, string $where, array $state = [] ): PushResult {
		$status  = $res['status'];
		$excerpt = $where . ': ' . ( $res['error'] ?? substr( $res['raw'], 0, 400 ) );
		if ( 0 === $status || 408 === $status || 425 === $status || $status >= 500 ) {
			return PushResult::retry( 0 === $status ? 'network' : (string) $status, $excerpt, null, $state );
		}
		if ( 429 === $status ) {
			return PushResult::retry( '429', $excerpt, $res['retry_after'] ?? 60, $state );
		}
		if ( 401 === $status || 403 === $status ) {
			return PushResult::failure( (string) $status, $excerpt, $state, true );
		}
		return PushResult::failure( (string) $status, $excerpt, $state );
	}

	public function render_title( Lead $lead ): string {
		$tpl   = (string) ( $this->setting( 'title_template' ) ?: '{nome} · Site' );
		$title = trim(
			strtr(
				$tpl,
				[
					'{nome}'     => $lead->name ?: PhoneBR::format( $lead->phone ),
					'{telefone}' => PhoneBR::format( $lead->phone ),
					'{email}'    => (string) $lead->email,
					'{empresa}'  => (string) $lead->company,
					'{opcao}'    => (string) $lead->menu_option,
					'{site}'     => wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES ),
					'{pagina}'   => (string) ( $lead->source_title ?: $lead->source_path ),
				]
			)
		) ?: 'Lead do site';
		if ( $this->setting( 'title_uppercase' ) ) {
			$title = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $title, 'UTF-8' ) : strtoupper( $title );
		}
		return (string) apply_filters( 'whatsalp_pipedrive_title', $title, $lead, $this );
	}

	private function render_note( Lead $lead ): string {
		$lines = [
			'<b>' . esc_html__( 'Lead capturado pelo WhatsAlp', 'whatsalp' ) . '</b>',
			esc_html__( 'Empresa:', 'whatsalp' ) . ' ' . esc_html( (string) ( $lead->company ?: '-' ) ),
			$lead->menu_option ? esc_html__( 'Escolheu:', 'whatsalp' ) . ' ' . esc_html( $lead->menu_option ) : '',
			esc_html__( 'Página:', 'whatsalp' ) . ' ' . esc_html( (string) ( $lead->source_title ?: '-' ) ) . ( $lead->source_url ? ' (' . esc_html( $lead->source_url ) . ')' : '' ),
			esc_html__( 'Data:', 'whatsalp' ) . ' ' . esc_html( wp_date( 'd/m/Y H:i', strtotime( $lead->created_at . ' UTC' ) ) ),
			esc_html__( 'Consentimento:', 'whatsalp' ) . ' ' . ( $lead->consent ? esc_html__( 'aceito', 'whatsalp' ) : esc_html__( 'não', 'whatsalp' ) ),
		];
		foreach ( $lead->utm as $k => $v ) {
			$lines[] = esc_html( $k ) . ': ' . esc_html( $v );
		}
		return implode( '<br>', array_filter( $lines ) );
	}
}
