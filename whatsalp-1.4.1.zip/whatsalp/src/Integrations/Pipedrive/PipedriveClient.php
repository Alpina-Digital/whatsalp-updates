<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations\Pipedrive;

/**
 * Cliente HTTP mínimo. Versão fixada por recurso: v2 para persons/deals,
 * v1 para leads, leadLabels, notes e users/me. Token no header x-api-token.
 */
final class PipedriveClient {

	public const TIMEOUT = 8;

	private string $token;
	private string $base;

	public function __construct( string $token, string $company_domain = '' ) {
		$this->token = $token;
		$domain      = preg_replace( '/[^a-z0-9-]/', '', strtolower( $company_domain ) ) ?: '';
		$this->base  = '' !== $domain ? "https://{$domain}.pipedrive.com" : 'https://api.pipedrive.com';
	}

	/**
	 * @param array<string,mixed> $query
	 * @return array{status:int, body:array<string,mixed>|null, raw:string, retry_after:?int, error:?string}
	 */
	public function get( string $path, array $query = [] ): array {
		return $this->request( 'GET', $path, $query, null );
	}

	/**
	 * @param array<string,mixed> $payload
	 * @return array{status:int, body:array<string,mixed>|null, raw:string, retry_after:?int, error:?string}
	 */
	public function post( string $path, array $payload ): array {
		return $this->request( 'POST', $path, [], $payload );
	}

	/**
	 * @param array<string,mixed> $query
	 * @param array<string,mixed>|null $payload
	 * @return array{status:int, body:array<string,mixed>|null, raw:string, retry_after:?int, error:?string}
	 */
	private function request( string $method, string $path, array $query, ?array $payload ): array {
		$url  = $this->base . $path . ( $query ? '?' . http_build_query( $query ) : '' );
		$args = [
			'method'  => $method,
			'timeout' => self::TIMEOUT,
			'headers' => [
				'Accept'      => 'application/json',
				'x-api-token' => $this->token,
			],
		];
		if ( null !== $payload ) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode( $payload );
		}
		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return [ 'status' => 0, 'body' => null, 'raw' => '', 'retry_after' => null, 'error' => $res->get_error_message() ];
		}
		$raw         = (string) wp_remote_retrieve_body( $res );
		$body        = json_decode( $raw, true );
		$retry_after = wp_remote_retrieve_header( $res, 'retry-after' );
		return [
			'status'      => (int) wp_remote_retrieve_response_code( $res ),
			'body'        => is_array( $body ) ? $body : null,
			'raw'         => $raw,
			'retry_after' => '' !== $retry_after && is_numeric( $retry_after ) ? (int) $retry_after : null,
			'error'       => null,
		];
	}
}
