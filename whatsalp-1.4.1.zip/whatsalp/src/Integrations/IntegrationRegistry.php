<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

use WhatsAlp\Integrations\Pipedrive\PipedriveIntegration;
use WhatsAlp\Integrations\Webhook\WebhookIntegration;

/**
 * Descobre integrações via filtro whatsalp_integrations, resolvido de forma
 * lazy no primeiro uso (após init), para add-ons carregados depois não sumirem.
 */
final class IntegrationRegistry {

	/** @var array<string,IntegrationInterface>|null */
	private static ?array $items = null;

	public function register(): void {
		add_filter( 'whatsalp_integrations', [ $this, 'core_integrations' ], 5 );
	}

	/**
	 * @param array<string,IntegrationInterface> $items
	 * @return array<string,IntegrationInterface>
	 */
	public function core_integrations( array $items ): array {
		foreach ( [ new PipedriveIntegration(), new WebhookIntegration() ] as $integration ) {
			$items[ $integration->id() ] = $integration;
		}
		return $items;
	}

	/**
	 * @return array<string,IntegrationInterface>
	 */
	public static function all(): array {
		if ( null === self::$items ) {
			$items       = apply_filters( 'whatsalp_integrations', [] );
			self::$items = [];
			foreach ( (array) $items as $item ) {
				if ( $item instanceof IntegrationInterface ) {
					self::$items[ $item->id() ] = $item;
				}
			}
		}
		return self::$items;
	}

	public static function get( string $id ): ?IntegrationInterface {
		return self::all()[ $id ] ?? null;
	}

	/**
	 * @return array<string,IntegrationInterface>
	 */
	public static function active(): array {
		return array_filter( self::all(), static fn( IntegrationInterface $i ) => $i->is_enabled() );
	}

	public static function flush(): void {
		self::$items = null;
	}
}
