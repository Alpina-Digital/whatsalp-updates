<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

final class PushResult {

	public bool $ok;
	public ?string $external_id;
	public ?string $error_code;
	public bool $retryable;
	public ?int $retry_after;
	public ?string $response_excerpt;
	/** @var array<string,mixed> Persistido em sync_log (step, external_person_id...). */
	public array $state;
	public bool $auth_failed;

	/**
	 * @param array<string,mixed> $state
	 */
	private function __construct( bool $ok, ?string $external_id, ?string $error_code, bool $retryable, ?int $retry_after, ?string $excerpt, array $state, bool $auth_failed ) {
		$this->ok               = $ok;
		$this->external_id      = $external_id;
		$this->error_code       = $error_code;
		$this->retryable        = $retryable;
		$this->retry_after      = $retry_after;
		$this->response_excerpt = $excerpt;
		$this->state            = $state;
		$this->auth_failed      = $auth_failed;
	}

	/**
	 * @param array<string,mixed> $state
	 */
	public static function success( ?string $external_id = null, array $state = [], ?string $excerpt = null ): self {
		return new self( true, $external_id, null, false, null, $excerpt, $state, false );
	}

	/**
	 * @param array<string,mixed> $state
	 */
	public static function retry( string $error_code, ?string $excerpt = null, ?int $retry_after = null, array $state = [] ): self {
		return new self( false, null, $error_code, true, $retry_after, $excerpt, $state, false );
	}

	/**
	 * @param array<string,mixed> $state
	 */
	public static function failure( string $error_code, ?string $excerpt = null, array $state = [], bool $auth_failed = false ): self {
		return new self( false, null, $error_code, false, null, $excerpt, $state, $auth_failed );
	}

	public static function skipped( string $reason ): self {
		return new self( false, null, 'skipped:' . $reason, false, null, null, [], false );
	}

	public function is_rate_limited(): bool {
		return $this->retryable && '429' === $this->error_code;
	}
}
