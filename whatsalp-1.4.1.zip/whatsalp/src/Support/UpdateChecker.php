<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

/**
 * Atualizações fora do WP.org: JSON estático da Alpina com sha256 do zip.
 */
final class UpdateChecker {

	public const METADATA_URL = 'https://alpina-digital.github.io/whatsalp-updates/latest.json';

	public function register(): void {
		if ( ! class_exists( PucFactory::class ) ) {
			// Pacote instalado sem vendor/: avisa em vez de falhar em silêncio (o cliente nunca receberia atualização).
			if ( ! defined( 'WP_TESTS_DOMAIN' ) ) {
				add_action(
					'admin_notices',
					static function (): void {
						if ( current_user_can( 'manage_options' ) ) {
							echo '<div class="notice notice-warning"><p><strong>WhatsAlp:</strong> ' . esc_html__( 'o verificador de atualizações não foi carregado (pasta vendor ausente). Reinstale o plugin a partir do pacote oficial.', 'whatsalp' ) . '</p></div>';
						}
					}
				);
			}
			return;
		}
		// Desligado em testes automatizados e por filtro (ex.: staging sem acesso externo).
		if ( ! apply_filters( 'whatsalp_enable_update_checker', ! defined( 'WP_TESTS_DOMAIN' ) ) ) {
			return;
		}
		$url     = (string) apply_filters( 'whatsalp_update_metadata_url', self::METADATA_URL );
		$checker = PucFactory::buildUpdateChecker( $url, WHATSALP_FILE, 'whatsalp' );
		add_filter( 'upgrader_pre_download', [ $this, 'verify_hash' ], 10, 3 );
		$this->checker = $checker;
	}

	/** @var object|null */
	private $checker = null;

	/**
	 * Verifica o sha256 publicado no JSON antes de instalar.
	 *
	 * @param mixed $reply
	 * @return mixed
	 */
	public function verify_hash( $reply, string $package, \WP_Upgrader $upgrader ) {
		if ( ! $this->checker || ! str_contains( $package, 'whatsalp' ) ) {
			return $reply;
		}
		$update = method_exists( $this->checker, 'getUpdate' ) ? $this->checker->getUpdate() : null;
		$hash   = $update && isset( $update->sha256 ) ? (string) $update->sha256 : '';
		if ( '' === $hash || ! $update || $update->download_url !== $package ) {
			return $reply;
		}
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		if ( ! hash_equals( strtolower( $hash ), hash_file( 'sha256', $file ) ) ) {
			wp_delete_file( $file );
			return new \WP_Error( 'whatsalp_bad_hash', __( 'O pacote de atualização do WhatsAlp não passou na verificação de integridade.', 'whatsalp' ) );
		}
		return $file;
	}
}
