<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

/**
 * Contador por dia em transient de 48 h: sem reescrever option a cada request.
 * Serve ao Site Health, que só precisa saber se algo aconteceu nas últimas 24 h.
 */
final class DailyCounter {

	public static function bump( string $prefix ): void {
		$key = self::key( $prefix, gmdate( 'Ymd' ) );
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, 'whatsalp', 2 * DAY_IN_SECONDS );
			wp_cache_incr( $key, 1, 'whatsalp' );
			return;
		}
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, 2 * DAY_IN_SECONDS );
	}

	public static function last_24h( string $prefix ): int {
		$total = 0;
		foreach ( [ gmdate( 'Ymd' ), gmdate( 'Ymd', time() - DAY_IN_SECONDS ) ] as $day ) {
			$key    = self::key( $prefix, $day );
			$total += wp_using_ext_object_cache() ? (int) wp_cache_get( $key, 'whatsalp' ) : (int) get_transient( $key );
		}
		return $total;
	}

	private static function key( string $prefix, string $day ): string {
		return 'whatsalp_' . $prefix . '_' . $day;
	}
}
