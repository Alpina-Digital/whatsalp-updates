<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

use WhatsAlp\Settings\Settings;

/**
 * Log de depuração com PII mascarada, em uploads/whatsalp-logs/, rotação em 5 MB.
 */
final class Logger {

	private const MAX_BYTES = 5 * 1024 * 1024;

	public static function enabled(): bool {
		return ( defined( 'WHATSALP_DEBUG' ) && constant( 'WHATSALP_DEBUG' ) ) || (bool) Settings::get( 'debug_log' );
	}

	/**
	 * @param array<string,mixed> $context
	 */
	public static function log( string $level, string $message, array $context = [] ): void {
		if ( ! self::enabled() ) {
			return;
		}
		$file = self::file();
		if ( ! $file ) {
			return;
		}
		if ( is_file( $file ) && filesize( $file ) > self::MAX_BYTES ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename, WordPress.PHP.NoSilencedErrors.Discouraged -- log é acessório: nunca deve interromper o request.
			@rename( $file, $file . '.1' );
		}
		$line = sprintf(
			"[%s] %s: %s %s\n",
			gmdate( 'Y-m-d H:i:s' ),
			strtoupper( $level ),
			self::mask( $message ),
			$context ? self::mask( (string) wp_json_encode( $context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) : ''
		);
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged -- log é acessório: nunca deve interromper o request.
		@file_put_contents( $file, $line, FILE_APPEND | LOCK_EX );
	}

	/**
	 * @param array<string,mixed> $context
	 */
	public static function info( string $message, array $context = [] ): void {
		self::log( 'info', $message, $context );
	}

	/**
	 * @param array<string,mixed> $context
	 */
	public static function error( string $message, array $context = [] ): void {
		self::log( 'error', $message, $context );
	}

	public static function mask( string $text ): string {
		$text = preg_replace_callback(
			'/[\w.+-]+@[\w-]+\.[\w.-]+/',
			static fn( array $m ) => substr( $m[0], 0, 2 ) . '***@' . substr( $m[0], (int) strrpos( $m[0], '@' ) + 1 ),
			$text
		) ?? $text;
		// Só telefones BR (55 + 10/11 dígitos): não mangles IDs numéricos do CRM.
		return preg_replace( '/\b(\+?55\d{2})\d{5,7}(\d{2})\b/', '$1******$2', $text ) ?? $text;
	}

	public static function file(): ?string {
		$dir = self::dir();
		if ( ! $dir ) {
			return null;
		}
		return $dir . '/whatsalp-' . substr( hash( 'sha256', wp_salt( 'auth' ) . 'log' ), 0, 12 ) . '.log';
	}

	public static function dir(): ?string {
		$upload = wp_upload_dir();
		if ( ! empty( $upload['error'] ) ) {
			return null;
		}
		$dir = trailingslashit( $upload['basedir'] ) . 'whatsalp-logs';
		if ( ! is_dir( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				return null;
			}
			// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged -- proteção da pasta é best effort.
			@file_put_contents( $dir . '/index.html', '' );
			@file_put_contents( $dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n" );
			// phpcs:enable
		}
		return $dir;
	}
}
