<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

/**
 * A configuração do widget é inlinada no HTML (um objeto no `wp_footer`), então
 * uma página servida por cache continua entregando a configuração ANTIGA depois
 * que o admin salva — o visitante vê o menu desligado, o número velho, o texto
 * anterior. Salvar precisa, portanto, limpar o cache de página de quem estiver
 * instalado. Cada plugin tem seu próprio gatilho e todos são no-op quando ausentes.
 */
final class CachePurge {

	public function register(): void {
		add_action( 'update_option_' . \WhatsAlp\Settings\Settings::OPTION, [ self::class, 'purge' ] );
		add_action( 'update_option_' . \WhatsAlp\Integrations\AbstractIntegration::OPTION, [ self::class, 'purge' ] );
	}

	/**
	 * Limpa o cache de página inteiro: o widget aparece em qualquer URL, então
	 * não há como purgar só uma.
	 */
	public static function purge(): void {
		// LiteSpeed Cache.
		do_action( 'litespeed_purge_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		// WP Rocket.
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		// W3 Total Cache.
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}
		// WP Super Cache.
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
		}
		// WP-Optimize.
		if ( function_exists( 'wpo_cache_flush' ) ) {
			wpo_cache_flush();
		}
		// SiteGround Optimizer.
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
		}
		// Cache Enabler, Swift Performance, Hummingbird, Breeze, Nginx Helper.
		// Os nomes abaixo são de OUTROS plugins: prefixá-los com whatsalp_ não limparia nada.
		// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		do_action( 'cache_enabler_clear_complete_cache' );
		do_action( 'swift_performance_clear_all_cache' );
		do_action( 'wphb_clear_page_cache' );
		do_action( 'breeze_clear_all_cache' );
		do_action( 'rt_nginx_helper_purge_all' );
		// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		// Autoptimize (CSS/JS agregados).
		if ( class_exists( '\autoptimizeCache' ) && method_exists( '\autoptimizeCache', 'clearall' ) ) {
			\autoptimizeCache::clearall();
		}
		// Cache de objeto persistente (Redis/Memcached) usado como page cache por alguns hosts.
		do_action( 'whatsalp_purge_cache' );
		Logger::info( 'cache de página purgado após salvar' );
	}
}
