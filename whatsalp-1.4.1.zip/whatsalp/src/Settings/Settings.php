<?php
declare(strict_types=1);

namespace WhatsAlp\Settings;

/**
 * Leitura e escrita de whatsalp_settings (um único array, autoload yes).
 * O sanitizador faz merge com os DEFAULTS, não com o valor anterior:
 * checkbox desmarcado some do POST e precisa virar false.
 */
final class Settings {

	public const OPTION = 'whatsalp_settings';

	/** @var array<string,mixed>|null */
	private static ?array $cache = null;

	public function register(): void {
		register_setting(
			'whatsalp',
			self::OPTION,
			[
				'type'              => 'array',
				'sanitize_callback' => [ self::class, 'sanitize' ],
			]
		);
		add_action( 'update_option_' . self::OPTION, [ self::class, 'flush' ] );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function defaults(): array {
		$out = [];
		foreach ( Schema::fields() as $key => $field ) {
			$out[ $key ] = Schema::resolve_default( $field['default'] );
		}
		return $out;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function all(): array {
		if ( null === self::$cache ) {
			$stored      = get_option( self::OPTION, [] );
			self::$cache = array_merge( self::defaults(), is_array( $stored ) ? $stored : [] );
		}
		return self::$cache;
	}

	/**
	 * @return mixed
	 */
	public static function get( string $key ) {
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	public static function flush(): void {
		self::$cache = null;
	}

	/**
	 * @param mixed $input
	 * @return array<string,mixed>
	 */
	public static function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : [];
		// Só o formulário do admin envia _form; nele, checkbox ausente = desmarcado.
		// Atualizações programáticas (WP-CLI, código) preservam o que não foi enviado.
		if ( empty( $input['_form'] ) ) {
			$current = get_option( self::OPTION, [] );
			$input   = array_merge( self::defaults(), is_array( $current ) ? $current : [], $input );
		}
		unset( $input['_form'] );
		$out   = [];
		foreach ( Schema::fields() as $key => $field ) {
			if ( Schema::TYPE_BOOL === $field['type'] ) {
				$out[ $key ] = ! empty( $input[ $key ] );
				continue;
			}
			$out[ $key ] = array_key_exists( $key, $input )
				? Schema::sanitize( $input[ $key ], $field )
				: Schema::resolve_default( $field['default'] );
		}
		// Telefone: só dígitos.
		$out['phone_country'] = preg_replace( '/\D+/', '', (string) $out['phone_country'] ) ?: '55';
		$out['phone_number']  = preg_replace( '/\D+/', '', (string) $out['phone_number'] ) ?? '';
		if ( '' !== $out['phone_number'] && strlen( $out['phone_number'] ) < 8 && function_exists( 'add_settings_error' ) ) {
			add_settings_error( self::OPTION, 'whatsalp_phone', __( 'O número do WhatsApp parece incompleto. Informe DDD e número, só dígitos.', 'whatsalp' ) );
		}
		return $out;
	}

	/**
	 * Número completo para o wa.me (sem +).
	 */
	public static function wa_number(): string {
		return self::get( 'phone_country' ) . self::get( 'phone_number' );
	}
}
