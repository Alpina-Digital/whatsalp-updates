<?php
declare(strict_types=1);

namespace WhatsAlp\Settings;

use WhatsAlp\Leads\Lead;
use WhatsAlp\Leads\PhoneBR;

/**
 * Menu de opções exibido antes do formulário: cada opção leva a um destino
 * próprio (WhatsApp com número/mensagem próprios, ou um link) e decide se
 * pede o formulário antes.
 *
 * O destino é sempre resolvido no servidor a partir do id da opção: o
 * visitante nunca escolhe a URL.
 */
final class OptionsMenu {

	public const TYPE_WHATSAPP = 'whatsapp';
	public const TYPE_LINK     = 'link';
	public const MAX_OPTIONS   = 8;

	/**
	 * Sanitiza a lista vinda do formulário do admin.
	 *
	 * @param mixed $value
	 * @return array<int, array<string,mixed>>
	 */
	public static function sanitize( $value ): array {
		if ( ! is_array( $value ) ) {
			return [];
		}
		$out = [];
		foreach ( $value as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}
			$label = mb_substr( sanitize_text_field( (string) ( $raw['label'] ?? '' ) ), 0, 80 );
			if ( '' === trim( $label ) ) {
				continue; // linha em branco do repetidor
			}
			$type   = self::TYPE_LINK === ( $raw['type'] ?? '' ) ? self::TYPE_LINK : self::TYPE_WHATSAPP;
			$option = [
				'id'      => self::make_id( $raw['id'] ?? '', $label, count( $out ) ),
				'label'   => $label,
				'type'    => $type,
				'form'    => ! empty( $raw['form'] ),
				'phone'   => '',
				'message' => '',
				'url'     => '',
				'new_tab' => ! empty( $raw['new_tab'] ),
				// Integrações que recebem esta opção. Ausente no POST = nenhuma marcada.
				'integrations' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $raw['integrations'] ?? [] ) ) ) ),
			];
			if ( self::TYPE_WHATSAPP === $type ) {
				$option['phone']   = preg_replace( '/\D+/', '', (string) ( $raw['phone'] ?? '' ) ) ?? '';
				$option['message'] = mb_substr( sanitize_text_field( (string) ( $raw['message'] ?? '' ) ), 0, 500 );
			} else {
				$url = esc_url_raw( trim( (string) ( $raw['url'] ?? '' ) ) );
				if ( '' === $url || false === wp_http_validate_url( $url ) ) {
					continue; // opção de link sem URL utilizável não entra
				}
				$option['url'] = $url;
			}
			$out[] = $option;
			if ( count( $out ) >= self::MAX_OPTIONS ) {
				break;
			}
		}
		return $out;
	}

	private static function make_id( string $current, string $label, int $index ): string {
		$id = sanitize_key( $current );
		if ( '' !== $id ) {
			return mb_substr( $id, 0, 32 );
		}
		$slug = sanitize_title( $label );
		return mb_substr( '' !== $slug ? $slug : 'opcao-' . ( $index + 1 ), 0, 32 );
	}

	/**
	 * Opções válidas e prontas para uso.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public static function options(): array {
		$options = Settings::get( 'menu_options' );
		return is_array( $options ) ? $options : [];
	}

	public static function is_active(): bool {
		return (bool) Settings::get( 'menu_enabled' ) && [] !== self::options();
	}

	/** O menu aparece depois do formulário? */
	public static function is_after_form(): bool {
		return 'after' === Settings::get( 'menu_position' );
	}

	/**
	 * Integrações que devem receber o lead desta opção.
	 * Sem menu ou sem opção escolhida ainda, todas as ativas recebem.
	 *
	 * @param array<string,mixed>|null $option
	 * @return string[]|null null = sem filtro
	 */
	public static function allowed_integrations( ?array $option ): ?array {
		if ( null === $option || ! isset( $option['integrations'] ) || ! is_array( $option['integrations'] ) ) {
			return null;
		}
		return $option['integrations'];
	}

	/**
	 * A opção escolhida por um lead já gravado.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function for_lead( \WhatsAlp\Leads\Lead $lead ): ?array {
		return $lead->menu_option_id ? self::find( (string) $lead->menu_option_id ) : null;
	}

	/**
	 * @return array<string,mixed>|null
	 */
	public static function find( string $id ): ?array {
		foreach ( self::options() as $option ) {
			if ( (string) $option['id'] === $id ) {
				return $option;
			}
		}
		return null;
	}

	/**
	 * A opção exige o formulário antes de liberar o destino?
	 *
	 * @param array<string,mixed>|null $option
	 */
	public static function requires_form( ?array $option ): bool {
		return null === $option ? true : ! empty( $option['form'] );
	}

	/**
	 * URL de destino final da opção (ou do padrão, quando não há opção).
	 *
	 * @param array<string,mixed>|null $option
	 */
	public static function destination( ?array $option, Lead $lead ): string {
		if ( null !== $option && self::TYPE_LINK === $option['type'] ) {
			return (string) $option['url'];
		}
		$number  = '';
		$message = '';
		if ( null !== $option ) {
			$number  = (string) $option['phone'];
			$message = (string) $option['message'];
		}
		if ( '' === $number ) {
			$number = Settings::wa_number();
		} elseif ( ! str_starts_with( $number, (string) Settings::get( 'phone_country' ) ) ) {
			$number = Settings::get( 'phone_country' ) . $number;
		}
		if ( '' === $message ) {
			$message = (string) Settings::get( 'wa_message' );
		}
		$text = self::render( $message, $lead );
		$text = (string) apply_filters( 'whatsalp_wa_message', $text, $lead );
		$url  = 'https://wa.me/' . $number;
		return '' === $text ? $url : $url . '?text=' . rawurlencode( $text );
	}

	/**
	 * Substitui as variáveis da mensagem de abertura.
	 */
	public static function render( string $template, Lead $lead ): string {
		return strtr(
			$template,
			[
				'{nome}'     => $lead->name,
				'{empresa}'  => (string) $lead->company,
				'{email}'    => (string) $lead->email,
				'{telefone}' => PhoneBR::format( $lead->phone ),
				'{opcao}'    => (string) $lead->menu_option,
				'{pagina}'   => (string) ( $lead->source_title ?: $lead->source_url ),
				'{site}'     => wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES ),
			]
		);
	}

	/**
	 * Versão pública (sem dados sensíveis) para o widget.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public static function public_options(): array {
		$out = [];
		foreach ( self::options() as $option ) {
			$is_link = self::TYPE_LINK === $option['type'];
			$number  = (string) $option['phone'];
			if ( '' === $number ) {
				$number = Settings::wa_number();
			} elseif ( ! str_starts_with( $number, (string) Settings::get( 'phone_country' ) ) ) {
				$number = Settings::get( 'phone_country' ) . $number;
			}
			$out[] = [
				'id'     => $option['id'],
				// 'integrations' fica de fora: é decisão de back-office, não interessa ao visitante.
				'label'  => $option['label'],
				'type'   => $option['type'],
				'form'   => (bool) $option['form'],
				// Destino é público de qualquer forma (o visitante será levado até ele) e o
				// widget precisa dele para a opção sem formulário e para o fallback offline.
				'url'    => $is_link ? $option['url'] : '',
				'number' => $is_link ? '' : $number,
				'message' => $is_link ? '' : ( '' !== (string) $option['message'] ? (string) $option['message'] : (string) Settings::get( 'wa_message' ) ),
				'newTab' => (bool) $option['new_tab'],
			];
		}
		return $out;
	}
}
