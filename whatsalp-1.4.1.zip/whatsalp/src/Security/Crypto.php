<?php
declare(strict_types=1);

namespace WhatsAlp\Security;

/**
 * Cifra segredos de integração em repouso.
 * Formato: v1:{key_id}:{base64(nonce . ciphertext)}.
 * Chave: WHATSALP_ENCRYPTION_KEY se definida, senão AUTH_KEY . SECURE_AUTH_KEY.
 * Ao decifrar com key_id diferente, tenta a chave legada e sinaliza para recifrar.
 */
final class Crypto {

	public const PREFIX = 'v1';

	/** @var string|null Indica que a última decifragem usou chave legada. */
	private static ?string $needs_rekey = null;

	public static function encrypt( string $plain ): string {
		$key   = self::key();
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$ct    = sodium_crypto_secretbox( $plain, $nonce, $key );
		return self::PREFIX . ':' . self::key_id( $key ) . ':' . base64_encode( $nonce . $ct );
	}

	/**
	 * @return string|null null quando não é possível decifrar.
	 */
	public static function decrypt( string $payload ): ?string {
		self::$needs_rekey = null;
		$parts             = explode( ':', $payload, 3 );
		if ( 3 !== count( $parts ) || self::PREFIX !== $parts[0] ) {
			return null;
		}
		[ , $key_id, $b64 ] = $parts;
		$raw                = base64_decode( $b64, true );
		if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return null;
		}
		$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$ct    = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );

		foreach ( self::candidate_keys() as $key ) {
			if ( self::key_id( $key ) !== $key_id ) {
				continue;
			}
			$plain = sodium_crypto_secretbox_open( $ct, $nonce, $key );
			if ( false !== $plain ) {
				if ( $key !== self::key() ) {
					self::$needs_rekey = $plain;
				}
				return $plain;
			}
		}
		return null;
	}

	/**
	 * Após decrypt(): payload recifrado com a chave atual, se a legada foi usada.
	 */
	public static function rekeyed_payload(): ?string {
		return null === self::$needs_rekey ? null : self::encrypt( self::$needs_rekey );
	}

	public static function key_id( string $key ): string {
		return substr( hash( 'sha256', 'whatsalp-key-id' . $key ), 0, 16 );
	}

	private static function key(): string {
		$material = defined( 'WHATSALP_ENCRYPTION_KEY' )
			? (string) constant( 'WHATSALP_ENCRYPTION_KEY' )
			: self::legacy_material();
		return hash( 'sha256', $material, true );
	}

	private static function legacy_material(): string {
		$auth   = defined( 'AUTH_KEY' ) ? (string) constant( 'AUTH_KEY' ) : '';
		$secure = defined( 'SECURE_AUTH_KEY' ) ? (string) constant( 'SECURE_AUTH_KEY' ) : '';
		return $auth . $secure;
	}

	/**
	 * @return string[]
	 */
	private static function candidate_keys(): array {
		$keys = [ self::key() ];
		if ( defined( 'WHATSALP_ENCRYPTION_KEY' ) ) {
			$keys[] = hash( 'sha256', self::legacy_material(), true );
		}
		return $keys;
	}
}
