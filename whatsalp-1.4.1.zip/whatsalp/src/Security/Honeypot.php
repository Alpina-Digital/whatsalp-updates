<?php
declare(strict_types=1);

namespace WhatsAlp\Security;

use WhatsAlp\Support\DailyCounter;

final class Honeypot {

	/** Nome não autofillável pelo navegador. */
	public const FIELD = 'website_url';

	private const COUNTER = 'hp_hit';

	/**
	 * @param array<string,mixed> $input
	 */
	public static function triggered( array $input ): bool {
		$hit = isset( $input[ self::FIELD ] ) && '' !== trim( (string) $input[ self::FIELD ] );
		if ( $hit ) {
			// O visitante vê uma tela de sucesso e nada é gravado: sem este contador,
			// um autofill no campo-armadilha some com os leads sem deixar rastro.
			DailyCounter::bump( self::COUNTER );
		}
		return $hit;
	}

	public static function hits_last_24h(): int {
		return DailyCounter::last_24h( self::COUNTER );
	}
}
