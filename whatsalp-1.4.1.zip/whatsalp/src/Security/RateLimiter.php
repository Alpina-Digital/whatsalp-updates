<?php
declare(strict_types=1);

namespace WhatsAlp\Security;

/**
 * Rate limit com janela fixa e incremento atômico.
 * Com object cache externo: wp_cache_add + wp_cache_incr.
 * Sem cache: UPSERT em uma option própria (uma linha por chave+janela),
 * limpa pelo DailyMaintenance.
 */
final class RateLimiter {

	public const PREFIX = 'whatsalp_rl_';
	private const GROUP = 'whatsalp';

	/**
	 * Incrementa e verifica. Retorna true quando o limite foi excedido.
	 */
	public static function hit( string $scope, string $subject, int $limit, int $window ): bool {
		$slot = intdiv( time(), max( 1, $window ) );
		$key  = self::PREFIX . $scope . '_' . substr( hash( 'sha256', $subject ), 0, 24 ) . '_' . $slot;
		return self::increment( $key, $window ) > $limit;
	}

	private static function increment( string $key, int $window ): int {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, self::GROUP, $window * 2 );
			$count = wp_cache_incr( $key, 1, self::GROUP );
			return false === $count ? 1 : (int) $count;
		}
		global $wpdb;
		// Atômico no banco: a concorrência não consegue ler 0 duas vezes.
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, '1', 'no')
				 ON DUPLICATE KEY UPDATE option_value = option_value + 1",
				$key
			)
		);
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Remove contadores de janelas antigas (sem cache externo, ficam em wp_options).
	 */
	public static function cleanup(): void {
		global $wpdb;
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( self::PREFIX ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$now  = time();
		foreach ( $rows as $name ) {
			$slot = (int) substr( (string) strrchr( (string) $name, '_' ), 1 );
			// Janelas de até 1 h; qualquer slot com mais de 2 h é lixo.
			if ( $slot > 0 && $slot * 60 < $now - 2 * HOUR_IN_SECONDS ) {
				delete_option( (string) $name );
			}
		}
	}
}
