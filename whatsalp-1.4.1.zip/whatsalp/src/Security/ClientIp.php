<?php
declare(strict_types=1);

namespace WhatsAlp\Security;

use WhatsAlp\Settings\Settings;

/**
 * Resolve o IP do visitante pelo algoritmo "rightmost untrusted":
 * percorre [X-Forwarded-For..., REMOTE_ADDR] da direita para a esquerda
 * descartando IPs confiáveis (privados, Cloudflare, lista do admin).
 */
final class ClientIp {

	/** Fallback embutido; atualizado diariamente em whatsalp_cf_ranges. */
	private const CF_V4 = [
		'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
		'141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
		'197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
		'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
	];
	private const CF_V6 = [
		'2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
		'2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
	];

	/**
	 * @param array<string,string> $server Normalmente $_SERVER.
	 * @return string|null IP público do cliente ou null se indeterminável.
	 */
	public static function resolve( ?array $server = null ): ?string {
		$server = $server ?? $_SERVER; // phpcs:ignore WordPress.Security
		$remote = self::clean( (string) ( $server['REMOTE_ADDR'] ?? '' ) );
		$chain  = [];
		if ( ! empty( $server['HTTP_X_FORWARDED_FOR'] ) ) {
			foreach ( explode( ',', (string) $server['HTTP_X_FORWARDED_FOR'] ) as $hop ) {
				$hop = self::clean( $hop );
				if ( $hop ) {
					$chain[] = $hop;
				}
			}
		}
		if ( $remote ) {
			$chain[] = $remote;
		}

		$result     = null;
		$prev_is_cf = false;
		for ( $i = count( $chain ) - 1; $i >= 0; $i-- ) {
			$ip = $chain[ $i ];
			if ( self::is_private( $ip ) || self::is_admin_trusted( $ip ) ) {
				continue;
			}
			if ( self::is_cloudflare( $ip ) ) {
				$prev_is_cf = true;
				continue;
			}
			$result = $ip;
			break;
		}

		if ( $prev_is_cf && ! empty( $server['HTTP_CF_CONNECTING_IP'] ) ) {
			$cf = self::clean( (string) $server['HTTP_CF_CONNECTING_IP'] );
			if ( $cf && ! self::is_private( $cf ) ) {
				$result = $cf;
			}
		}

		// Sem proxy declarado e REMOTE_ADDR público: ignora XFF (poderia ser forjado).
		if ( $remote && ! self::is_private( $remote ) && ! self::is_cloudflare( $remote ) && ! self::is_admin_trusted( $remote ) && ! Settings::get( 'behind_proxy' ) ) {
			$result = $remote;
		}

		/** @var string|null $result */
		$result = apply_filters( 'whatsalp_client_ip', $result, $chain, $server );
		return $result ?: null;
	}

	/**
	 * Chave de rate limit: IPv6 agrupado por /64.
	 */
	public static function bucket( string $ip ): string {
		if ( str_contains( $ip, ':' ) ) {
			$bin = inet_pton( $ip );
			if ( false !== $bin ) {
				return inet_ntop( substr( $bin, 0, 8 ) . str_repeat( "\0", 8 ) ) . '/64';
			}
		}
		return $ip;
	}

	public static function is_private( string $ip ): bool {
		return false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}

	public static function is_cloudflare( string $ip ): bool {
		$ranges = get_option( 'whatsalp_cf_ranges' );
		if ( ! is_array( $ranges ) || empty( $ranges ) ) {
			$ranges = array_merge( self::CF_V4, self::CF_V6 );
		}
		return self::in_ranges( $ip, $ranges );
	}

	private static function is_admin_trusted( string $ip ): bool {
		$list = (array) Settings::get( 'trusted_proxies' );
		return ! empty( $list ) && self::in_ranges( $ip, $list );
	}

	/**
	 * @param string[] $ranges CIDRs ou IPs.
	 */
	public static function in_ranges( string $ip, array $ranges ): bool {
		$bin = inet_pton( $ip );
		if ( false === $bin ) {
			return false;
		}
		foreach ( $ranges as $range ) {
			$range = trim( (string) $range );
			if ( '' === $range ) {
				continue;
			}
			[ $net, $bits ] = array_pad( explode( '/', $range, 2 ), 2, null );
			$net_bin        = inet_pton( $net );
			if ( false === $net_bin || strlen( $net_bin ) !== strlen( $bin ) ) {
				continue;
			}
			$bits = null === $bits ? strlen( $bin ) * 8 : min( (int) $bits, strlen( $bin ) * 8 );
			if ( self::prefix_match( $bin, $net_bin, $bits ) ) {
				return true;
			}
		}
		return false;
	}

	private static function prefix_match( string $a, string $b, int $bits ): bool {
		$bytes = intdiv( $bits, 8 );
		$rest  = $bits % 8;
		if ( $bytes > 0 && substr( $a, 0, $bytes ) !== substr( $b, 0, $bytes ) ) {
			return false;
		}
		if ( 0 === $rest ) {
			return true;
		}
		$mask = ( 0xFF << ( 8 - $rest ) ) & 0xFF;
		return ( ord( $a[ $bytes ] ) & $mask ) === ( ord( $b[ $bytes ] ) & $mask );
	}

	private static function clean( string $ip ): string {
		$ip = trim( $ip );
		if ( preg_match( '/^\[?([0-9a-f:.]+)\]?(?::\d+)?$/i', $ip, $m ) && str_contains( $m[1], ':' ) ) {
			$ip = $m[1];
		} elseif ( preg_match( '/^(\d{1,3}(?:\.\d{1,3}){3})(?::\d+)?$/', $ip, $m ) ) {
			$ip = $m[1];
		}
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}
}
