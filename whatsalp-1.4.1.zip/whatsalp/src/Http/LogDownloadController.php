<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Admin\Capabilities;
use WhatsAlp\Support\Logger;

final class LogDownloadController {

	public const ACTION = 'whatsalp_download_log';

	public function register(): void {
		add_action( 'admin_post_' . self::ACTION, [ $this, 'download' ] );
	}

	public function download(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'whatsalp' ), 403 );
		}
		check_admin_referer( self::ACTION );
		$file = Logger::file();
		if ( ! $file || ! is_file( $file ) ) {
			wp_die( esc_html__( 'Nenhum log disponível ainda.', 'whatsalp' ) );
		}
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="whatsalp-' . gmdate( 'Ymd-His' ) . '.log"' );
		readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}
}
