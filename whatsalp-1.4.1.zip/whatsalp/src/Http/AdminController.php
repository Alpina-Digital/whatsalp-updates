<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Admin\Capabilities;
use WhatsAlp\Integrations\AbstractIntegration;
use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Integrations\Pipedrive\PipedriveIntegration;
use WhatsAlp\Leads\LeadRepository;
use WhatsAlp\Support\Mailer;

/**
 * REST de admin: cookie + nonce + manage_whatsalp.
 */
final class AdminController {

	public function register(): void {
		add_action( 'rest_api_init', [ $this, 'routes' ] );
	}

	public function routes(): void {
		$perm = static fn() => current_user_can( Capabilities::CAP );
		register_rest_route(
			LeadController::NS,
			'/admin/integrations/(?P<id>[a-z_]+)/test',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'test' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/integrations/pipedrive/options',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'pipedrive_options' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/integrations/pipedrive/utm-fields',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'pipedrive_utm_fields' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/notify/test',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'notify_test' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/sync-log/(?P<id>\d+)/resend',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'resend' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/leads/(?P<id>\d+)/resync',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'resync_lead' ],
				'permission_callback' => $perm,
			]
		);
		register_rest_route(
			LeadController::NS,
			'/admin/leads/(?P<id>\d+)',
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_lead' ],
				'permission_callback' => $perm,
			]
		);
	}

	public function test( \WP_REST_Request $request ): \WP_REST_Response {
		$integration = IntegrationRegistry::get( (string) $request['id'] );
		if ( ! $integration ) {
			return new \WP_REST_Response( [ 'ok' => false, 'message' => 'not_found' ], 404 );
		}
		$result = $integration->test_connection();
		return new \WP_REST_Response(
			[
				'ok'      => $result->ok,
				'message' => $result->ok
					// translators: %s = detalhe da resposta ou código do erro.
					? sprintf( __( 'Conexão OK%s', 'whatsalp' ), $result->response_excerpt ? ' · ' . $result->response_excerpt : '' )
					// translators: %s = detalhe da resposta ou código do erro.
					: sprintf( __( 'Falha: %s', 'whatsalp' ), $result->response_excerpt ?: $result->error_code ),
			],
			200
		);
	}

	/**
	 * Usa os destinatários já salvos: o botão confirma o caminho real do e-mail,
	 * não o que ainda está no formulário.
	 */
	public function notify_test(): \WP_REST_Response {
		return new \WP_REST_Response( Mailer::send_test(), 200 );
	}

	public function pipedrive_options( \WP_REST_Request $request ): \WP_REST_Response {
		$integration = IntegrationRegistry::get( 'pipedrive' );
		if ( ! $integration instanceof PipedriveIntegration ) {
			return new \WP_REST_Response( [], 404 );
		}
		$refresh = ! empty( $request['refresh'] );
		return new \WP_REST_Response(
			[
				'pipelines'   => $integration->options( 'pipelines', $refresh ),
				'stages'      => $integration->options( 'stages', $refresh ),
				'users'       => $integration->options( 'users', $refresh ),
				'lead_labels' => $integration->options( 'lead_labels', $refresh ),
				'deal_fields' => $integration->options( 'deal_fields', $refresh ),
			],
			200
		);
	}

	/**
	 * Cria no Pipedrive os campos personalizados de UTM que faltarem e grava o mapeamento.
	 */
	public function pipedrive_utm_fields( \WP_REST_Request $request ): \WP_REST_Response {
		$integration = IntegrationRegistry::get( 'pipedrive' );
		if ( ! $integration instanceof PipedriveIntegration ) {
			return new \WP_REST_Response( [ 'ok' => false, 'message' => 'not_found' ], 404 );
		}
		$result = $integration->ensure_utm_fields();
		IntegrationRegistry::flush();
		return new \WP_REST_Response(
			[
				'ok'      => $result['ok'],
				'message' => $result['message'],
				'mapping' => $integration->utm_mapping(),
			],
			$result['ok'] ? 200 : 400
		);
	}

	public function resend( \WP_REST_Request $request ): \WP_REST_Response {
		$dispatcher = new Dispatcher();
		$as_new     = ! empty( $request['as_new'] );
		$ok         = $as_new ? $dispatcher->resend_as_new( (int) $request['id'] ) : $dispatcher->resend( (int) $request['id'] );
		if ( $ok ) {
			$row = ( new \WhatsAlp\Integrations\SyncLogRepository() )->find( (int) $request['id'] );
			if ( $row ) {
				$dispatcher->process( (int) $row['lead_id'], 10 );
			}
		}
		return new \WP_REST_Response( [ 'ok' => $ok ], $ok ? 200 : 400 );
	}

	public function resync_lead( \WP_REST_Request $request ): \WP_REST_Response {
		$id         = (int) $request['id'];
		$dispatcher = new Dispatcher();
		$dispatcher->enqueue_missing( $id );
		foreach ( ( new \WhatsAlp\Integrations\SyncLogRepository() )->for_lead( $id ) as $row ) {
			if ( in_array( $row['status'], [ 'error', 'skipped' ], true ) ) {
				$dispatcher->resend( (int) $row['id'] );
			}
		}
		$done = $dispatcher->process( $id, 10 );
		return new \WP_REST_Response( [ 'ok' => true, 'processed' => $done ], 200 );
	}

	public function delete_lead( \WP_REST_Request $request ): \WP_REST_Response {
		( new LeadRepository() )->delete( (int) $request['id'] );
		return new \WP_REST_Response( [ 'ok' => true ], 200 );
	}
}
