<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Support\DailyCounter;

/**
 * Origin obrigatório nos POST públicos, com período de observação de 14 dias.
 */
final class OriginCheck {

	private const COUNTER = 'origin_blk';

	/**
	 * @param array<string,string> $server
	 * @return bool true = permitido.
	 */
	public static function allowed( array $server ): bool {
		$origin = isset( $server['HTTP_ORIGIN'] ) ? trim( (string) $server['HTTP_ORIGIN'] ) : '';
		$ok     = '' !== $origin && self::matches( $origin );
		if ( $ok ) {
			return true;
		}
		if ( ! self::enforcing() ) {
			self::count_block();
			return true;
		}
		self::count_block();
		return false;
	}

	public static function enforcing(): bool {
		$default = (int) get_option( 'whatsalp_origin_enforce_from', 0 );
		if ( 0 === $default ) {
			$default = (int) get_option( 'whatsalp_installed_at', time() ) + 14 * DAY_IN_SECONDS;
			update_option( 'whatsalp_origin_enforce_from', $default, false );
		}
		return (bool) apply_filters( 'whatsalp_enforce_origin', time() >= $default );
	}

	public static function matches( string $origin ): bool {
		$host = strtolower( (string) wp_parse_url( $origin, PHP_URL_HOST ) );
		if ( '' === $host ) {
			return false;
		}
		$allowed = [];
		foreach ( [ home_url(), site_url() ] as $url ) {
			$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
			if ( $h ) {
				$allowed[] = $h;
				$allowed[] = str_starts_with( $h, 'www.' ) ? substr( $h, 4 ) : 'www.' . $h;
			}
		}
		foreach ( (array) get_allowed_http_origins() as $o ) {
			$h = strtolower( (string) wp_parse_url( (string) $o, PHP_URL_HOST ) );
			if ( $h ) {
				$allowed[] = $h;
			}
		}
		$allowed = array_merge( $allowed, (array) apply_filters( 'whatsalp_allowed_origins', [] ) );
		return in_array( $host, array_unique( $allowed ), true );
	}

	private static function count_block(): void {
		DailyCounter::bump( self::COUNTER );
	}

	public static function blocks_last_24h(): int {
		return DailyCounter::last_24h( self::COUNTER );
	}
}
