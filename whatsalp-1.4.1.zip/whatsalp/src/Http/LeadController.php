<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Leads\FormToken;
use WhatsAlp\Leads\LeadService;
use WhatsAlp\Security\ClientIp;
use WhatsAlp\Security\RateLimiter;

/**
 * REST público. permission_callback é __return_true; a autorização é feita
 * pelos tokens dentro do handler (sem nonce do WP, incompatível com cache).
 */
final class LeadController {

	public const NS = 'whatsalp/v1';

	private LeadService $service;

	public function __construct( ?LeadService $service = null ) {
		$this->service = $service ?? new LeadService();
	}

	public function register(): void {
		add_action( 'rest_api_init', [ $this, 'routes' ] );
	}

	public function routes(): void {
		register_rest_route(
			self::NS,
			'/leads',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'create' ],
				'permission_callback' => '__return_true',
			]
		);
		register_rest_route(
			self::NS,
			'/leads/(?P<id>\d+)/sync',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'sync' ],
				'permission_callback' => '__return_true',
			]
		);
		register_rest_route(
			self::NS,
			'/leads/(?P<id>\d+)/complete',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'complete' ],
				'permission_callback' => '__return_true',
			]
		);
		register_rest_route(
			self::NS,
			'/leads/(?P<id>\d+)/clicked',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'clicked' ],
				'permission_callback' => '__return_true',
			]
		);
		register_rest_route(
			self::NS,
			'/form-token',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'form_token' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create( \WP_REST_Request $request ) {
		return $this->respond( self::handle_create( $this->service, self::params( $request ), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	/**
	 * Lógica compartilhada com o fallback ajax.
	 *
	 * @param array<string,mixed> $input
	 * @param array<string,string> $server
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function handle_create( LeadService $service, array $input, array $server ) {
		if ( ! OriginCheck::allowed( $server ) ) {
			return new \WP_Error( 'whatsalp_bad_origin', __( 'Origem não permitida.', 'whatsalp' ), [ 'status' => 403 ] );
		}
		$token = FormToken::check( (string) ( $input['form_token'] ?? '' ) );
		if ( 'expired' === $token ) {
			return new \WP_Error( 'whatsalp_token_expired', __( 'Sessão expirada. Tentando novamente...', 'whatsalp' ), [ 'status' => 400 ] );
		}
		if ( 'ok' !== $token ) {
			return new \WP_Error( 'whatsalp_token_invalid', __( 'Não foi possível validar o formulário.', 'whatsalp' ), [ 'status' => 400 ] );
		}
		$result = $service->create( $input, $server );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$lead = $service->repository()->find( (int) $result['lead_id'] );
		if ( $lead ) {
			// Resposta já montada; o processamento acontece após o envio ao cliente.
			InternalTrigger::after_response(
				static function () use ( $service, $lead ): void {
					$service->trigger_after_response( $lead );
				}
			);
		}
		return $result;
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function sync( \WP_REST_Request $request ) {
		$params = self::params( $request );
		return $this->respond( self::handle_sync( $this->service, (int) $request['id'], (string) ( $params['lead_token'] ?? '' ), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	/**
	 * @param array<string,string> $server
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function handle_sync( LeadService $service, int $id, string $token, array $server ) {
		if ( ! OriginCheck::allowed( $server ) ) {
			return new \WP_Error( 'whatsalp_bad_origin', __( 'Origem não permitida.', 'whatsalp' ), [ 'status' => 403 ] );
		}
		$lead = $service->repository()->find_by_token( $id, $token );
		if ( ! $lead ) {
			return [ 'status' => 204 ];
		}
		// O caminho rápido pode ser chamado poucas vezes por lead; o resto fica com o sweeper e seu backoff.
		if ( RateLimiter::hit( 'sync', (string) $lead->id, 3, 10 * MINUTE_IN_SECONDS ) ) {
			return [ 'status' => 202, 'accepted' => true, 'deferred' => true ];
		}
		@ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		InternalTrigger::after_response(
			static function () use ( $service, $lead ): void {
				$service->sync( $lead );
			}
		);
		return [ 'status' => 202, 'accepted' => true ];
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function complete( \WP_REST_Request $request ) {
		$params = self::params( $request );
		return $this->respond( self::handle_complete( $this->service, (int) $request['id'], (string) ( $params['lead_token'] ?? '' ), $params, $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	/**
	 * @param array<string,mixed> $params
	 * @param array<string,string> $server
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function handle_complete( LeadService $service, int $id, string $token, array $params, array $server ) {
		if ( ! OriginCheck::allowed( $server ) ) {
			return new \WP_Error( 'whatsalp_bad_origin', __( 'Origem não permitida.', 'whatsalp' ), [ 'status' => 403 ] );
		}
		$lead = $service->repository()->find_by_token( $id, $token );
		if ( ! $lead ) {
			return [ 'status' => 204 ];
		}
		if ( RateLimiter::hit( 'complete', (string) $lead->id, 12, 10 * MINUTE_IN_SECONDS ) ) {
			return new \WP_Error( 'whatsalp_rate_limited', __( 'Muitas tentativas. Aguarde alguns minutos e tente de novo.', 'whatsalp' ), [ 'status' => 429 ] );
		}
		$result = $service->complete( $lead, $params );
		@ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		InternalTrigger::after_response(
			static function () use ( $service, $lead ): void {
				$service->sync( $lead );
			}
		);
		return $result;
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function clicked( \WP_REST_Request $request ) {
		$params = self::params( $request );
		return $this->respond( self::handle_clicked( $this->service, (int) $request['id'], (string) ( $params['lead_token'] ?? '' ), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	/**
	 * @param array<string,string> $server
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function handle_clicked( LeadService $service, int $id, string $token, array $server ) {
		if ( ! OriginCheck::allowed( $server ) ) {
			return new \WP_Error( 'whatsalp_bad_origin', __( 'Origem não permitida.', 'whatsalp' ), [ 'status' => 403 ] );
		}
		$lead = $service->repository()->find_by_token( $id, $token );
		if ( $lead ) {
			$service->clicked( $lead );
		}
		return [ 'status' => 204 ];
	}

	public function form_token( \WP_REST_Request $request ): \WP_REST_Response {
		nocache_headers();
		$ip = ClientIp::resolve( $_SERVER ); // phpcs:ignore WordPress.Security
		if ( $ip && RateLimiter::hit( 'token', ClientIp::bucket( $ip ), 30, 10 * MINUTE_IN_SECONDS ) ) {
			return new \WP_REST_Response( [ 'code' => 'whatsalp_rate_limited' ], 429 );
		}
		return new \WP_REST_Response( [ 'form_token' => FormToken::issue() ], 200 );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function params( \WP_REST_Request $request ): array {
		$json = $request->get_json_params();
		if ( is_array( $json ) && $json ) {
			return $json;
		}
		return (array) $request->get_body_params();
	}

	/**
	 * @param array<string,mixed>|\WP_Error $result
	 * @return \WP_REST_Response|\WP_Error
	 */
	private function respond( $result ) {
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$status = (int) ( $result['status'] ?? 200 );
		unset( $result['status'] );
		$response = new \WP_REST_Response( 204 === $status ? null : $result, $status );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}
}
