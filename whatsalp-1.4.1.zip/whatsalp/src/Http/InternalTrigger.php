<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Support\Logger;

/**
 * Processa o lead logo após a resposta: inline quando o SAPI permite encerrar
 * o request (fastcgi/litespeed), senão loopback não bloqueante para admin-ajax.
 */
final class InternalTrigger {

	public const ACTION = 'whatsalp_process';

	/** @var callable[] */
	private static array $after = [];
	private static bool $hooked = false;

	/**
	 * Agenda um callable para rodar depois que a resposta foi enviada.
	 */
	public static function after_response( callable $fn ): void {
		self::$after[] = $fn;
		if ( self::$hooked ) {
			return;
		}
		self::$hooked = true;
		// shutdown roda após o output; finish_request() libera o cliente antes.
		add_action( 'shutdown', [ self::class, 'run_after' ], 0 );
	}

	public static function run_after(): void {
		if ( ! self::$after ) {
			return;
		}
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		}
		@ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$queue       = self::$after;
		self::$after = [];
		foreach ( $queue as $fn ) {
			try {
				$fn();
			} catch ( \Throwable $e ) {
				Logger::error( 'after_response', [ 'error' => $e->getMessage() ] );
			}
		}
	}

	public static function can_finish_inline(): bool {
		return function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' );
	}

	/**
	 * Processa o lead: inline se o cliente já foi liberado, senão loopback.
	 */
	public static function fire( int $lead_id ): void {
		if ( apply_filters( 'whatsalp_disable_internal_trigger', false ) ) {
			return;
		}
		if ( self::can_finish_inline() ) {
			( new Dispatcher() )->process( $lead_id, 10 );
			return;
		}
		$ts   = (string) time();
		$body = [
			'action'  => self::ACTION,
			'lead_id' => $lead_id,
			'ts'      => $ts,
			'sig'     => self::sign( $lead_id, $ts ),
		];
		wp_remote_post(
			admin_url( 'admin-ajax.php' ),
			[
				'blocking'  => false,
				'timeout'   => 1,
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				'body'      => $body,
			]
		);
	}

	public static function sign( int $lead_id, string $ts ): string {
		return hash_hmac( 'sha256', 'whatsalp-process.' . $lead_id . '.' . $ts, wp_salt( 'auth' ) );
	}

	public static function verify( int $lead_id, string $ts, string $sig ): bool {
		if ( ! ctype_digit( $ts ) || abs( time() - (int) $ts ) > MINUTE_IN_SECONDS ) {
			return false;
		}
		return hash_equals( self::sign( $lead_id, $ts ), $sig );
	}
}
