<?php
declare(strict_types=1);

namespace WhatsAlp\Cron;

use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Integrations\SyncLogRepository;

final class SyncSweeper {

	public const HOOK     = 'whatsalp_sync_sweeper';
	public const SCHEDULE = 'whatsalp_five_minutes';

	public function register(): void {
		add_filter( 'cron_schedules', [ $this, 'schedules' ] ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		add_action( self::HOOK, [ $this, 'run' ] );
	}

	/**
	 * @param array<string, array<string,mixed>> $schedules
	 * @return array<string, array<string,mixed>>
	 */
	public function schedules( array $schedules ): array {
		$schedules[ self::SCHEDULE ] = [
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => 'WhatsAlp: a cada 5 minutos',
		];
		return $schedules;
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::SCHEDULE, self::HOOK );
		}
	}

	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public function run(): void {
		if ( apply_filters( 'whatsalp_disable_sweeper', false ) ) {
			return;
		}
		( new SyncLogRepository() )->housekeeping();
		$dispatcher = new Dispatcher();
		$deadline   = microtime( true ) + Dispatcher::BUDGET_SECONDS;
		// Lotes de 10 até esvaziar a fila ou estourar o orçamento do tick.
		do {
			$done = $dispatcher->process( null, 10, $deadline );
		} while ( 10 === $done && microtime( true ) < $deadline - 2 );
		update_option( 'whatsalp_last_sweep', time(), false );
	}
}
