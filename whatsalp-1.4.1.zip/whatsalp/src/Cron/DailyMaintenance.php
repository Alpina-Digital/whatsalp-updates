<?php
declare(strict_types=1);

namespace WhatsAlp\Cron;

use WhatsAlp\Integrations\SyncLogRepository;
use WhatsAlp\Leads\LeadRepository;
use WhatsAlp\Security\RateLimiter;
use WhatsAlp\Settings\Settings;

final class DailyMaintenance {

	public const HOOK = 'whatsalp_daily_maintenance';

	public function register(): void {
		add_action( self::HOOK, [ $this, 'run' ] );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
		}
	}

	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public function run(): void {
		$days = (int) Settings::get( 'retention_days' );
		if ( $days > 0 ) {
			( new LeadRepository() )->delete_older_than( $days );
		}
		( new SyncLogRepository() )->prune_success( 90 );
		$this->cleanup_transients();
		$this->refresh_cloudflare_ranges();
	}

	private function cleanup_transients(): void {
		RateLimiter::cleanup();
	}

	private function refresh_cloudflare_ranges(): void {
		$ranges = [];
		foreach ( [ 'https://www.cloudflare.com/ips-v4', 'https://www.cloudflare.com/ips-v6' ] as $url ) {
			$res = wp_remote_get( $url, [ 'timeout' => 8 ] );
			if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
				return; // mantém o que tem
			}
			foreach ( preg_split( '/\s+/', trim( wp_remote_retrieve_body( $res ) ) ) ?: [] as $cidr ) {
				if ( preg_match( '#^[0-9a-f:.]+/\d{1,3}$#i', $cidr ) ) {
					$ranges[] = $cidr;
				}
			}
		}
		if ( count( $ranges ) >= 10 ) {
			update_option( 'whatsalp_cf_ranges', $ranges, false );
		}
	}
}
