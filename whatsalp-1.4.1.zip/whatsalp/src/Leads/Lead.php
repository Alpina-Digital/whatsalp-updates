<?php
declare(strict_types=1);

namespace WhatsAlp\Leads;

final class Lead {

	public int $id = 0;
	public string $lead_token = '';
	public string $name = '';
	public string $phone = '';
	public ?string $phone_raw = null;
	public ?string $email = null;
	public ?string $company = null;
	public ?string $menu_option = null;
	public ?string $menu_option_id = null;
	public ?string $source_url = null;
	public ?string $source_path = null;
	public ?string $source_title = null;
	/** @var array<string,string> */
	public array $utm = [];
	public bool $consent = false;
	public ?string $consent_text = null;
	public ?string $consent_policy_url = null;
	public ?string $ip_hash = null;
	public ?string $user_agent = null;
	public string $sync_status = 'none';
	public ?string $wa_clicked_at = null;
	public string $created_at = '';

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		$lead = new self();
		foreach ( $row as $key => $value ) {
			if ( ! property_exists( $lead, (string) $key ) ) {
				continue;
			}
			if ( 'utm' === $key ) {
				$decoded   = is_string( $value ) ? json_decode( $value, true ) : null;
				$lead->utm = is_array( $decoded ) ? $decoded : [];
			} elseif ( 'id' === $key ) {
				$lead->id = (int) $value;
			} elseif ( 'consent' === $key ) {
				$lead->consent = (bool) $value;
			} else {
				$lead->{$key} = null === $value ? null : (string) $value;
			}
		}
		return $lead;
	}

	public function first_name(): string {
		$parts = preg_split( '/\s+/', trim( $this->name ) ) ?: [];
		return $parts[0] ?? '';
	}

	/**
	 * @return array<string,mixed>
	 */
	public function to_array(): array {
		return [
			'id'                 => $this->id,
			'name'               => $this->name,
			'phone'              => $this->phone,
			'phone_formatted'    => PhoneBR::format( $this->phone ),
			'email'              => $this->email,
			'company'            => $this->company,
			'menu_option'        => $this->menu_option,
			'menu_option_id'     => $this->menu_option_id,
			'source_url'         => $this->source_url,
			'source_path'        => $this->source_path,
			'source_title'       => $this->source_title,
			'utm'                => $this->utm,
			'consent'            => $this->consent,
			'consent_text'       => $this->consent_text,
			'consent_policy_url' => $this->consent_policy_url,
			'created_at'         => $this->created_at,
		];
	}
}
