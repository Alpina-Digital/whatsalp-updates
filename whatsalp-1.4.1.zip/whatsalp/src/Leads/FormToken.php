<?php
declare(strict_types=1);

namespace WhatsAlp\Leads;

/**
 * Token HMAC com timestamp embutido na página. Expirado não é 403: o widget
 * pede outro. Invalida payloads raspados e páginas cacheadas há dias.
 */
final class FormToken {

	public const TTL = DAY_IN_SECONDS;

	public static function issue( ?int $now = null ): string {
		$ts = (string) ( $now ?? time() );
		return rtrim( strtr( base64_encode( $ts . '.' . self::sign( $ts ) ), '+/', '-_' ), '=' );
	}

	/**
	 * @return string 'ok' | 'expired' | 'invalid'
	 */
	public static function check( string $token, ?int $now = null ): string {
		$raw = base64_decode( strtr( $token, '-_', '+/' ), true );
		if ( false === $raw || ! str_contains( $raw, '.' ) ) {
			return 'invalid';
		}
		[ $ts, $sig ] = explode( '.', $raw, 2 );
		if ( ! ctype_digit( $ts ) || ! hash_equals( self::sign( $ts ), $sig ) ) {
			return 'invalid';
		}
		$age = ( $now ?? time() ) - (int) $ts;
		if ( $age < -300 || $age > self::TTL ) {
			return 'expired';
		}
		return 'ok';
	}

	private static function sign( string $ts ): string {
		return hash_hmac( 'sha256', 'whatsalp-form.' . $ts, wp_salt( 'nonce' ) );
	}
}
