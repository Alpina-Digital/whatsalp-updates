<?php
declare(strict_types=1);

namespace WhatsAlp\Leads;

/**
 * Normalização de telefone brasileiro para o formato do wa.me: 55 + DDD + número.
 */
final class PhoneBR {

	private const DDDS = [
		11, 12, 13, 14, 15, 16, 17, 18, 19,
		21, 22, 24, 27, 28,
		31, 32, 33, 34, 35, 37, 38,
		41, 42, 43, 44, 45, 46, 47, 48, 49,
		51, 53, 54, 55,
		61, 62, 63, 64, 65, 66, 67, 68, 69,
		71, 73, 74, 75, 77, 79,
		81, 82, 83, 84, 85, 86, 87, 88, 89,
		91, 92, 93, 94, 95, 96, 97, 98, 99,
	];

	/**
	 * @return string|null Dígitos com DDI (ex.: 5511999999999) ou null se inválido.
	 */
	public static function normalize( string $raw ): ?string {
		$digits = preg_replace( '/\D+/', '', $raw ) ?? '';
		if ( '' === $digits ) {
			return null;
		}
		if ( str_starts_with( $digits, '55' ) && in_array( strlen( $digits ) - 2, [ 10, 11 ], true ) ) {
			$digits = substr( $digits, 2 );
		}
		if ( str_starts_with( $digits, '0' ) && in_array( strlen( $digits ) - 1, [ 10, 11 ], true ) ) {
			$digits = substr( $digits, 1 );
		}
		$len = strlen( $digits );
		if ( 10 !== $len && 11 !== $len ) {
			return null;
		}
		$ddd = (int) substr( $digits, 0, 2 );
		if ( ! in_array( $ddd, self::DDDS, true ) ) {
			return null;
		}
		$third = (int) $digits[2];
		if ( 11 === $len && 9 !== $third ) {
			return null;
		}
		if ( 10 === $len && ( $third < 2 || $third > 5 ) ) {
			return null;
		}
		return '55' . $digits;
	}

	/**
	 * Variantes para busca em CRMs (E.164 sem +, nacional).
	 *
	 * @return string[]
	 */
	public static function search_variants( string $normalized ): array {
		$national = str_starts_with( $normalized, '55' ) ? substr( $normalized, 2 ) : $normalized;
		return array_values( array_unique( [ $normalized, $national, '+' . $normalized ] ) );
	}

	/**
	 * +55 11 99999-9999
	 */
	public static function format( string $normalized ): string {
		if ( ! preg_match( '/^55(\d{2})(\d{4,5})(\d{4})$/', $normalized, $m ) ) {
			return $normalized;
		}
		return sprintf( '+55 %s %s-%s', $m[1], $m[2], $m[3] );
	}
}
