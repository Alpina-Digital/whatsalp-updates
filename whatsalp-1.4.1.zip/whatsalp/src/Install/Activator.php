<?php
declare(strict_types=1);

namespace WhatsAlp\Install;

use WhatsAlp\Cron\DailyMaintenance;
use WhatsAlp\Cron\SyncSweeper;
use WhatsAlp\Settings\Settings;

final class Activator {

	public static function activate( bool $network_wide = false ): void {
		if ( $network_wide && is_multisite() ) {
			foreach ( get_sites( [ 'number' => 0, 'fields' => 'ids' ] ) as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::activate_single();
				restore_current_blog();
			}
			return;
		}
		self::activate_single();
	}

	public static function activate_single(): void {
		Schema::create_tables();
		if ( null === get_option( Settings::OPTION, null ) ) {
			add_option( Settings::OPTION, Settings::defaults(), '', 'yes' );
		}
		if ( false === get_option( 'whatsalp_installed_at' ) ) {
			add_option( 'whatsalp_installed_at', time(), '', 'no' );
		}
		SyncSweeper::schedule();
		DailyMaintenance::schedule();
	}

	/**
	 * Novo site criado em multisite (hook wp_initialize_site, prioridade 100).
	 */
	public static function on_new_site( \WP_Site $site ): void {
		if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		if ( ! is_plugin_active_for_network( WHATSALP_BASENAME ) ) {
			return;
		}
		switch_to_blog( (int) $site->blog_id );
		self::activate_single();
		restore_current_blog();
	}
}
