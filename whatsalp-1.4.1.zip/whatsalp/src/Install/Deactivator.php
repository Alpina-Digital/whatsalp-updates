<?php
declare(strict_types=1);

namespace WhatsAlp\Install;

use WhatsAlp\Cron\DailyMaintenance;
use WhatsAlp\Cron\SyncSweeper;

final class Deactivator {

	public static function deactivate( bool $network_wide = false ): void {
		if ( $network_wide && is_multisite() ) {
			foreach ( get_sites( [ 'number' => 0, 'fields' => 'ids' ] ) as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::deactivate_single();
				restore_current_blog();
			}
			return;
		}
		self::deactivate_single();
	}

	public static function deactivate_single(): void {
		SyncSweeper::unschedule();
		DailyMaintenance::unschedule();
	}
}
