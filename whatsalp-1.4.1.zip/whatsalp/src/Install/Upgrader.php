<?php
declare(strict_types=1);

namespace WhatsAlp\Install;

/**
 * Roda em plugins_loaded: o hook de ativação não dispara em auto-update nem em
 * sites clonados. Só chama dbDelta quando a versão gravada difere.
 * Sem strings traduzidas aqui (WP 6.7+ avisa sobre carregamento antecipado).
 */
final class Upgrader {

	private const LOCK = 'whatsalp_upgrading';

	public static function maybe_upgrade(): void {
		$installed = (string) get_option( 'whatsalp_db_version', '0' );
		if ( WHATSALP_DB_VERSION === $installed ) {
			return;
		}
		if ( get_transient( self::LOCK ) ) {
			return;
		}
		set_transient( self::LOCK, 1, MINUTE_IN_SECONDS );

		Schema::create_tables();
		// Remoções de colunas/índices não são feitas pelo dbDelta: adicionar
		// ALTERs explícitos por versão aqui quando houver.

		delete_transient( self::LOCK );
		update_option( 'whatsalp_upgraded_from', $installed, false );
	}
}
