<?php
declare(strict_types=1);

namespace WhatsAlp\Frontend;

use WhatsAlp\Settings\Settings;

/**
 * Decide no servidor, só por URL/tipo de conteúdo (seguro com cache de página).
 * hide_on_mobile e delay_seconds ficam no cliente.
 */
final class DisplayRules {

	public static function should_display(): bool {
		$show = self::evaluate();
		return (bool) apply_filters( 'whatsalp_should_display', $show );
	}

	private static function evaluate(): bool {
		if ( is_admin() || is_feed() || is_embed() || is_customize_preview() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && constant( 'REST_REQUEST' ) ) ) {
			return false;
		}
		if ( '' === Settings::get( 'phone_number' ) ) {
			return false;
		}
		if ( self::in_builder_editor() ) {
			return false;
		}
		if ( ! Settings::get( 'display_woo_checkout' ) && self::is_woo_checkout_or_cart() ) {
			return false;
		}
		$mode = (string) Settings::get( 'display_mode' );
		$ids  = array_map( 'intval', (array) Settings::get( 'display_ids' ) );
		$id   = (int) get_queried_object_id();
		if ( 'include' === $mode ) {
			return is_singular() && in_array( $id, $ids, true );
		}
		if ( 'exclude' === $mode && is_singular() && in_array( $id, $ids, true ) ) {
			return false;
		}
		if ( is_front_page() && ! Settings::get( 'display_front_page' ) ) {
			return false;
		}
		if ( ( is_archive() || is_search() || ( is_home() && ! is_front_page() ) ) && ! Settings::get( 'display_archives' ) ) {
			return false;
		}
		return true;
	}

	private static function in_builder_editor(): bool {
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$el = \Elementor\Plugin::$instance ?? null;
			if ( $el && isset( $el->editor ) && method_exists( $el->editor, 'is_edit_mode' ) && $el->editor->is_edit_mode() ) {
				return true;
			}
			if ( $el && isset( $el->preview ) && method_exists( $el->preview, 'is_preview_mode' ) && $el->preview->is_preview_mode() ) {
				return true;
			}
		}
		if ( function_exists( 'et_fb_is_enabled' ) && et_fb_is_enabled() ) {
			return true;
		}
		return false;
	}

	private static function is_woo_checkout_or_cart(): bool {
		return ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_cart' ) && is_cart() );
	}
}
