<?php
declare(strict_types=1);

namespace WhatsAlp\Frontend;

use WhatsAlp\Settings\PublicConfig;
use WhatsAlp\Settings\Settings;

/**
 * Enfileira o bundle e injeta a config. O JS cria o host no body.
 */
final class Widget {

	public const HANDLE = 'whatsalp-widget';

	public function register(): void {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );
		add_action( 'template_redirect', [ $this, 'preview_headers' ] );
	}

	public static function is_preview(): bool {
		if ( empty( $_GET['whatsalp_preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return false;
		}
		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return current_user_can( \WhatsAlp\Admin\Capabilities::CAP ) && wp_verify_nonce( $nonce, 'whatsalp_preview' );
	}

	public function preview_headers(): void {
		if ( ! self::is_preview() ) {
			return;
		}
		show_admin_bar( false );
		nocache_headers();
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound
		}
	}

	public function enqueue(): void {
		$preview = self::is_preview();
		if ( ! $preview && ! DisplayRules::should_display() ) {
			return;
		}
		$file = WHATSALP_DIR . 'assets/dist/widget.js';
		$ver  = is_file( $file ) ? (string) filemtime( $file ) : WHATSALP_VERSION;
		wp_register_script( self::HANDLE, WHATSALP_URL . 'assets/dist/widget.js', [], $ver, $this->script_args() );
		wp_add_inline_script( self::HANDLE, 'window.WhatsAlpConfig = ' . wp_json_encode( PublicConfig::get( $preview ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ';', 'before' );
		wp_enqueue_script( self::HANDLE );

		if ( Settings::get( 'font_jakarta' ) ) {
			// @font-face precisa estar no light DOM: dentro do shadow root não registra.
			$base = WHATSALP_URL . 'assets/dist/fonts/';
			$css  = "@font-face{font-family:'Plus Jakarta Sans';font-style:normal;font-weight:500 700;font-display:swap;src:url('{$base}PlusJakartaSans.woff2') format('woff2')}";
			wp_register_style( 'whatsalp-font', false, [], WHATSALP_VERSION ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			wp_enqueue_style( 'whatsalp-font' );
			wp_add_inline_style( 'whatsalp-font', $css );
		}

		if ( ! $this->supports_strategy() ) {
			add_filter( 'script_loader_tag', [ $this, 'defer_tag' ], 10, 2 );
		}
	}

	/**
	 * @return array<string,mixed>|bool
	 */
	private function script_args() {
		return $this->supports_strategy() ? [ 'in_footer' => true, 'strategy' => 'defer' ] : true;
	}

	private function supports_strategy(): bool {
		return version_compare( get_bloginfo( 'version' ), '6.3', '>=' );
	}

	public function defer_tag( string $tag, string $handle ): string {
		if ( self::HANDLE === $handle && ! str_contains( $tag, ' defer' ) ) {
			$tag = str_replace( ' src=', ' defer src=', $tag );
		}
		return $tag;
	}
}
