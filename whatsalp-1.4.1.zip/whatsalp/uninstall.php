<?php
/**
 * Desinstalação: respeita a opção "manter dados" de cada site.
 *
 * @package WhatsAlp
 */

declare(strict_types=1);

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Remove dados do site atual.
 */
function whatsalp_uninstall_site(): void {
	global $wpdb;

	$settings = get_option( 'whatsalp_settings', [] );
	if ( ! empty( $settings['keep_data'] ) ) {
		return;
	}

	$leads = $wpdb->prefix . 'whatsalp_leads';
	$log   = $wpdb->prefix . 'whatsalp_sync_log';
	$wpdb->query( "DROP TABLE IF EXISTS {$log}" );   // phpcs:ignore WordPress.DB
	$wpdb->query( "DROP TABLE IF EXISTS {$leads}" ); // phpcs:ignore WordPress.DB

	foreach ( [ 'whatsalp_settings', 'whatsalp_integrations', 'whatsalp_db_version', 'whatsalp_last_sweep', 'whatsalp_installed_at', 'whatsalp_upgraded_from', 'whatsalp_origin_enforce_from', 'whatsalp_cf_ranges', 'whatsalp_origin_blocks' ] as $option ) {
		delete_option( $option );
	}

	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_whatsalp\_%' OR option_name LIKE '\_transient\_timeout\_whatsalp\_%'" ); // phpcs:ignore WordPress.DB
	$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'whatsalp\_%' OR meta_key LIKE '%whatsalp_leads_per_page'" ); // phpcs:ignore WordPress.DB

	wp_clear_scheduled_hook( 'whatsalp_sync_sweeper' );
	wp_clear_scheduled_hook( 'whatsalp_daily_maintenance' );

	$upload = wp_upload_dir();
	$dir    = trailingslashit( $upload['basedir'] ) . 'whatsalp-logs';
	if ( is_dir( $dir ) ) {
		foreach ( array_merge( (array) glob( $dir . '/*' ), (array) glob( $dir . '/.[!.]*' ) ) as $log_file ) {
			if ( is_file( $log_file ) ) {
				wp_delete_file( $log_file );
			}
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir, WordPress.PHP.NoSilencedErrors.Discouraged -- pasta pode ter ficado em uso; falhar aqui travaria a desinstalação.
		@rmdir( $dir );
	}
}

if ( is_multisite() ) {
	foreach ( get_sites( [ 'number' => 0, 'fields' => 'ids' ] ) as $whatsalp_site_id ) {
		switch_to_blog( (int) $whatsalp_site_id );
		whatsalp_uninstall_site();
		restore_current_blog();
	}
} else {
	whatsalp_uninstall_site();
}
