<?php
/**
 * Plugin Name:       WhatsAlp
 * Plugin URI:        https://alpina.digital/whatsalp
 * Description:       Botão de WhatsApp com captura de leads e integração com CRM.
 * Version:           1.4.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Alpina Digital
 * Author URI:        https://alpina.digital
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       whatsalp
 * Domain Path:       /languages
 * Update URI:        https://alpina.digital/whatsalp
 * Network:           false
 *
 * @package WhatsAlp
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

define( 'WHATSALP_VERSION', '1.4.0' );
define( 'WHATSALP_DB_VERSION', '3' ); // 3: colunas menu_option e menu_option_id
define( 'WHATSALP_FILE', __FILE__ );
define( 'WHATSALP_DIR', plugin_dir_path( __FILE__ ) );
define( 'WHATSALP_URL', plugin_dir_url( __FILE__ ) );
define( 'WHATSALP_BASENAME', plugin_basename( __FILE__ ) );

// Autoloader próprio: o vendor/ só é necessário para dependências de terceiros.
spl_autoload_register(
	static function ( string $class ): void {
		$prefix = 'WhatsAlp\\';
		if ( 0 !== strncmp( $class, $prefix, strlen( $prefix ) ) ) {
			return;
		}
		$relative = substr( $class, strlen( $prefix ) );
		$file     = WHATSALP_DIR . 'src/' . str_replace( '\\', '/', $relative ) . '.php';
		if ( is_file( $file ) ) {
			require $file;
		}
	}
);

if ( is_file( WHATSALP_DIR . 'vendor/autoload.php' ) ) {
	require WHATSALP_DIR . 'vendor/autoload.php';
}

register_activation_hook( __FILE__, [ WhatsAlp\Install\Activator::class, 'activate' ] );
register_deactivation_hook( __FILE__, [ WhatsAlp\Install\Deactivator::class, 'deactivate' ] );

WhatsAlp\Plugin::instance()->boot();
