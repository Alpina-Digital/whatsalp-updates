<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

use WhatsAlp\Admin\Menu;
use WhatsAlp\Leads\Lead;
use WhatsAlp\Leads\PhoneBR;
use WhatsAlp\Security\RateLimiter;
use WhatsAlp\Settings\Settings;

/**
 * Avisos por e-mail. O remetente nunca é forçado aqui: quem decide é o site
 * (quase sempre um plugin de SMTP com o domínio autenticado), e sobrescrever
 * o From quebraria justamente a configuração que faz o e-mail ser entregue.
 */
final class Mailer {

	/** Alertas de falha por integração a cada hora: um CRM fora do ar não vira enxurrada. */
	private const FAIL_PER_HOUR = 3;

	/**
	 * Destinatários configurados; sem nenhum, o administrador do site.
	 *
	 * @return string[]
	 */
	public static function recipients(): array {
		$raw  = (string) Settings::get( 'notify_emails' );
		$list = array_filter( array_map( 'trim', preg_split( '/[\s,;]+/', $raw ) ?: [] ), 'is_email' );
		if ( ! $list ) {
			$admin = (string) get_option( 'admin_email' );
			$list  = is_email( $admin ) ? [ $admin ] : [];
		}
		/** @var string[] $out */
		$out = (array) apply_filters( 'whatsalp_notify_recipients', array_values( array_unique( $list ) ) );
		return $out;
	}

	public static function new_lead( Lead $lead ): bool {
		$to = self::recipients();
		if ( ! $to ) {
			return false;
		}
		// Responder o aviso fala com o lead, não com o servidor.
		$headers = $lead->email && is_email( $lead->email ) ? [ 'Reply-To: ' . self::name_and_email( $lead ) ] : [];
		return self::send(
			$to,
			// translators: %1$s = nome do site, %2$s = nome do contato.
			sprintf( __( '[%1$s] Novo contato: %2$s', 'whatsalp' ), self::site_name(), $lead->name ?: __( 'sem nome', 'whatsalp' ) ),
			self::lead_body( $lead ),
			$headers
		);
	}

	/**
	 * Alerta de lead que não chegou ao CRM. Sem isso a falha só aparece para quem
	 * abre o painel — e o contato fica parado sem ninguém saber.
	 */
	public static function sync_failed( Lead $lead, string $integration, string $error ): bool {
		$to = self::recipients();
		if ( ! $to ) {
			return false;
		}
		if ( RateLimiter::hit( 'notify_fail', $integration, self::FAIL_PER_HOUR, HOUR_IN_SECONDS ) ) {
			Logger::info( 'notify_fail suprimido', [ 'integration' => $integration ] );
			return false;
		}
		$rows = [
			__( 'Integração', 'whatsalp' ) => $integration,
			__( 'Erro', 'whatsalp' )       => $error,
		];
		$body = '<p>' . esc_html__( 'Um contato foi capturado pelo site mas não chegou ao CRM. Ele está salvo no painel e pode ser reenviado por lá.', 'whatsalp' ) . '</p>'
			. self::table( $rows )
			. self::lead_body( $lead );
		return self::send(
			$to,
			// translators: %1$s = nome do site, %2$s = nome do contato.
			sprintf( __( '[%1$s] Falha ao enviar contato ao CRM: %2$s', 'whatsalp' ), self::site_name(), $lead->name ?: __( 'sem nome', 'whatsalp' ) ),
			$body
		);
	}

	/**
	 * @return array{ok:bool, message:string}
	 */
	public static function send_test(): array {
		$to = self::recipients();
		if ( ! $to ) {
			return [ 'ok' => false, 'message' => __( 'Nenhum destinatário válido configurado.', 'whatsalp' ) ];
		}
		$ok = self::send(
			$to,
			// translators: %s = nome do site.
			sprintf( __( '[%s] Teste de aviso do WhatsAlp', 'whatsalp' ), self::site_name() ),
			'<p>' . esc_html__( 'Se você recebeu esta mensagem, os avisos do WhatsAlp estão funcionando.', 'whatsalp' ) . '</p>'
		);
		$lista = implode( ', ', $to );
		return [
			'ok'      => $ok,
			// translators: %s = lista de endereços de e-mail.
			'message' => $ok
				? sprintf( __( 'Enviado para %s. Confira a caixa de entrada (e o spam).', 'whatsalp' ), $lista )
				: sprintf( __( 'O WordPress não conseguiu enviar para %s. Verifique o plugin de SMTP do site.', 'whatsalp' ), $lista ),
		];
	}

	/**
	 * @param string[] $to
	 * @param string[] $headers
	 */
	private static function send( array $to, string $subject, string $html, array $headers = [] ): bool {
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$sent      = wp_mail( $to, $subject, self::wrap( $subject, $html ), $headers );
		if ( ! $sent ) {
			Logger::error( 'wp_mail falhou', [ 'subject' => $subject ] );
		}
		return (bool) $sent;
	}

	private static function lead_body( Lead $lead ): string {
		$phone = PhoneBR::format( $lead->phone );
		$rows  = [
			__( 'Nome', 'whatsalp' )     => $lead->name,
			__( 'Telefone', 'whatsalp' ) => $phone,
			__( 'E-mail', 'whatsalp' )   => (string) $lead->email,
			__( 'Empresa', 'whatsalp' )  => (string) $lead->company,
			__( 'Escolha', 'whatsalp' )  => (string) $lead->menu_option,
			__( 'Página', 'whatsalp' )   => (string) ( $lead->source_title ?: $lead->source_url ),
		];
		$wa    = 'https://wa.me/' . rawurlencode( preg_replace( '/\D+/', '', $lead->phone ) ?? '' );
		$links = '<p><a href="' . esc_url( $wa ) . '">' . esc_html__( 'Abrir conversa no WhatsApp', 'whatsalp' ) . '</a>';
		if ( $lead->id > 0 ) {
			$painel = admin_url( 'admin.php?page=' . Menu::SLUG_CONTACTS . '&lead=' . $lead->id );
			$links .= ' &nbsp;·&nbsp; <a href="' . esc_url( $painel ) . '">' . esc_html__( 'Ver no painel', 'whatsalp' ) . '</a>';
		}
		return self::table( $rows ) . $links . '</p>';
	}

	/**
	 * @param array<string,string> $rows
	 */
	private static function table( array $rows ): string {
		$html = '<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;font:15px/1.5 -apple-system,Segoe UI,Roboto,sans-serif">';
		foreach ( $rows as $label => $value ) {
			if ( '' === trim( $value ) ) {
				continue;
			}
			$html .= '<tr><td style="color:#64748b;vertical-align:top">' . esc_html( $label ) . '</td>'
				. '<td style="font-weight:600">' . esc_html( $value ) . '</td></tr>';
		}
		return $html . '</table>';
	}

	private static function wrap( string $title, string $html ): string {
		return '<!doctype html><html><body style="font:15px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a">'
			. '<h2 style="font-size:17px;margin:0 0 12px">' . esc_html( $title ) . '</h2>'
			. $html
			. '</body></html>';
	}

	private static function name_and_email( Lead $lead ): string {
		$email = (string) $lead->email;
		$name  = trim( str_replace( [ '<', '>', '"', "\r", "\n" ], '', $lead->name ) );
		return '' === $name ? $email : sprintf( '%s <%s>', $name, $email );
	}

	private static function site_name(): string {
		return (string) get_bloginfo( 'name' );
	}
}
