<?php
declare(strict_types=1);

namespace WhatsAlp\Install;

/**
 * Definição das tabelas no formato exigido pelo dbDelta.
 */
final class Schema {

	public static function leads_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'whatsalp_leads';
	}

	public static function sync_log_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'whatsalp_sync_log';
	}

	/**
	 * @return string[] Instruções CREATE TABLE.
	 */
	public static function statements(): array {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$leads           = self::leads_table();
		$log             = self::sync_log_table();

		return [
			"CREATE TABLE {$leads} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  lead_token char(32) NOT NULL,
  name varchar(190) NOT NULL,
  phone varchar(20) NOT NULL,
  phone_raw varchar(40) DEFAULT NULL,
  email varchar(190) DEFAULT NULL,
  company varchar(190) DEFAULT NULL,
  source_url text,
  source_path varchar(255) DEFAULT NULL,
  source_title varchar(255) DEFAULT NULL,
  utm longtext,
  consent tinyint(1) NOT NULL DEFAULT 0,
  consent_text text,
  consent_policy_url varchar(255) DEFAULT NULL,
  ip_hash char(64) DEFAULT NULL,
  user_agent varchar(255) DEFAULT NULL,
  sync_status varchar(20) NOT NULL DEFAULT 'none',
  wa_clicked_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY uk_token (lead_token),
  KEY idx_created (created_at),
  KEY idx_phone (phone),
  KEY idx_email (email(100)),
  KEY idx_source (source_path(191)),
  KEY idx_sync (sync_status)
) {$charset_collate};",
			"CREATE TABLE {$log} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  lead_id bigint(20) unsigned NOT NULL,
  integration varchar(50) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'pending',
  step varchar(40) DEFAULT NULL,
  external_person_id varchar(100) DEFAULT NULL,
  external_id varchar(100) DEFAULT NULL,
  attempts tinyint(3) unsigned NOT NULL DEFAULT 0,
  rate_limited tinyint(3) unsigned NOT NULL DEFAULT 0,
  next_attempt_at datetime DEFAULT NULL,
  locked_at datetime DEFAULT NULL,
  last_error varchar(255) DEFAULT NULL,
  response_excerpt text,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY uk_lead_integration (lead_id,integration),
  KEY idx_pending (status,next_attempt_at)
) {$charset_collate};",
		];
	}

	public static function create_tables(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( self::statements() as $sql ) {
			dbDelta( $sql );
		}
		update_option( 'whatsalp_db_version', WHATSALP_DB_VERSION, true ); // autoload: lido em todo request pelo Upgrader
	}
}
