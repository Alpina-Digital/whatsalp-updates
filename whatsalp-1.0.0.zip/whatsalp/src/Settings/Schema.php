<?php
declare(strict_types=1);

namespace WhatsAlp\Settings;

/**
 * Definição declarativa dos campos de configuração: default + sanitizador.
 * Defaults traduzíveis são closures, resolvidas só quando usadas (nunca no bootstrap).
 */
final class Schema {

	public const TYPE_TEXT   = 'text';
	public const TYPE_RICH   = 'rich';
	public const TYPE_URL    = 'url';
	public const TYPE_EMAILS = 'emails';
	public const TYPE_INT    = 'int';
	public const TYPE_BOOL   = 'bool';
	public const TYPE_COLOR  = 'color';
	public const TYPE_ENUM   = 'enum';
	public const TYPE_IDS    = 'ids';
	public const TYPE_LIST   = 'list';

	/**
	 * @return array<string, array{type:string, default:mixed, options?:string[], min?:int, max?:int}>
	 */
	public static function fields(): array {
		return [
			// Número e mensagem.
			'phone_country'   => [ 'type' => self::TYPE_TEXT, 'default' => '55' ],
			'phone_number'    => [ 'type' => self::TYPE_TEXT, 'default' => '' ],
			'display_name'    => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Atendimento', 'whatsalp' ) ],
			'display_subtitle' => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Online · responde em minutos', 'whatsalp' ) ],
			'avatar_id'       => [ 'type' => self::TYPE_INT, 'default' => 0 ],
			'wa_message'      => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Olá! Meu nome é {nome}. Vim pelo site {site} e gostaria de mais informações.', 'whatsalp' ) ],
			'welcome_text'    => [ 'type' => self::TYPE_RICH, 'default' => static fn() => __( "Olá! Que bom ter você aqui.\nPara começar o atendimento no WhatsApp, me conta rapidinho quem é você.", 'whatsalp' ) ],

			// Após o formulário.
			'after_submit'    => [ 'type' => self::TYPE_ENUM, 'default' => 'button_redirect', 'options' => [ 'button', 'button_redirect', 'redirect' ] ],
			'redirect_delay'  => [ 'type' => self::TYPE_INT, 'default' => 5, 'min' => 1, 'max' => 60 ],
			'open_new_tab'    => [ 'type' => self::TYPE_BOOL, 'default' => true ],

			// Aparência.
			'theme'           => [ 'type' => self::TYPE_ENUM, 'default' => 'light', 'options' => [ 'light', 'dark', 'custom' ] ],
			'color_primary'   => [ 'type' => self::TYPE_COLOR, 'default' => '#25D366' ],
			'color_panel'     => [ 'type' => self::TYPE_COLOR, 'default' => '#FFFFFF' ],
			'color_text'      => [ 'type' => self::TYPE_COLOR, 'default' => '#0F172A' ],
			'position'        => [ 'type' => self::TYPE_ENUM, 'default' => 'right', 'options' => [ 'right', 'left' ] ],
			'margin'          => [ 'type' => self::TYPE_INT, 'default' => 20, 'min' => 0, 'max' => 200 ],
			'bubble_enabled'  => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'bubble_text'     => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Fale conosco no WhatsApp', 'whatsalp' ) ],
			'font_jakarta'    => [ 'type' => self::TYPE_BOOL, 'default' => false ],

			// Campos do formulário (telefone é sempre obrigatório).
			'field_name_show'     => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'field_name_required' => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'field_name_label'    => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Nome', 'whatsalp' ) ],
			'field_phone_label'   => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Telefone', 'whatsalp' ) ],
			'field_company_show'  => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'field_company_required' => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'field_company_label' => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'Empresa', 'whatsalp' ) ],
			'field_email_show'    => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'field_email_required' => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'field_email_label'   => [ 'type' => self::TYPE_TEXT, 'default' => static fn() => __( 'E-mail', 'whatsalp' ) ],
			'consent_text'    => [ 'type' => self::TYPE_RICH, 'default' => static fn() => __( 'Concordo em ser contatado e aceito a Política de Privacidade.', 'whatsalp' ) ],
			'privacy_url'     => [ 'type' => self::TYPE_URL, 'default' => '' ],

			// Exibição.
			'display_mode'    => [ 'type' => self::TYPE_ENUM, 'default' => 'all', 'options' => [ 'all', 'include', 'exclude' ] ],
			'display_ids'     => [ 'type' => self::TYPE_IDS, 'default' => [] ],
			'display_front_page' => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'display_archives' => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'display_woo_checkout' => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'hide_on_mobile'  => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'delay_seconds'   => [ 'type' => self::TYPE_INT, 'default' => 0, 'min' => 0, 'max' => 120 ],

			// Segurança / privacidade.
			'behind_proxy'    => [ 'type' => self::TYPE_BOOL, 'default' => false ],
			'trusted_proxies' => [ 'type' => self::TYPE_LIST, 'default' => [] ],
			'retention_days'  => [ 'type' => self::TYPE_INT, 'default' => 0, 'min' => 0, 'max' => 3650 ],
			'keep_data'       => [ 'type' => self::TYPE_BOOL, 'default' => true ],
			'debug_log'       => [ 'type' => self::TYPE_BOOL, 'default' => false ],
		];
	}

	/**
	 * @param mixed $value
	 * @param array{type:string, default:mixed, options?:string[], min?:int, max?:int} $field
	 * @return mixed
	 */
	public static function sanitize( $value, array $field ) {
		switch ( $field['type'] ) {
			case self::TYPE_BOOL:
				return (bool) $value;
			case self::TYPE_INT:
				$int = absint( $value );
				if ( isset( $field['min'] ) ) {
					$int = max( $field['min'], $int );
				}
				if ( isset( $field['max'] ) ) {
					$int = min( $field['max'], $int );
				}
				return $int;
			case self::TYPE_COLOR:
				$color = sanitize_hex_color( (string) $value );
				return $color ? strtoupper( $color ) : self::resolve_default( $field['default'] );
			case self::TYPE_ENUM:
				return in_array( $value, $field['options'], true ) ? $value : self::resolve_default( $field['default'] );
			case self::TYPE_URL:
				return esc_url_raw( (string) $value );
			case self::TYPE_EMAILS:
				$emails = array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', (string) $value ) ?: [] ), static fn( $e ) => is_email( $e ) );
				return implode( ', ', array_unique( $emails ) );
			case self::TYPE_IDS:
				$ids = is_array( $value ) ? $value : preg_split( '/[\s,]+/', (string) $value );
				return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
			case self::TYPE_LIST:
				$items = is_array( $value ) ? $value : preg_split( '/[\s,]+/', (string) $value );
				return array_values( array_filter( array_map( 'sanitize_text_field', (array) $items ) ) );
			case self::TYPE_RICH:
				return wp_kses( (string) $value, [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ], 'strong' => [], 'em' => [], 'br' => [] ] );
			case self::TYPE_TEXT:
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * @param mixed $default
	 * @return mixed
	 */
	public static function resolve_default( $default ) {
		return $default instanceof \Closure ? $default() : $default;
	}
}
