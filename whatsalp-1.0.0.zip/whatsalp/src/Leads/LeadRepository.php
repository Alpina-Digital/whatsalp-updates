<?php
declare(strict_types=1);

namespace WhatsAlp\Leads;

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nomes de tabela vêm de Schema, não de input.

use WhatsAlp\Install\Schema;

class LeadRepository {

	private string $table;

	public function __construct() {
		$this->table = Schema::leads_table();
	}

	public function table(): string {
		return $this->table;
	}

	public function insert( Lead $lead ): int {
		global $wpdb;
		$wpdb->insert(
			$this->table,
			[
				'lead_token'         => $lead->lead_token,
				'name'               => $lead->name,
				'phone'              => $lead->phone,
				'phone_raw'          => $lead->phone_raw,
				'email'              => $lead->email,
				'company'            => $lead->company,
				'source_url'         => $lead->source_url,
				'source_path'        => $lead->source_path,
				'source_title'       => $lead->source_title,
				'utm'                => $lead->utm ? wp_json_encode( $lead->utm ) : null,
				'consent'            => $lead->consent ? 1 : 0,
				'consent_text'       => $lead->consent_text,
				'consent_policy_url' => $lead->consent_policy_url,
				'ip_hash'            => $lead->ip_hash,
				'user_agent'         => $lead->user_agent,
				'sync_status'        => $lead->sync_status,
				'created_at'         => $lead->created_at,
			]
		);
		$lead->id = (int) $wpdb->insert_id;
		return $lead->id;
	}

	public function find( int $id ): ?Lead {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? Lead::from_row( $row ) : null;
	}

	public function find_by_token( int $id, string $token, int $max_age = DAY_IN_SECONDS ): ?Lead {
		$lead = $this->find( $id );
		if ( ! $lead || ! hash_equals( $lead->lead_token, $token ) ) {
			return null;
		}
		if ( strtotime( $lead->created_at . ' UTC' ) < time() - $max_age ) {
			return null;
		}
		return $lead;
	}

	public function find_recent_by_phone( string $phone, int $minutes ): ?Lead {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - $minutes * MINUTE_IN_SECONDS );
		$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare( "SELECT * FROM {$this->table} WHERE phone = %s AND created_at >= %s ORDER BY id DESC LIMIT 1", $phone, $since ),
			ARRAY_A
		);
		return $row ? Lead::from_row( $row ) : null;
	}

	/**
	 * @param array<string,mixed> $data
	 */
	public function update( int $id, array $data ): void {
		global $wpdb;
		$wpdb->update( $this->table, $data, [ 'id' => $id ] );
	}

	public function mark_clicked( int $id ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$this->table} SET wa_clicked_at = UTC_TIMESTAMP() WHERE id = %d AND wa_clicked_at IS NULL", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function delete( int $id ): void {
		global $wpdb;
		$wpdb->delete( $this->table, [ 'id' => $id ] );
		$wpdb->delete( Schema::sync_log_table(), [ 'lead_id' => $id ] );
	}

	/**
	 * @return int[] IDs apagados.
	 */
	public function delete_older_than( int $days ): int {
		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$ids    = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$this->table} WHERE created_at < %s LIMIT 500", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( $ids as $id ) {
			$this->delete( (int) $id );
		}
		return count( $ids );
	}

	/**
	 * @return Lead[]
	 */
	public function find_by_email( string $email, int $page, int $per_page ): array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare( "SELECT * FROM {$this->table} WHERE email = %s ORDER BY id ASC LIMIT %d OFFSET %d", $email, $per_page, ( $page - 1 ) * $per_page ),
			ARRAY_A
		);
		return array_map( [ Lead::class, 'from_row' ], $rows ?: [] );
	}
}
