=== WhatsAlp ===
Contributors: alpinadigital
Tags: whatsapp, leads, crm, pipedrive, chat
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Botão de WhatsApp com captura de leads (nome, telefone e e-mail), painel de contatos e integração com CRM.

== Description ==

O WhatsAlp coloca um botão flutuante de WhatsApp no seu site. Ao clicar, o visitante vê um painel em formato de chat que pede nome, telefone e e-mail antes de liberar a conversa no WhatsApp da empresa, já com a mensagem de abertura preenchida.

* Temas claro, escuro e personalizado.
* Leads salvos em um painel de Contatos no WP Admin, com filtros, detalhes e exportação CSV.
* Integração com Pipedrive (Pessoa + Lead/Negócio + nota) e webhook genérico assinado (Zapier, Make, n8n).
* Arquitetura extensível: novas integrações via filtro `whatsalp_integrations`.
* LGPD: consentimento registrado, exportação e exclusão por titular, ferramentas de privacidade do WordPress.

Desenvolvido por [Alpina Digital](https://alpina.digital).

== Installation ==

1. Envie a pasta `whatsalp` para `/wp-content/plugins/` ou instale pelo zip.
2. Ative o plugin.
3. Em WhatsAlp › Configurações, informe o número do WhatsApp e salve.
4. Opcional: em WhatsAlp › Integrações, conecte o Pipedrive ou um webhook.

== Frequently Asked Questions ==

= O formulário funciona com cache de página? =
Sim. O endpoint público não depende de nonce do WordPress e o widget renova o token automaticamente quando a página está cacheada há muito tempo.

= E se a REST API estiver bloqueada para visitantes? =
O widget usa automaticamente o fallback por `admin-ajax.php`. Se os dois falharem, o botão do WhatsApp ainda abre com a mensagem correta.

= Como adiciono outra integração? =
Implemente `WhatsAlp\Integrations\IntegrationInterface` e registre a classe no filtro `whatsalp_integrations`.

== Changelog ==

= 1.0.0 =
* Versão inicial.
