# WhatsAlp

Plugin WordPress da **Alpina Digital**: botão flutuante de WhatsApp que abre um chat, captura nome, telefone, empresa e e-mail, salva o lead no painel do site e envia para o CRM (Pipedrive) ou para um webhook assinado.

- Plano técnico completo: [`PLANO.md`](PLANO.md)
- Texto de distribuição (WordPress.org): [`readme.txt`](readme.txt)

## Instalar em um cliente

1. Baixe o zip da última release em `release/` (ou gere com `./scripts/release.sh`).
2. WP Admin › Plugins › Adicionar novo › Enviar plugin › ativar.
3. WhatsAlp › Configurações: informe o número, salve. O botão aparece no site.
4. WhatsAlp › Integrações › Pipedrive: token da API, domínio da empresa, pipeline/etapa (modo Negócio), **marque "Enviar novos leads automaticamente"**, salve e clique em "Testar conexão".

Requisitos: WordPress 6.0+, PHP 8.0+. Funciona com cache de página, Cloudflare e REST bloqueada para visitantes (fallback automático).

## Desenvolvimento

```bash
composer install
npm install
npm run build          # gera assets/dist (não versionado)
npm run watch          # rebuild contínuo
```

Testes:

```bash
composer lint          # phpcs WordPress-Extra + PHPCompatibility
composer test:unit     # PHPUnit sem WordPress (Brain Monkey)
# Integração: precisa de MariaDB/MySQL e de um WordPress descompactado (ver tests/phpunit/wp-tests-config.php)
WP_PHPUNIT__TESTS_CONFIG=$PWD/tests/phpunit/wp-tests-config.php composer test:wp
npx playwright test    # widget em Chromium, WebKit e iPhone (serve tests/e2e/fixtures)
```

Ambiente WordPress local alternativo: `npx wp-env start` (Docker) lê `.wp-env.json` e sobe o plugin em http://localhost:8888.

## Release

```bash
./scripts/release.sh
```

Gera `release/whatsalp-<versão>.zip` (vendor só de produção, sem testes) e `release/latest.json` com o `sha256` do zip. Se o repositório público [`Alpina-Digital/whatsalp-updates`](https://github.com/Alpina-Digital/whatsalp-updates) estiver clonado ao lado desta pasta, o script copia os dois arquivos para lá e faz push; o GitHub Pages serve em `https://alpina-digital.github.io/whatsalp-updates/latest.json`, que é onde os sites dos clientes consultam a versão e verificam o hash antes de instalar. Para mudar a URL use o filtro `whatsalp_update_metadata_url`; para desligar o verificador, `add_filter( 'whatsalp_enable_update_checker', '__return_false' )`.

Antes de uma release: atualizar `Version` em `whatsalp.php`, `Stable tag` em `readme.txt` e `version` em `package.json` (o script falha se divergirem) e regenerar `languages/whatsalp.pot`:

```bash
wp i18n make-pot . languages/whatsalp.pot --domain=whatsalp --exclude=vendor,node_modules,tests,assets/dist,scripts,release
```

## Arquitetura em uma página

- `src/Leads/LeadService.php`: honeypot → telefone → rate limit → validação → dedupe → persistência → fila.
- `src/Http/LeadController.php` + `AjaxFallback.php`: REST público (sem nonce do WP) e fallback por admin-ajax.
- `src/Integrations/Dispatcher.php`: processa `sync_log` com claim atômico e orçamento de tempo; `SyncSweeper` a cada 5 min cobre o que o navegador e o gatilho interno não pegaram.
- `src/Integrations/Pipedrive/`: máquina de estados pessoa → lead/negócio → nota, sem duplicar em retry.
- Nova integração: implemente `IntegrationInterface` (ou estenda `AbstractIntegration`) e registre no filtro `whatsalp_integrations`.
- `assets/src/widget/`: widget em JS puro com Shadow DOM; `assets/src/admin/`: telas do painel.

## Hooks para desenvolvedores

`whatsalp_lead_created`, `whatsalp_before_push_lead`, `whatsalp_after_push_lead`, `whatsalp_lead_payload_pipedrive`, `whatsalp_pipedrive_title`, `whatsalp_wa_message`, `whatsalp_should_display`, `whatsalp_client_ip`, `whatsalp_allowed_origins`, `whatsalp_verify_submission`, `whatsalp_integrations`, `whatsalp_public_config`.

## Licença

GPL-2.0-or-later. © Alpina Digital.
