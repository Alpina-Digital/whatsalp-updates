=== WhatsAlp ===
Contributors: alpinadigital
Tags: whatsapp, leads, crm, pipedrive, chat
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Botão de WhatsApp com captura de leads (nome, telefone e e-mail), painel de contatos e integração com CRM.

== Description ==

O WhatsAlp coloca um botão flutuante de WhatsApp no seu site. Ao clicar, o visitante vê um painel em formato de chat que pede nome, telefone e e-mail antes de liberar a conversa no WhatsApp da empresa, já com a mensagem de abertura preenchida.

* Menu de opções, antes ou depois do formulário: cada opção leva a um destino próprio (um WhatsApp ou um link do site) e decide quais integrações recebem o contato.
* Dois formatos de captura: formulário tradicional ou conversa, pedindo uma informação por vez.
* Temas claro, escuro e personalizado.
* Leads salvos em um painel de Contatos no WP Admin, com filtros, detalhes e exportação CSV.
* Integração com Pipedrive (Pessoa + Lead/Negócio + nota) e webhook genérico assinado (Zapier, Make, n8n).
* Arquitetura extensível: novas integrações via filtro `whatsalp_integrations`.
* LGPD: consentimento registrado, exportação e exclusão por titular, ferramentas de privacidade do WordPress.

Desenvolvido por [Alpina Digital](https://alpina.digital).

== Installation ==

1. Envie a pasta `whatsalp` para `/wp-content/plugins/` ou instale pelo zip.
2. Ative o plugin.
3. Em WhatsAlp › Configurações, informe o número do WhatsApp e salve.
4. Opcional: em WhatsAlp › Integrações, conecte o Pipedrive ou um webhook.

== Frequently Asked Questions ==

= O formulário funciona com cache de página? =
Sim. O endpoint público não depende de nonce do WordPress e o widget renova o token automaticamente quando a página está cacheada há muito tempo.

= E se a REST API estiver bloqueada para visitantes? =
O widget usa automaticamente o fallback por `admin-ajax.php`. Se os dois falharem, o botão do WhatsApp ainda abre com a mensagem correta.

= Como adiciono outra integração? =
Implemente `WhatsAlp\Integrations\IntegrationInterface` e registre a classe no filtro `whatsalp_integrations`.

== Changelog ==

= 1.3.1 =
* Correção: um preenchimento automático do navegador no campo anti-spam invisível fazia o envio ser descartado em silêncio — o visitante via a tela de sucesso e o contato não era gravado nem enviado ao CRM. O campo agora é somente leitura, que o preenchimento automático e os gerenciadores de senha ignoram.
* Correção: telefones que o formulário aceitava e o servidor recusava (por exemplo um celular digitado sem o nono dígito) passavam da tela e se perdiam. A validação do formulário agora é a mesma do servidor e o erro aparece no campo.
* Novo: em Ferramentas › Saúde do site, um teste mostra quantos envios foram descartados pelo campo anti-spam nas últimas 24 horas.

= 1.3.0 =
* Novo: os UTMs da URL (utm_source, utm_medium, utm_campaign, utm_term, utm_content, gclid e fbclid) vão para **campos personalizados do Pipedrive**, que podem ser filtrados e usados em relatório — antes apareciam apenas na nota. Em Integrações › Pipedrive, o botão "Criar campos no Pipedrive" cria o que faltar e reaproveita campos de mesmo nome.
* Correção: salvar as configurações agora **limpa o cache de página** (LiteSpeed, WP Rocket, W3 Total Cache, WP Super Cache e outros). Sem isso, uma página cacheada continuava entregando a configuração antiga — o sintoma mais comum era o menu de opções não aparecer para o visitante.
* O liga/desliga do menu passou a se chamar "Ativar o menu de opções": o rótulo anterior descrevia a posição, que é escolhida em "Quando perguntar". Com opções configuradas e o menu desligado, a tela agora avisa.

= 1.2.0 =
* Novo: a pergunta pode vir **depois** do formulário. Assim o contato é salvo mesmo que o visitante não escolha nada, e a escolha é registrada em seguida.
* Novo: **modo conversa**. Em vez de um formulário, o chat pede uma informação por vez. O contato é salvo assim que o visitante aceita o consentimento, e os campos seguintes vão completando o registro.
* Novo: cada opção define **quais integrações recebem** o contato. Uma opção pode ir só para o Pipedrive, para o webhook também, ou para nenhum.
* O envio ao CRM espera alguns minutos pela escolha quando a pergunta vem depois; se o visitante abandonar, o contato é enviado assim mesmo.

= 1.1.0 =
* Novo: menu de opções antes do formulário. O visitante escolhe entre até 8 opções e cada uma leva a um destino próprio: um WhatsApp (com número e mensagem próprios) ou um link. Cada opção decide se pede o formulário antes.
* Novo: a escolha fica gravada no contato, aparece no painel e no CSV, vai na nota do Pipedrive e está disponível como variável {opcao} na mensagem de abertura e no título do negócio.
* Novo: campo Empresa opcional no formulário, com a variável {empresa}.
* Removido: notificação por e-mail a cada lead (use a integração com o CRM ou o webhook).
* O rodapé do chat agora leva ao site da Alpina Digital.

= 1.0.0 =
* Versão inicial.
