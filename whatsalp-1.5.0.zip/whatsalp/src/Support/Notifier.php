<?php
declare(strict_types=1);

namespace WhatsAlp\Support;

use WhatsAlp\Http\InternalTrigger;
use WhatsAlp\Integrations\IntegrationInterface;
use WhatsAlp\Integrations\PushResult;
use WhatsAlp\Leads\Lead;
use WhatsAlp\Settings\Settings;

/**
 * Liga os eventos de lead aos avisos por e-mail. O envio de um lead novo sai
 * depois da resposta: o SMTP pode levar segundos e o visitante não espera por ele.
 */
final class Notifier {

	public function register(): void {
		add_action( 'whatsalp_lead_created', [ $this, 'lead_created' ] );
		add_action( 'whatsalp_sync_failed', [ $this, 'sync_failed' ], 10, 3 );
		// O resumo depende de alguém varrer a fila. Pendurar só no cron diário
		// deixaria de fora justamente o caso em que o WP-Cron parou, então a
		// captura de lead — que prova que o site está vivo — também dispara.
		add_action( 'whatsalp_lead_created', [ $this, 'check_queue' ], 20 );
	}

	public function check_queue(): void {
		if ( ! Settings::get( 'notify_sync_error' ) ) {
			return;
		}
		InternalTrigger::after_response(
			static function (): void {
				Mailer::maybe_digest();
			}
		);
	}

	public function lead_created( Lead $lead ): void {
		if ( ! Settings::get( 'notify_new_lead' ) ) {
			return;
		}
		InternalTrigger::after_response(
			static function () use ( $lead ): void {
				Mailer::new_lead( $lead );
			}
		);
	}

	public function sync_failed( Lead $lead, IntegrationInterface $integration, PushResult $result ): void {
		if ( ! Settings::get( 'notify_sync_error' ) ) {
			return;
		}
		// Já estamos depois da resposta (fila ou cron): enviar aqui mesmo.
		Mailer::sync_failed( $lead, $integration->label(), (string) ( $result->error_code ?: 'erro' ) );
	}
}
