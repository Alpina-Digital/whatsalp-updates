<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Settings\OptionsMenu;
use WhatsAlp\Settings\Settings;

final class SettingsPage {

	public function render(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			return;
		}
		$s    = Settings::all();
		$name = Settings::OPTION;
		?>
		<div class="wrap whatsalp-wrap">
			<?php Menu::header( Menu::SLUG_SETTINGS ); ?>
			<?php settings_errors(); ?>
			<form method="post" action="options.php" class="whatsalp-settings" id="whatsalp-settings-form">
				<?php settings_fields( 'whatsalp' ); ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>[_form]" value="1">
				<div class="whatsalp-columns">
					<div class="whatsalp-main">

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Número e mensagem', 'whatsalp' ); ?></h2>
							<p class="description"><?php esc_html_e( 'Para onde o visitante será enviado e o que já vai escrito na conversa.', 'whatsalp' ); ?></p>
							<div class="whatsalp-grid-2">
								<div>
									<label for="phone_number"><?php esc_html_e( 'Número do WhatsApp', 'whatsalp' ); ?></label>
									<div class="whatsalp-inline">
										<select name="<?php echo esc_attr( $name ); ?>[phone_country]" aria-label="<?php esc_attr_e( 'Código do país', 'whatsalp' ); ?>" style="width:150px">
											<?php foreach ( [ '55' => 'Brasil (+55)', '351' => 'Portugal (+351)', '1' => 'EUA (+1)', '54' => 'Argentina (+54)', '598' => 'Uruguai (+598)' ] as $code => $label ) : ?>
												<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $s['phone_country'], $code ); ?>><?php echo esc_html( $label ); ?></option>
											<?php endforeach; ?>
										</select>
										<input type="tel" id="phone_number" name="<?php echo esc_attr( $name ); ?>[phone_number]" value="<?php echo esc_attr( $s['phone_number'] ); ?>" placeholder="11999999999" class="regular-text" data-preview="number">
									</div>
									<p class="description"><?php esc_html_e( 'Somente números com DDD. O plugin monta o link wa.me automaticamente.', 'whatsalp' ); ?></p>
								</div>
								<div>
									<label for="display_name"><?php esc_html_e( 'Nome exibido no chat', 'whatsalp' ); ?></label>
									<input type="text" id="display_name" name="<?php echo esc_attr( $name ); ?>[display_name]" value="<?php echo esc_attr( $s['display_name'] ); ?>" class="regular-text" data-preview="displayName">
									<label for="display_subtitle" class="whatsalp-mt"><?php esc_html_e( 'Subtítulo', 'whatsalp' ); ?></label>
									<input type="text" id="display_subtitle" name="<?php echo esc_attr( $name ); ?>[display_subtitle]" value="<?php echo esc_attr( $s['display_subtitle'] ); ?>" class="regular-text" data-preview="subtitle">
								</div>
							</div>
							<label for="wa_message"><?php esc_html_e( 'Mensagem de abertura (vai no link do WhatsApp)', 'whatsalp' ); ?></label>
							<textarea id="wa_message" name="<?php echo esc_attr( $name ); ?>[wa_message]" rows="3" class="large-text"><?php echo esc_textarea( $s['wa_message'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Variáveis:', 'whatsalp' ); ?> <code>{nome}</code> <code>{empresa}</code> <code>{opcao}</code> <code>{email}</code> <code>{telefone}</code> <code>{pagina}</code> <code>{site}</code></p>
							<label for="welcome_text"><?php esc_html_e( 'Mensagem de boas-vindas (balões do chat)', 'whatsalp' ); ?></label>
							<textarea id="welcome_text" name="<?php echo esc_attr( $name ); ?>[welcome_text]" rows="3" class="large-text" data-preview="welcome"><?php echo esc_textarea( $s['welcome_text'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Cada linha vira um balão. Permitido: links, negrito e itálico.', 'whatsalp' ); ?></p>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Menu de opções', 'whatsalp' ); ?></h2>
							<p class="description"><?php esc_html_e( 'Uma pergunta com botões, antes ou depois do formulário. Cada opção leva a um destino próprio: um WhatsApp ou um link do site.', 'whatsalp' ); ?></p>
							<?php // O rótulo liga o menu; "antes ou depois" é o campo "Quando perguntar", logo abaixo. ?>
							<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[menu_enabled]" value="1" <?php checked( $s['menu_enabled'] ); ?> data-preview="menuEnabled"> <?php esc_html_e( 'Ativar o menu de opções', 'whatsalp' ); ?></label>
							<?php if ( ! $s['menu_enabled'] && is_array( $s['menu_options'] ) && $s['menu_options'] ) : ?>
								<div class="notice notice-warning inline"><p><?php esc_html_e( 'As opções abaixo estão configuradas, mas o menu está desligado: o visitante vai direto do formulário para o WhatsApp padrão, sem a pergunta. Marque "Ativar o menu de opções" e salve.', 'whatsalp' ); ?></p></div>
							<?php endif; ?>
							<div class="whatsalp-grid-2">
								<div>
									<label for="menu_question"><?php esc_html_e( 'Pergunta', 'whatsalp' ); ?></label>
									<input type="text" id="menu_question" name="<?php echo esc_attr( $name ); ?>[menu_question]" value="<?php echo esc_attr( $s['menu_question'] ); ?>" class="large-text" data-preview="menuQuestion">
								</div>
								<div>
									<label for="menu_position"><?php esc_html_e( 'Quando perguntar', 'whatsalp' ); ?></label>
									<select id="menu_position" name="<?php echo esc_attr( $name ); ?>[menu_position]">
										<option value="before" <?php selected( $s['menu_position'], 'before' ); ?>><?php esc_html_e( 'Antes do formulário (filtra o assunto primeiro)', 'whatsalp' ); ?></option>
										<option value="after" <?php selected( $s['menu_position'], 'after' ); ?>><?php esc_html_e( 'Depois do formulário (garante o contato primeiro)', 'whatsalp' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Perguntando depois, o contato é salvo mesmo que o visitante não escolha nada.', 'whatsalp' ); ?></p>
								</div>
							</div>

							<div id="whatsalp-menu-options" class="whatsalp-repeater" data-name="<?php echo esc_attr( $name ); ?>" data-max="<?php echo esc_attr( (string) OptionsMenu::MAX_OPTIONS ); ?>" data-position="<?php echo esc_attr( (string) $s['menu_position'] ); ?>">
								<?php
								$menu_options = is_array( $s['menu_options'] ) ? $s['menu_options'] : [];
								foreach ( $menu_options as $i => $option ) {
									self::option_row( $name, (int) $i, $option );
								}
								?>
							</div>
							<p>
								<button type="button" class="button" id="whatsalp-add-option"><?php esc_html_e( 'Adicionar opção', 'whatsalp' ); ?></button>
								<span class="description"><?php printf( esc_html__( 'Até %d opções. Arraste não é necessário: a ordem é a de cima para baixo.', 'whatsalp' ), (int) OptionsMenu::MAX_OPTIONS ); ?></span>
							</p>
							<template id="whatsalp-option-template"><?php self::option_row( $name, 0, [], true ); ?></template>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Após o formulário', 'whatsalp' ); ?></h2>
							<fieldset>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[after_submit]" value="button" <?php checked( $s['after_submit'], 'button' ); ?> data-preview="afterSubmit"> <?php esc_html_e( 'Mostrar o botão "Abrir WhatsApp" e aguardar o clique', 'whatsalp' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[after_submit]" value="button_redirect" <?php checked( $s['after_submit'], 'button_redirect' ); ?> data-preview="afterSubmit"> <?php esc_html_e( 'Mostrar o botão e redirecionar automaticamente após', 'whatsalp' ); ?> <input type="number" min="1" max="60" name="<?php echo esc_attr( $name ); ?>[redirect_delay]" value="<?php echo esc_attr( (string) $s['redirect_delay'] ); ?>" class="small-text" data-preview="redirectDelay"> <?php esc_html_e( 'segundos', 'whatsalp' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[after_submit]" value="redirect" <?php checked( $s['after_submit'], 'redirect' ); ?> data-preview="afterSubmit"> <?php esc_html_e( 'Redirecionar imediatamente, sem tela final', 'whatsalp' ); ?></label>
							</fieldset>
							<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[open_new_tab]" value="1" <?php checked( $s['open_new_tab'] ); ?>> <?php esc_html_e( 'Abrir o WhatsApp em nova aba', 'whatsalp' ); ?></label>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Aparência', 'whatsalp' ); ?></h2>
							<div class="whatsalp-themes">
								<?php foreach ( [ 'light' => __( 'Claro', 'whatsalp' ), 'dark' => __( 'Escuro', 'whatsalp' ), 'custom' => __( 'Personalizado', 'whatsalp' ) ] as $value => $label ) : ?>
									<label class="whatsalp-theme whatsalp-theme--<?php echo esc_attr( $value ); ?> <?php echo $s['theme'] === $value ? 'is-selected' : ''; ?>">
										<span class="whatsalp-theme-preview" aria-hidden="true"><i></i><b></b></span>
										<span><input type="radio" name="<?php echo esc_attr( $name ); ?>[theme]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['theme'], $value ); ?> data-preview="theme"> <?php echo esc_html( $label ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
							<div class="whatsalp-grid-3">
								<div>
									<label for="color_primary"><?php esc_html_e( 'Cor principal', 'whatsalp' ); ?></label>
									<input type="color" id="color_primary" name="<?php echo esc_attr( $name ); ?>[color_primary]" value="<?php echo esc_attr( $s['color_primary'] ); ?>" data-preview="colors.primary">
								</div>
								<div class="whatsalp-custom-only">
									<label for="color_panel"><?php esc_html_e( 'Fundo do painel', 'whatsalp' ); ?></label>
									<input type="color" id="color_panel" name="<?php echo esc_attr( $name ); ?>[color_panel]" value="<?php echo esc_attr( $s['color_panel'] ); ?>" data-preview="colors.panel">
								</div>
								<div class="whatsalp-custom-only">
									<label for="color_text"><?php esc_html_e( 'Cor do texto', 'whatsalp' ); ?></label>
									<input type="color" id="color_text" name="<?php echo esc_attr( $name ); ?>[color_text]" value="<?php echo esc_attr( $s['color_text'] ); ?>" data-preview="colors.text">
								</div>
							</div>
							<div class="whatsalp-grid-3">
								<div>
									<span class="whatsalp-label"><?php esc_html_e( 'Posição', 'whatsalp' ); ?></span>
									<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[position]" value="right" <?php checked( $s['position'], 'right' ); ?> data-preview="position"> <?php esc_html_e( 'Direita', 'whatsalp' ); ?></label>
									<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[position]" value="left" <?php checked( $s['position'], 'left' ); ?> data-preview="position"> <?php esc_html_e( 'Esquerda', 'whatsalp' ); ?></label>
								</div>
								<div>
									<label for="margin"><?php esc_html_e( 'Margem das bordas (px)', 'whatsalp' ); ?></label>
									<input type="number" id="margin" min="0" max="200" name="<?php echo esc_attr( $name ); ?>[margin]" value="<?php echo esc_attr( (string) $s['margin'] ); ?>" class="small-text" data-preview="margin">
								</div>
								<div>
									<span class="whatsalp-label"><?php esc_html_e( 'Avatar do chat', 'whatsalp' ); ?></span>
									<div class="whatsalp-inline">
										<span class="whatsalp-avatar-preview" id="whatsalp-avatar-preview">
										<?php
										if ( $s['avatar_id'] ) {
											echo wp_get_attachment_image( (int) $s['avatar_id'], 'thumbnail' ); }
										?>
										</span>
										<input type="hidden" name="<?php echo esc_attr( $name ); ?>[avatar_id]" id="avatar_id" value="<?php echo esc_attr( (string) $s['avatar_id'] ); ?>">
										<button type="button" class="button" id="whatsalp-avatar-pick"><?php esc_html_e( 'Escolher imagem', 'whatsalp' ); ?></button>
										<button type="button" class="button-link" id="whatsalp-avatar-clear"><?php esc_html_e( 'Remover', 'whatsalp' ); ?></button>
									</div>
									<p class="description"><?php esc_html_e( 'Sem imagem, usamos as iniciais do nome.', 'whatsalp' ); ?></p>
								</div>
							</div>
							<div class="whatsalp-grid-2">
								<div>
									<label for="bubble_text"><?php esc_html_e( 'Texto do balão de chamada', 'whatsalp' ); ?></label>
									<input type="text" id="bubble_text" name="<?php echo esc_attr( $name ); ?>[bubble_text]" value="<?php echo esc_attr( $s['bubble_text'] ); ?>" class="regular-text" data-preview="bubbleText">
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[bubble_enabled]" value="1" <?php checked( $s['bubble_enabled'] ); ?> data-preview="bubble"> <?php esc_html_e( 'Mostrar balão de chamada', 'whatsalp' ); ?></label>
								</div>
								<div>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[font_jakarta]" value="1" <?php checked( $s['font_jakarta'] ); ?>> <?php esc_html_e( 'Usar a fonte Plus Jakarta Sans (hospedada localmente)', 'whatsalp' ); ?></label>
									<p class="description"><?php esc_html_e( 'Desligado, o widget usa a fonte do sistema. Nenhum request ao Google.', 'whatsalp' ); ?></p>
								</div>
							</div>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Campos do formulário', 'whatsalp' ); ?></h2>
							<span class="whatsalp-label"><?php esc_html_e( 'Como pedir os dados', 'whatsalp' ); ?></span>
							<fieldset class="whatsalp-mb">
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[form_mode]" value="form" <?php checked( $s['form_mode'], 'form' ); ?> data-preview="formMode"> <?php esc_html_e( 'Formulário: todos os campos de uma vez', 'whatsalp' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[form_mode]" value="chat" <?php checked( $s['form_mode'], 'chat' ); ?> data-preview="formMode"> <?php esc_html_e( 'Conversa: uma pergunta por vez, como um chat', 'whatsalp' ); ?></label>
							</fieldset>
							<table class="widefat whatsalp-fields-table">
								<thead><tr><th><?php esc_html_e( 'Campo', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Exibir', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Obrigatório', 'whatsalp' ); ?></th><th><?php esc_html_e( 'Rótulo', 'whatsalp' ); ?></th></tr></thead>
								<tbody>
									<tr>
										<td><strong><?php esc_html_e( 'Nome', 'whatsalp' ); ?></strong></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_name_show]" value="1" <?php checked( $s['field_name_show'] ); ?> data-preview="fields.name.show"></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_name_required]" value="1" <?php checked( $s['field_name_required'] ); ?> data-preview="fields.name.required"></td>
										<td><input type="text" name="<?php echo esc_attr( $name ); ?>[field_name_label]" value="<?php echo esc_attr( $s['field_name_label'] ); ?>" data-preview="fields.name.label"></td>
									</tr>
									<tr>
										<td><strong><?php esc_html_e( 'Telefone', 'whatsalp' ); ?></strong></td>
										<td><input type="checkbox" checked disabled> <span class="description"><?php esc_html_e( 'sempre', 'whatsalp' ); ?></span></td>
										<td><input type="checkbox" checked disabled></td>
										<td><input type="text" name="<?php echo esc_attr( $name ); ?>[field_phone_label]" value="<?php echo esc_attr( $s['field_phone_label'] ); ?>" data-preview="fields.phone.label"></td>
									</tr>
									<tr>
										<td><strong><?php esc_html_e( 'Empresa', 'whatsalp' ); ?></strong></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_company_show]" value="1" <?php checked( $s['field_company_show'] ); ?> data-preview="fields.company.show"></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_company_required]" value="1" <?php checked( $s['field_company_required'] ); ?> data-preview="fields.company.required"></td>
										<td><input type="text" name="<?php echo esc_attr( $name ); ?>[field_company_label]" value="<?php echo esc_attr( $s['field_company_label'] ); ?>" data-preview="fields.company.label"></td>
									</tr>
									<tr>
										<td><strong><?php esc_html_e( 'E-mail', 'whatsalp' ); ?></strong></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_email_show]" value="1" <?php checked( $s['field_email_show'] ); ?> data-preview="fields.email.show"></td>
										<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[field_email_required]" value="1" <?php checked( $s['field_email_required'] ); ?> data-preview="fields.email.required"></td>
										<td><input type="text" name="<?php echo esc_attr( $name ); ?>[field_email_label]" value="<?php echo esc_attr( $s['field_email_label'] ); ?>" data-preview="fields.email.label"></td>
									</tr>
								</tbody>
							</table>
							<div class="whatsalp-grid-2">
								<div>
									<label for="consent_text"><?php esc_html_e( 'Texto de consentimento (LGPD)', 'whatsalp' ); ?></label>
									<input type="text" id="consent_text" name="<?php echo esc_attr( $name ); ?>[consent_text]" value="<?php echo esc_attr( $s['consent_text'] ); ?>" class="large-text" data-preview="consentText">
								</div>
								<div>
									<label for="privacy_url"><?php esc_html_e( 'Link da política de privacidade', 'whatsalp' ); ?></label>
									<input type="url" id="privacy_url" name="<?php echo esc_attr( $name ); ?>[privacy_url]" value="<?php echo esc_attr( $s['privacy_url'] ); ?>" class="large-text" placeholder="https://">
								</div>
							</div>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Exibição', 'whatsalp' ); ?></h2>
							<div class="whatsalp-grid-3">
								<div>
									<label for="display_mode"><?php esc_html_e( 'Mostrar em', 'whatsalp' ); ?></label>
									<select id="display_mode" name="<?php echo esc_attr( $name ); ?>[display_mode]">
										<option value="all" <?php selected( $s['display_mode'], 'all' ); ?>><?php esc_html_e( 'Todas as páginas', 'whatsalp' ); ?></option>
										<option value="include" <?php selected( $s['display_mode'], 'include' ); ?>><?php esc_html_e( 'Somente nos IDs abaixo', 'whatsalp' ); ?></option>
										<option value="exclude" <?php selected( $s['display_mode'], 'exclude' ); ?>><?php esc_html_e( 'Todas, exceto os IDs abaixo', 'whatsalp' ); ?></option>
									</select>
									<input type="text" name="<?php echo esc_attr( $name ); ?>[display_ids]" aria-label="<?php esc_attr_e( 'IDs de páginas ou posts', 'whatsalp' ); ?>" value="<?php echo esc_attr( implode( ', ', (array) $s['display_ids'] ) ); ?>" class="regular-text whatsalp-mt" placeholder="<?php esc_attr_e( 'IDs de páginas/posts, separados por vírgula', 'whatsalp' ); ?>">
								</div>
								<div>
									<label for="delay_seconds"><?php esc_html_e( 'Atraso para aparecer (s)', 'whatsalp' ); ?></label>
									<input type="number" id="delay_seconds" min="0" max="120" name="<?php echo esc_attr( $name ); ?>[delay_seconds]" value="<?php echo esc_attr( (string) $s['delay_seconds'] ); ?>" class="small-text">
								</div>
								<div>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[display_front_page]" value="1" <?php checked( $s['display_front_page'] ); ?>> <?php esc_html_e( 'Exibir na página inicial', 'whatsalp' ); ?></label>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[display_archives]" value="1" <?php checked( $s['display_archives'] ); ?>> <?php esc_html_e( 'Exibir em arquivos, blog e busca', 'whatsalp' ); ?></label>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[display_woo_checkout]" value="1" <?php checked( $s['display_woo_checkout'] ); ?>> <?php esc_html_e( 'Exibir no carrinho/checkout do WooCommerce', 'whatsalp' ); ?></label>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[hide_on_mobile]" value="1" <?php checked( $s['hide_on_mobile'] ); ?>> <?php esc_html_e( 'Ocultar no mobile', 'whatsalp' ); ?></label>
								</div>
							</div>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Avisos por e-mail', 'whatsalp' ); ?></h2>
							<p class="description"><?php esc_html_e( 'O envio usa o e-mail do próprio site. Se houver um plugin de SMTP configurado, ele cuida da entrega.', 'whatsalp' ); ?></p>
							<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[notify_new_lead]" value="1" <?php checked( $s['notify_new_lead'] ); ?>> <?php esc_html_e( 'Avisar a cada contato capturado', 'whatsalp' ); ?></label>
							<label for="notify_emails"><?php esc_html_e( 'Contato novo vai para', 'whatsalp' ); ?></label>
							<input type="text" id="notify_emails" name="<?php echo esc_attr( $name ); ?>[notify_emails]" value="<?php echo esc_attr( (string) $s['notify_emails'] ); ?>" class="large-text" placeholder="comercial@exemplo.com.br, vendas@exemplo.com.br">
							<p class="description">
								<?php esc_html_e( 'Separe por vírgula. Em branco, vai para o e-mail do administrador do site.', 'whatsalp' ); ?>
								<?php esc_html_e( 'Responder ao aviso fala direto com o contato, quando ele informou e-mail.', 'whatsalp' ); ?>
							</p>
							<label class="whatsalp-toggle whatsalp-mt"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[notify_sync_error]" value="1" <?php checked( $s['notify_sync_error'] ); ?>> <?php esc_html_e( 'Avisar quando um contato não chegar ao CRM', 'whatsalp' ); ?></label>
							<label for="notify_error_emails"><?php esc_html_e( 'Falha no CRM vai para', 'whatsalp' ); ?></label>
							<input type="text" id="notify_error_emails" name="<?php echo esc_attr( $name ); ?>[notify_error_emails]" value="<?php echo esc_attr( (string) $s['notify_error_emails'] ); ?>" class="large-text" placeholder="suporte@exemplo.com.br">
							<p class="description">
								<?php esc_html_e( 'Alerta técnico: costuma ser outra pessoa, não o comercial. Em branco, usa a lista de contato novo.', 'whatsalp' ); ?>
								<?php esc_html_e( 'Inclui um resumo quando há contatos parados na fila ou quando o processamento deixa de rodar.', 'whatsalp' ); ?>
							</p>
							<p class="whatsalp-mt">
								<button type="button" class="button whatsalp-notify-test"><?php esc_html_e( 'Enviar e-mail de teste', 'whatsalp' ); ?></button>
								<span class="whatsalp-test-result" role="status"></span>
							</p>
							<p class="description"><?php esc_html_e( 'O teste usa os destinatários já salvos: salve antes de testar uma lista nova.', 'whatsalp' ); ?></p>
						</section>

						<section class="whatsalp-card">
							<h2><?php esc_html_e( 'Avançado', 'whatsalp' ); ?></h2>
							<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[behind_proxy]" value="1" <?php checked( $s['behind_proxy'] ); ?>> <?php esc_html_e( 'Site atrás de proxy/CDN (confiar no X-Forwarded-For)', 'whatsalp' ); ?></label>
							<label for="trusted_proxies"><?php esc_html_e( 'Proxies confiáveis adicionais (IP ou CIDR, separados por vírgula)', 'whatsalp' ); ?></label>
							<input type="text" id="trusted_proxies" name="<?php echo esc_attr( $name ); ?>[trusted_proxies]" value="<?php echo esc_attr( implode( ', ', (array) $s['trusted_proxies'] ) ); ?>" class="large-text">
							<p class="description"><?php esc_html_e( 'Cloudflare já é reconhecida automaticamente.', 'whatsalp' ); ?></p>
							<div class="whatsalp-grid-3 whatsalp-mt">
								<div>
									<label for="retention_days"><?php esc_html_e( 'Apagar leads após (dias)', 'whatsalp' ); ?></label>
									<input type="number" id="retention_days" min="0" max="3650" name="<?php echo esc_attr( $name ); ?>[retention_days]" value="<?php echo esc_attr( (string) $s['retention_days'] ); ?>" class="small-text">
									<p class="description"><?php esc_html_e( '0 = nunca.', 'whatsalp' ); ?></p>
								</div>
								<div>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[keep_data]" value="1" <?php checked( $s['keep_data'] ); ?>> <?php esc_html_e( 'Manter dados ao desinstalar', 'whatsalp' ); ?></label>
								</div>
								<div>
									<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[debug_log]" value="1" <?php checked( $s['debug_log'] ); ?>> <?php esc_html_e( 'Log de depuração', 'whatsalp' ); ?></label>
								</div>
							</div>
						</section>

						<?php submit_button( __( 'Salvar alterações', 'whatsalp' ) ); ?>
					</div>

					<aside class="whatsalp-side">
						<div class="whatsalp-preview-head">
							<strong><?php esc_html_e( 'Pré-visualização ao vivo', 'whatsalp' ); ?></strong>
							<span class="description"><?php esc_html_e( 'O envio está desativado aqui.', 'whatsalp' ); ?></span>
						</div>
						<iframe id="whatsalp-preview" title="<?php esc_attr_e( 'Pré-visualização do widget', 'whatsalp' ); ?>" src="about:blank" loading="lazy"></iframe>
						<p class="description"><?php esc_html_e( 'A prévia atualiza conforme você altera cores, textos e campos. Use "Salvar alterações" para publicar no site.', 'whatsalp' ); ?></p>
					</aside>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Uma linha do repetidor de opções.
	 *
	 * @param array<string,mixed> $option
	 */
	private static function option_row( string $name, int $index, array $option, bool $template = false ): void {
		$idx   = $template ? '__INDEX__' : (string) $index;
		$type  = (string) ( $option['type'] ?? OptionsMenu::TYPE_WHATSAPP );
		$field = static fn( string $key ) => sprintf( '%s[menu_options][%s][%s]', $name, $idx, $key );
		?>
		<div class="whatsalp-repeater-row" data-type="<?php echo esc_attr( $type ); ?>">
			<input type="hidden" name="<?php echo esc_attr( $field( 'id' ) ); ?>" value="<?php echo esc_attr( (string) ( $option['id'] ?? '' ) ); ?>">
			<div class="whatsalp-repeater-head">
				<span class="whatsalp-repeater-handle" aria-hidden="true">☰</span>
				<input type="text" class="regular-text" name="<?php echo esc_attr( $field( 'label' ) ); ?>" value="<?php echo esc_attr( (string) ( $option['label'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Texto do botão (ex.: Falar com vendas)', 'whatsalp' ); ?>" aria-label="<?php esc_attr_e( 'Texto do botão', 'whatsalp' ); ?>">
				<select class="whatsalp-option-type" name="<?php echo esc_attr( $field( 'type' ) ); ?>" aria-label="<?php esc_attr_e( 'Destino', 'whatsalp' ); ?>">
					<option value="<?php echo esc_attr( OptionsMenu::TYPE_WHATSAPP ); ?>" <?php selected( $type, OptionsMenu::TYPE_WHATSAPP ); ?>><?php esc_html_e( 'WhatsApp', 'whatsalp' ); ?></option>
					<option value="<?php echo esc_attr( OptionsMenu::TYPE_LINK ); ?>" <?php selected( $type, OptionsMenu::TYPE_LINK ); ?>><?php esc_html_e( 'Link', 'whatsalp' ); ?></option>
				</select>
				<button type="button" class="button-link whatsalp-remove-option" aria-label="<?php esc_attr_e( 'Remover opção', 'whatsalp' ); ?>">&times;</button>
			</div>
			<div class="whatsalp-repeater-fields whatsalp-only-whatsapp">
				<label><?php esc_html_e( 'Número (vazio = número padrão)', 'whatsalp' ); ?>
					<input type="tel" name="<?php echo esc_attr( $field( 'phone' ) ); ?>" value="<?php echo esc_attr( (string) ( $option['phone'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( '11999999999', 'whatsalp' ); ?>">
				</label>
				<label><?php esc_html_e( 'Mensagem de abertura (vazio = mensagem padrão)', 'whatsalp' ); ?>
					<input type="text" name="<?php echo esc_attr( $field( 'message' ) ); ?>" value="<?php echo esc_attr( (string) ( $option['message'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Olá! Sou {nome} e quero falar sobre {opcao}.', 'whatsalp' ); ?>">
				</label>
			</div>
			<div class="whatsalp-repeater-fields whatsalp-only-link">
				<label><?php esc_html_e( 'URL de destino', 'whatsalp' ); ?>
					<input type="url" name="<?php echo esc_attr( $field( 'url' ) ); ?>" value="<?php echo esc_attr( (string) ( $option['url'] ?? '' ) ); ?>" placeholder="https://">
				</label>
				<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $field( 'new_tab' ) ); ?>" value="1" <?php checked( ! empty( $option['new_tab'] ) ); ?>> <?php esc_html_e( 'Abrir em nova aba', 'whatsalp' ); ?></label>
			</div>
			<div class="whatsalp-repeater-foot">
				<label class="whatsalp-toggle whatsalp-only-before"><input type="checkbox" name="<?php echo esc_attr( $field( 'form' ) ); ?>" value="1" <?php checked( ! isset( $option['form'] ) || ! empty( $option['form'] ) ); ?>> <?php esc_html_e( 'Pedir os dados antes (captura o lead)', 'whatsalp' ); ?></label>
				<?php
				$integrations = array_filter( IntegrationRegistry::all(), static fn( $i ) => ! $i->is_internal() );
				if ( $integrations ) :
					$selected = isset( $option['integrations'] ) && is_array( $option['integrations'] ) ? $option['integrations'] : array_keys( $integrations );
					?>
					<fieldset class="whatsalp-option-integrations">
						<legend><?php esc_html_e( 'Enviar esta escolha para:', 'whatsalp' ); ?></legend>
						<?php foreach ( $integrations as $integration ) : ?>
							<label class="whatsalp-toggle"><input type="checkbox" name="<?php echo esc_attr( $field( 'integrations' ) ); ?>[]" value="<?php echo esc_attr( $integration->id() ); ?>" <?php checked( in_array( $integration->id(), $selected, true ) ); ?>> <?php echo esc_html( $integration->label() ); ?></label>
						<?php endforeach; ?>
					</fieldset>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
