<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nomes de tabela vêm de Schema, não de input.

use WhatsAlp\Install\Schema;

class SyncLogRepository {

	public const PENDING = 'pending';
	public const RUNNING = 'running';
	public const SUCCESS = 'success';
	public const ERROR   = 'error';
	public const SKIPPED = 'skipped';

	private string $table;

	public function __construct() {
		$this->table = Schema::sync_log_table();
	}

	public function table(): string {
		return $this->table;
	}

	/**
	 * Cria a linha pending (ignora se já existir para o par lead/integração).
	 */
	public function enqueue( int $lead_id, string $integration, int $delay_seconds = 90 ): void {
		global $wpdb;
		$now  = gmdate( 'Y-m-d H:i:s' );
		$next = gmdate( 'Y-m-d H:i:s', time() + $delay_seconds );
		$wpdb->query( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare(
				"INSERT IGNORE INTO {$this->table} (lead_id, integration, status, next_attempt_at, created_at, updated_at) VALUES (%d, %s, %s, %s, %s, %s)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$lead_id,
				$integration,
				self::PENDING,
				$next,
				$now,
				$now
			)
		);
	}

	/**
	 * @return array<string,mixed>|null
	 */
	public function find( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ?: null;
	}

	/**
	 * Linhas pendentes de um lead (ignora next_attempt_at) ou globais vencidas.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public function pending( ?int $lead_id, int $limit ): array {
		global $wpdb;
		if ( null !== $lead_id ) {
			$sql = $wpdb->prepare( "SELECT * FROM {$this->table} WHERE lead_id = %d AND status = %s ORDER BY id ASC LIMIT %d", $lead_id, self::PENDING, $limit ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$sql = $wpdb->prepare( "SELECT * FROM {$this->table} WHERE status = %s AND (next_attempt_at IS NULL OR next_attempt_at <= UTC_TIMESTAMP()) ORDER BY next_attempt_at ASC, id ASC LIMIT %d", self::PENDING, $limit ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $wpdb->get_results( $sql, ARRAY_A ) ?: []; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Claim atômico: só prossegue se exatamente uma linha foi afetada.
	 */
	public function claim( int $id ): bool {
		global $wpdb;
		$affected = $wpdb->query( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare(
				"UPDATE {$this->table} SET status = %s, locked_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP()
				 WHERE id = %d AND status = %s AND (locked_at IS NULL OR locked_at < UTC_TIMESTAMP() - INTERVAL 2 MINUTE)",
				self::RUNNING,
				$id,
				self::PENDING
			)
		);
		return 1 === (int) $affected;
	}

	/**
	 * @param array<string,mixed> $data
	 */
	public function update( int $id, array $data ): void {
		global $wpdb;
		$data['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		$wpdb->update( $this->table, $data, [ 'id' => $id ] );
	}

	/**
	 * Persiste o estado intermediário da máquina de estados.
	 *
	 * @param array<string,mixed> $state
	 */
	public function save_state( int $id, array $state ): void {
		$data = [];
		if ( isset( $state['step'] ) ) {
			$data['step'] = (string) $state['step'];
		}
		if ( isset( $state['external_person_id'] ) ) {
			$data['external_person_id'] = (string) $state['external_person_id'];
		}
		if ( isset( $state['external_id'] ) ) {
			$data['external_id'] = (string) $state['external_id'];
		}
		if ( $data ) {
			$this->update( $id, $data );
		}
	}

	/**
	 * @return array<int, array<string,mixed>>
	 */
	public function for_lead( int $lead_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE lead_id = %d ORDER BY id ASC", $lead_id ), ARRAY_A ) ?: []; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Recupera running travadas (processo morto) e marca stuck/expired.
	 */
	public function housekeeping(): void {
		global $wpdb;
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$this->table} SET status = %s, locked_at = NULL, updated_at = UTC_TIMESTAMP() WHERE status = %s AND locked_at < UTC_TIMESTAMP() - INTERVAL 2 MINUTE", self::PENDING, self::RUNNING ) );
		$wpdb->query( $wpdb->prepare( "UPDATE {$this->table} SET status = %s, last_error = 'stuck', updated_at = UTC_TIMESTAMP() WHERE status = %s AND updated_at < UTC_TIMESTAMP() - INTERVAL 24 HOUR AND (next_attempt_at IS NULL OR next_attempt_at <= UTC_TIMESTAMP())", self::ERROR, self::PENDING ) );
		$wpdb->query( $wpdb->prepare( "UPDATE {$this->table} SET status = %s, last_error = 'expired', updated_at = UTC_TIMESTAMP() WHERE status = %s AND created_at < UTC_TIMESTAMP() - INTERVAL 48 HOUR", self::ERROR, self::PENDING ) );
		// phpcs:enable
	}

	/**
	 * Fotografia da fila para o resumo de pendências: o que não entregou e o que
	 * está parado. "Parado" é pendente com a hora de tentar já vencida há mais de
	 * uma hora — o sweeper roda a cada 5 minutos, então isso significa que ninguém
	 * processou.
	 *
	 * @return array{error:int, stuck:int, oldest:?string}
	 */
	public function health_counts(): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					SUM( status = %s ) AS errors,
					SUM( status = %s AND ( next_attempt_at IS NULL OR next_attempt_at <= UTC_TIMESTAMP() - INTERVAL 1 HOUR ) AND updated_at <= UTC_TIMESTAMP() - INTERVAL 1 HOUR ) AS stuck,
					MIN( IF( status IN ( %s, %s ), created_at, NULL ) ) AS oldest
				 FROM {$this->table}
				 WHERE status IN ( %s, %s )",
				self::ERROR,
				self::PENDING,
				self::ERROR,
				self::PENDING,
				self::ERROR,
				self::PENDING
			),
			ARRAY_A
		);
		// phpcs:enable
		return [
			'error'  => (int) ( $row['errors'] ?? 0 ),
			'stuck'  => (int) ( $row['stuck'] ?? 0 ),
			'oldest' => isset( $row['oldest'] ) && $row['oldest'] ? (string) $row['oldest'] : null,
		];
	}

	public function prune_success( int $days ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$this->table} WHERE status = %s AND updated_at < UTC_TIMESTAMP() - INTERVAL %d DAY", self::SUCCESS, $days ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
}
