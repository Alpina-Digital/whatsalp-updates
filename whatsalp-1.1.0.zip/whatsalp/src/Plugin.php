<?php
declare(strict_types=1);

namespace WhatsAlp;

use WhatsAlp\Admin\Capabilities;
use WhatsAlp\Admin\Menu;
use WhatsAlp\Admin\PrivacyTools;
use WhatsAlp\Admin\SiteHealth;
use WhatsAlp\Cron\DailyMaintenance;
use WhatsAlp\Cron\SyncSweeper;
use WhatsAlp\Frontend\Widget;
use WhatsAlp\Http\AdminController;
use WhatsAlp\Http\AjaxFallback;
use WhatsAlp\Http\ExportController;
use WhatsAlp\Http\LeadController;
use WhatsAlp\Http\LogDownloadController;
use WhatsAlp\Install\Upgrader;
use WhatsAlp\Integrations\IntegrationRegistry;
use WhatsAlp\Settings\Settings;
use WhatsAlp\Support\UpdateChecker;

/**
 * Bootstrap do plugin: registra hooks e serviços.
 */
final class Plugin {

	private static ?Plugin $instance = null;

	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( 'plugins_loaded', [ Upgrader::class, 'maybe_upgrade' ], 5 );
		add_action( 'init', [ $this, 'load_textdomain' ], 1 );
		add_action( 'init', [ $this, 'ensure_cron' ], 20 );
		add_action( 'wp_initialize_site', [ \WhatsAlp\Install\Activator::class, 'on_new_site' ], 100 );

		( new Capabilities() )->register();
		( new Settings() )->register();
		( new IntegrationRegistry() )->register();

		( new LeadController() )->register();
		( new AjaxFallback() )->register();
		( new AdminController() )->register();
		( new ExportController() )->register();
		( new LogDownloadController() )->register();

		( new Widget() )->register();

		( new SyncSweeper() )->register();
		( new DailyMaintenance() )->register();

		if ( is_admin() ) {
			( new Menu() )->register();
			( new SiteHealth() )->register();
			( new PrivacyTools() )->register();
		}

		( new UpdateChecker() )->register();
	}

	public function load_textdomain(): void {
		load_plugin_textdomain( 'whatsalp', false, dirname( WHATSALP_BASENAME ) . '/languages' );
	}

	/**
	 * Auto-cura dos crons: eventos somem com plugins de limpeza e o Activator
	 * não roda em sites clonados. Guarda de 1 h via transient.
	 */
	public function ensure_cron(): void {
		// wp_next_scheduled lê a option "cron" (autoload): mais barato que qualquer guarda por transient.
		SyncSweeper::schedule();
		DailyMaintenance::schedule();
	}
}
