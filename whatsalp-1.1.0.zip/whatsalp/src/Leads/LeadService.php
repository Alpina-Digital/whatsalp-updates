<?php
declare(strict_types=1);

namespace WhatsAlp\Leads;

use WhatsAlp\Http\InternalTrigger;
use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Security\ClientIp;
use WhatsAlp\Security\Honeypot;
use WhatsAlp\Security\RateLimiter;
use WhatsAlp\Settings\OptionsMenu;
use WhatsAlp\Settings\Settings;
use WhatsAlp\Support\Logger;

/**
 * Cria leads. Ordem obrigatória: honeypot → normalizar telefone → rate limit →
 * validar → dedupe → persistir → enfileirar → responder.
 */
final class LeadService {

	public const UTM_KEYS = [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid' ];

	private LeadRepository $leads;
	private Dispatcher $dispatcher;

	public function __construct( ?LeadRepository $leads = null, ?Dispatcher $dispatcher = null ) {
		$this->leads      = $leads ?? new LeadRepository();
		$this->dispatcher = $dispatcher ?? new Dispatcher();
	}

	/**
	 * @param array<string,mixed> $input Corpo do request (já decodificado).
	 * @param array<string,string> $server $_SERVER.
	 * @return array<string,mixed>|\WP_Error Payload de sucesso ou erro com code whatsalp_*.
	 */
	public function create( array $input, array $server ) {
		// 0. Opção escolhida no menu: o destino vem SEMPRE da configuração, nunca do visitante.
		$option = OptionsMenu::is_active() ? OptionsMenu::find( sanitize_key( (string) ( $input['menu_option'] ?? '' ) ) ) : null;

		// 1. Honeypot: 200 com payload plausível, nada gravado.
		if ( Honeypot::triggered( $input ) ) {
			Logger::info( 'honeypot' );
			return $this->fake_payload( (string) ( $input['name'] ?? '' ), $option );
		}

		// 2. Telefone antes do rate limit (sem I/O), inválido → 400 sem contar.
		$phone_raw = (string) ( $input['phone'] ?? '' );
		$phone     = PhoneBR::normalize( $phone_raw );
		if ( null === $phone ) {
			return new \WP_Error( 'whatsalp_invalid_phone', __( 'Informe um telefone válido com DDD.', 'whatsalp' ), [ 'status' => 400 ] );
		}

		// 3. Rate limit: IP, telefone normalizado e disjuntor global.
		$ip = ClientIp::resolve( $server );
		if ( $ip && RateLimiter::hit( 'ip', ClientIp::bucket( $ip ), 5, 10 * MINUTE_IN_SECONDS ) ) {
			return $this->rate_limited();
		}
		if ( RateLimiter::hit( 'phone', $phone, 5, 10 * MINUTE_IN_SECONDS ) ) {
			return $this->rate_limited();
		}
		if ( RateLimiter::hit( 'global', 'all', 60, MINUTE_IN_SECONDS ) ) {
			return $this->rate_limited();
		}

		// 4. Validação restante.
		$name    = sanitize_text_field( (string) ( $input['name'] ?? '' ) );
		$email   = sanitize_email( (string) ( $input['email'] ?? '' ) );
		$company = mb_substr( sanitize_text_field( (string) ( $input['company'] ?? '' ) ), 0, 190 );
		if ( Settings::get( 'field_company_show' ) && Settings::get( 'field_company_required' ) && '' === $company ) {
			return new \WP_Error( 'whatsalp_missing_company', __( 'Informe a empresa.', 'whatsalp' ), [ 'status' => 400 ] );
		}
		if ( Settings::get( 'field_name_show' ) && Settings::get( 'field_name_required' ) && '' === $name ) {
			return new \WP_Error( 'whatsalp_missing_name', __( 'Informe seu nome.', 'whatsalp' ), [ 'status' => 400 ] );
		}
		if ( Settings::get( 'field_email_show' ) && Settings::get( 'field_email_required' ) && ! is_email( $email ) ) {
			return new \WP_Error( 'whatsalp_invalid_email', __( 'Informe um e-mail válido.', 'whatsalp' ), [ 'status' => 400 ] );
		}
		if ( '' !== $email && ! is_email( $email ) ) {
			$email = '';
		}
		if ( empty( $input['consent'] ) ) {
			return new \WP_Error( 'whatsalp_missing_consent', __( 'É preciso aceitar o consentimento para continuar.', 'whatsalp' ), [ 'status' => 400 ] );
		}
		$verified = apply_filters( 'whatsalp_verify_submission', true, $input, $server );
		if ( true !== $verified ) {
			return new \WP_Error( 'whatsalp_verification_failed', __( 'Não foi possível validar o envio. Tente novamente.', 'whatsalp' ), [ 'status' => 400 ] );
		}

		// 5. Dedupe: mesmo telefone em 60 min → não cria outro lead nem outra linha de sync.
		// A resposta é montada só com o que ESTE envio trouxe: quem conhece um telefone
		// não pode obter nome, e-mail ou token de um lead anterior.
		$existing = $this->leads->find_recent_by_phone( $phone, 60 );
		if ( $existing ) {
			$patch = [];
			if ( '' === $existing->name && '' !== $name ) {
				$patch['name'] = $name;
			}
			if ( empty( $existing->email ) && '' !== $email ) {
				$patch['email'] = $email;
			}
			if ( empty( $existing->company ) && '' !== $company ) {
				$patch['company'] = $company;
			}
			if ( $patch ) {
				// Enriquecer só o que estava vazio: não sobrescreve dados do primeiro envio.
				$this->leads->update( $existing->id, $patch );
			}
			$echo        = new Lead();
			$echo->id    = 0;
			$echo->name  = $name;
			$echo->phone = $phone;
			$echo->email = '' === $email ? null : $email;
			$echo->company = '' === $company ? null : $company;
			$echo->menu_option = null === $option ? null : (string) $option['label'];
			$echo->menu_option_id = null === $option ? null : (string) $option['id'];
			$echo->source_title = isset( $input['source_title'] ) ? sanitize_text_field( (string) $input['source_title'] ) : null;
			return $this->payload( $echo, $option );
		}

		// 6. Persistência.
		$lead                     = new Lead();
		$lead->lead_token         = bin2hex( random_bytes( 16 ) );
		$lead->name               = mb_substr( $name, 0, 190 );
		$lead->phone              = $phone;
		$lead->phone_raw          = mb_substr( $phone_raw, 0, 40 );
		$lead->email              = '' === $email ? null : mb_substr( $email, 0, 190 );
		$lead->company            = '' === $company ? null : $company;
		$lead->menu_option        = null === $option ? null : (string) $option['label'];
		$lead->menu_option_id     = null === $option ? null : (string) $option['id'];
		$lead->source_url         = $this->source_url( $input, $server );
		$lead->source_path        = $lead->source_url ? mb_substr( (string) wp_parse_url( $lead->source_url, PHP_URL_PATH ), 0, 255 ) : null;
		$lead->source_title       = isset( $input['source_title'] ) ? mb_substr( sanitize_text_field( (string) $input['source_title'] ), 0, 255 ) : null;
		$lead->utm                = $this->utm( $input['utm'] ?? [] );
		$lead->consent            = true;
		$lead->consent_text       = wp_strip_all_tags( (string) Settings::get( 'consent_text' ) );
		$lead->consent_policy_url = (string) Settings::get( 'privacy_url' ) ?: null;
		$lead->ip_hash            = $ip ? hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ) : null;
		$lead->user_agent         = isset( $server['HTTP_USER_AGENT'] ) ? mb_substr( sanitize_text_field( (string) $server['HTTP_USER_AGENT'] ), 0, 255 ) : null;
		$lead->created_at         = gmdate( 'Y-m-d H:i:s' );
		$lead->sync_status        = 'none';
		$this->leads->insert( $lead );

		// 7. Linhas pending por integração ativa.
		$lead->sync_status = $this->dispatcher->enqueue( $lead );
		if ( 'none' !== $lead->sync_status ) {
			$this->leads->update( $lead->id, [ 'sync_status' => $lead->sync_status ] );
		}

		// 8. Evento (sem I/O nos listeners do núcleo).
		do_action( 'whatsalp_lead_created', $lead );
		Logger::info( 'lead created', [ 'id' => $lead->id ] );

		// 9. Resposta; o InternalTrigger é acionado pelo controller após responder.
		return $this->payload( $lead, $option );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function payload( Lead $lead, ?array $option = null ): array {
		$destination = OptionsMenu::destination( $option, $lead );
		return [
			'lead_id'     => $lead->id,
			'lead_token'  => $lead->lead_token,
			'wa_url'      => $destination,
			'destination' => $destination,
			'destination_type' => null !== $option && OptionsMenu::TYPE_LINK === $option['type'] ? OptionsMenu::TYPE_LINK : OptionsMenu::TYPE_WHATSAPP,
			'destination_new_tab' => null !== $option && OptionsMenu::TYPE_LINK === $option['type'] ? (bool) $option['new_tab'] : null,
			'sync_url'    => rest_url( 'whatsalp/v1/leads/' . $lead->id . '/sync' ),
			'clicked_url' => rest_url( 'whatsalp/v1/leads/' . $lead->id . '/clicked' ),
			'ajax_url'    => admin_url( 'admin-ajax.php' ),
			'first_name'  => $lead->first_name(),
		];
	}

	/**
	 * @return array<string,mixed>
	 */
	private function fake_payload( string $name, ?array $option = null ): array {
		$lead             = new Lead();
		$lead->id         = wp_rand( 100000, 999999 );
		$lead->lead_token = bin2hex( random_bytes( 16 ) );
		$lead->name       = sanitize_text_field( $name );
		return $this->payload( $lead, $option );
	}

	private function rate_limited(): \WP_Error {
		return new \WP_Error( 'whatsalp_rate_limited', __( 'Muitas tentativas. Aguarde alguns minutos e tente de novo.', 'whatsalp' ), [ 'status' => 429 ] );
	}

	public static function wa_url( Lead $lead ): string {
		return OptionsMenu::destination( null, $lead );
	}

	public static function render_message( string $template, Lead $lead ): string {
		return OptionsMenu::render( $template, $lead );
	}

	/**
	 * @param array<string,mixed> $input
	 * @param array<string,string> $server
	 */
	private function source_url( array $input, array $server ): ?string {
		$candidates = [
			isset( $input['source_url'] ) ? esc_url_raw( (string) $input['source_url'] ) : '',
			! empty( $server['HTTP_REFERER'] ) ? esc_url_raw( (string) $server['HTTP_REFERER'] ) : '',
		];
		foreach ( $candidates as $url ) {
			// Só URLs do próprio site: evita link de phishing dentro do painel e do CRM.
			if ( '' !== $url && \WhatsAlp\Http\OriginCheck::matches( $url ) ) {
				return mb_substr( $url, 0, 2000 );
			}
		}
		return null;
	}

	/**
	 * @param mixed $raw
	 * @return array<string,string>
	 */
	private function utm( $raw ): array {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : [];
		}
		if ( ! is_array( $raw ) ) {
			return [];
		}
		$out = [];
		foreach ( self::UTM_KEYS as $key ) {
			if ( isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) && '' !== (string) $raw[ $key ] ) {
				$out[ $key ] = mb_substr( sanitize_text_field( (string) $raw[ $key ] ), 0, 200 );
			}
		}
		return $out;
	}

	/**
	 * Processa as linhas pending de um lead (acelerador do navegador / disparo interno).
	 */
	public function sync( Lead $lead ): int {
		return $this->dispatcher->process( $lead->id, 10 );
	}

	public function clicked( Lead $lead ): void {
		$this->leads->mark_clicked( $lead->id );
	}

	public function repository(): LeadRepository {
		return $this->leads;
	}

	public function trigger_after_response( Lead $lead ): void {
		InternalTrigger::fire( $lead->id );
	}
}
