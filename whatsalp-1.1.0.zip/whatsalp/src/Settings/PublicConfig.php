<?php
declare(strict_types=1);

namespace WhatsAlp\Settings;

use WhatsAlp\Leads\FormToken;
use WhatsAlp\Security\Honeypot;

/**
 * Allowlist do que vai ao front. Nunca segredos nem whatsalp_integrations.
 */
final class PublicConfig {

	/**
	 * @return array<string,mixed>
	 */
	public static function get( bool $preview = false ): array {
		$s      = Settings::all();
		$avatar = $s['avatar_id'] ? wp_get_attachment_image_url( (int) $s['avatar_id'], 'thumbnail' ) : '';
		$config = [
			'version'        => WHATSALP_VERSION,
			'preview'        => $preview,
			'number'         => Settings::wa_number(),
			'message'        => $s['wa_message'],
			'siteName'       => wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES ),
			'displayName'    => $s['display_name'],
			'subtitle'       => $s['display_subtitle'],
			'avatar'         => $avatar ?: '',
			'welcome'        => $s['welcome_text'],
			'afterSubmit'    => $s['after_submit'],
			'redirectDelay'  => (int) $s['redirect_delay'],
			'newTab'         => (bool) $s['open_new_tab'],
			'theme'          => $s['theme'],
			'colors'         => [
				'primary' => $s['color_primary'],
				'panel'   => $s['color_panel'],
				'text'    => $s['color_text'],
			],
			'position'       => $s['position'],
			'margin'         => (int) $s['margin'],
			'bubble'         => (bool) $s['bubble_enabled'],
			'bubbleText'     => $s['bubble_text'],
			'fields'         => [
				'name'  => [ 'show' => (bool) $s['field_name_show'], 'required' => (bool) $s['field_name_required'], 'label' => $s['field_name_label'] ],
				'phone' => [ 'show' => true, 'required' => true, 'label' => $s['field_phone_label'] ],
				'company' => [ 'show' => (bool) $s['field_company_show'], 'required' => (bool) $s['field_company_required'], 'label' => $s['field_company_label'] ],
				'email' => [ 'show' => (bool) $s['field_email_show'], 'required' => (bool) $s['field_email_required'], 'label' => $s['field_email_label'] ],
			],
			'menu'           => OptionsMenu::is_active() ? [ 'question' => $s['menu_question'], 'options' => OptionsMenu::public_options() ] : null,
			'consentText'    => $s['consent_text'],
			'privacyUrl'     => $s['privacy_url'],
			'hideOnMobile'   => (bool) $s['hide_on_mobile'],
			'delay'          => (int) $s['delay_seconds'],
			'honeypot'       => Honeypot::FIELD,
			'formToken'      => FormToken::issue(),
			'urls'           => [
				'leads'     => rest_url( 'whatsalp/v1/leads' ),
				'formToken' => rest_url( 'whatsalp/v1/form-token' ),
				'ajax'      => admin_url( 'admin-ajax.php' ),
			],
			'i18n'           => self::strings(),
		];
		return (array) apply_filters( 'whatsalp_public_config', $config );
	}

	/**
	 * @return array<string,string>
	 */
	public static function strings(): array {
		return [
			'open'          => __( 'Abrir conversa no WhatsApp', 'whatsalp' ),
			'close'         => __( 'Fechar', 'whatsalp' ),
			'closeBubble'   => __( 'Fechar aviso', 'whatsalp' ),
			'continue'      => __( 'Continuar', 'whatsalp' ),
			'sending'       => __( 'Enviando...', 'whatsalp' ),
			'openWhatsApp'  => __( 'Abrir WhatsApp', 'whatsalp' ),
			'thanks'        => __( 'Obrigado, {nome}! Tudo pronto. Clique abaixo para continuar a conversa no WhatsApp.', 'whatsalp' ),
			'thanksNoName'  => __( 'Tudo pronto! Clique abaixo para continuar a conversa no WhatsApp.', 'whatsalp' ),
			'thanksLink'    => __( 'Obrigado, {nome}! Clique abaixo para continuar.', 'whatsalp' ),
			'thanksLinkNoName' => __( 'Tudo pronto! Clique abaixo para continuar.', 'whatsalp' ),
			'redirecting'   => __( 'Abrindo automaticamente em {s} segundos', 'whatsalp' ),
			'redirectingOne' => __( 'Abrindo automaticamente em 1 segundo', 'whatsalp' ),
			'popupBlocked'  => __( 'Seu navegador bloqueou a abertura automática. Abrindo nesta aba...', 'whatsalp' ),
			'required'      => __( 'Preencha os campos obrigatórios.', 'whatsalp' ),
			'invalidPhone'  => __( 'Informe um telefone válido com DDD.', 'whatsalp' ),
			'invalidEmail'  => __( 'Informe um e-mail válido.', 'whatsalp' ),
			'consent'       => __( 'Marque o consentimento para continuar.', 'whatsalp' ),
			'genericError'  => __( 'Não foi possível enviar agora. Você ainda pode falar conosco pelo WhatsApp.', 'whatsalp' ),
			'phonePlaceholder' => __( '(11) 99999-9999', 'whatsalp' ),
			'namePlaceholder'  => __( 'Seu nome', 'whatsalp' ),
			'emailPlaceholder' => __( 'voce@empresa.com.br', 'whatsalp' ),
			'companyPlaceholder' => __( 'Nome da empresa', 'whatsalp' ),
			'openLink'      => __( 'Continuar', 'whatsalp' ),
			'back'          => __( 'Voltar', 'whatsalp' ),
			'chooseOption'  => __( 'Escolha uma opção para continuar.', 'whatsalp' ),
			'poweredBy'     => __( 'Protegido por', 'whatsalp' ),
			'privacy'       => __( 'Política de Privacidade', 'whatsalp' ),
			'previewNotice' => __( 'Pré-visualização: o envio está desativado.', 'whatsalp' ),
		];
	}
}
