<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Admin\Capabilities;
use WhatsAlp\Install\Schema;
use WhatsAlp\Leads\PhoneBR;

/**
 * CSV em streaming por admin-post (nunca nopriv). Cursor por id, sem OFFSET.
 */
final class ExportController {

	public const ACTION = 'whatsalp_export';

	public function register(): void {
		add_action( 'admin_post_' . self::ACTION, [ $this, 'export' ] );
	}

	public function export(): void {
		if ( ! current_user_can( Capabilities::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'whatsalp' ), 403 );
		}
		check_admin_referer( self::ACTION );

		$delimiter = isset( $_GET['delimiter'] ) && ',' === $_GET['delimiter'] ? ',' : ';'; // phpcs:ignore WordPress.Security.NonceVerification
		$ids       = [];
		if ( ! empty( $_GET['ids'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$key    = sanitize_key( (string) wp_unslash( $_GET['ids'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			$stored = get_transient( 'whatsalp_export_' . $key );
			delete_transient( 'whatsalp_export_' . $key );
			if ( ! is_array( $stored ) || ! $stored ) {
				wp_die( esc_html__( 'A seleção para exportar expirou. Volte à lista e selecione de novo.', 'whatsalp' ) );
			}
			$ids = array_filter( array_map( 'intval', $stored ) );
		}
		$filters = [
			'search' => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
			'from'   => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
			'to'     => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
			'source' => isset( $_GET['source'] ) ? sanitize_text_field( wp_unslash( $_GET['source'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
			'sync'   => isset( $_GET['sync'] ) ? sanitize_key( wp_unslash( $_GET['sync'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
		];

		self::stream( $ids, $filters, $delimiter );
	}

	/**
	 * @param int[] $ids
	 * @param array<string,string> $filters
	 */
	public static function stream( array $ids, array $filters, string $delimiter ): void {
		global $wpdb;
		@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="whatsalp-contatos-' . gmdate( 'Ymd-His' ) . '.csv"' );
		header( 'X-Accel-Buffering: no' );

		$tz  = wp_timezone_string();
		$out = fopen( 'php://output', 'w' );
		if ( ! $out ) {
			exit;
		}
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$header = [
			__( 'ID', 'whatsalp' ),
			__( 'Nome', 'whatsalp' ),
			__( 'Telefone', 'whatsalp' ),
			__( 'Telefone (só dígitos, com DDI)', 'whatsalp' ),
			__( 'E-mail', 'whatsalp' ),
			__( 'Empresa', 'whatsalp' ),
			__( 'Escolha no menu', 'whatsalp' ),
			__( 'Página de origem', 'whatsalp' ),
			__( 'Título da página', 'whatsalp' ),
			'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid',
			__( 'Consentimento', 'whatsalp' ),
			__( 'Status CRM', 'whatsalp' ),
			__( 'Clicou no WhatsApp', 'whatsalp' ) . " ({$tz})",
			__( 'Data', 'whatsalp' ) . " ({$tz})",
		];
		self::row( $out, $header, $delimiter );

		$table   = Schema::leads_table();
		$where   = [ '1=1' ];
		$params  = [];
		if ( $ids ) {
			$where[]  = 'id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
			$params   = array_merge( $params, $ids );
		} else {
			self::build_where( $filters, $where, $params );
		}
		$last = 0;
		do {
			$sql  = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' AND id > %d ORDER BY id ASC LIMIT 500';
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, [ $last ] ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			foreach ( $rows ?: [] as $r ) {
				$last = (int) $r['id'];
				$utm  = json_decode( (string) $r['utm'], true );
				$utm  = is_array( $utm ) ? $utm : [];
				self::row(
					$out,
					[
						$r['id'],
						$r['name'],
						ltrim( PhoneBR::format( (string) $r['phone'] ), '+' ), // sem "+" para não virar fórmula nem receber aspas
						(string) $r['phone'],
						$r['email'],
						$r['company'],
						$r['menu_option'],
						$r['source_url'],
						$r['source_title'],
						$utm['utm_source'] ?? '', $utm['utm_medium'] ?? '', $utm['utm_campaign'] ?? '', $utm['utm_term'] ?? '', $utm['utm_content'] ?? '', $utm['gclid'] ?? '', $utm['fbclid'] ?? '',
						$r['consent'] ? __( 'sim', 'whatsalp' ) : __( 'não', 'whatsalp' ),
						$r['sync_status'],
						$r['wa_clicked_at'] ? wp_date( 'Y-m-d H:i:s', strtotime( $r['wa_clicked_at'] . ' UTC' ) ) : '',
						wp_date( 'Y-m-d H:i:s', strtotime( $r['created_at'] . ' UTC' ) ),
					],
					$delimiter
				);
			}
			flush();
			$fetched = count( $rows ?: [] );
		} while ( 500 === $fetched );
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/**
	 * @param array<string,string> $filters
	 * @param string[] $where
	 * @param array<int,mixed> $params
	 */
	public static function build_where( array $filters, array &$where, array &$params ): void {
		global $wpdb;
		if ( '' !== $filters['search'] ) {
			$like     = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
			$digits   = preg_replace( '/\D+/', '', $filters['search'] ) ?? '';
			$where[]  = '(name LIKE %s OR email LIKE %s OR company LIKE %s' . ( '' !== $digits ? ' OR phone LIKE %s' : '' ) . ')';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			if ( '' !== $digits ) {
				$params[] = '%' . $wpdb->esc_like( $digits ) . '%';
			}
		}
		if ( '' !== $filters['from'] ) {
			$where[]  = 'created_at >= %s';
			$params[] = get_gmt_from_date( $filters['from'] . ' 00:00:00' );
		}
		if ( '' !== $filters['to'] ) {
			$where[]  = 'created_at <= %s';
			$params[] = get_gmt_from_date( $filters['to'] . ' 23:59:59' );
		}
		if ( '' !== $filters['source'] ) {
			$where[]  = 'source_path = %s';
			$params[] = $filters['source'];
		}
		if ( '' !== $filters['sync'] ) {
			$where[]  = 'sync_status = %s';
			$params[] = $filters['sync'];
		}
	}

	/**
	 * @param resource $out
	 * @param array<int,mixed> $fields
	 */
	private static function row( $out, array $fields, string $delimiter ): void {
		$safe = array_map( [ self::class, 'cell' ], $fields );
		// php://output não aceita seek: monta a linha em memória para trocar o LF por CRLF
		// (o parâmetro $eol do fputcsv só existe no PHP 8.1).
		$tmp = fopen( 'php://temp', 'r+' );
		if ( ! $tmp ) {
			return;
		}
		fputcsv( $tmp, $safe, $delimiter, '"', '' );
		rewind( $tmp );
		$line = rtrim( (string) stream_get_contents( $tmp ), "\n" );
		fclose( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, $line . "\r\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * @param mixed $value
	 */
	private static function cell( $value ): string {
		$value = null === $value ? '' : (string) $value;
		if ( '' !== $value && in_array( $value[0], [ '=', '+', '-', '@', "\t", "\r" ], true ) && "'" !== $value[0] ) {
			$value = "'" . $value;
		}
		return $value;
	}
}
