<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

use WhatsAlp\Integrations\Dispatcher;
use WhatsAlp\Leads\LeadService;

/**
 * Fallback por admin-ajax (REST pode estar bloqueado para anônimos) e alvo do
 * loopback interno. Só estes quatro actions são nopriv.
 */
final class AjaxFallback {

	private LeadService $service;

	public function __construct( ?LeadService $service = null ) {
		$this->service = $service ?? new LeadService();
	}

	public function register(): void {
		foreach ( [ 'whatsalp_lead' => 'lead', 'whatsalp_sync' => 'sync', 'whatsalp_clicked' => 'clicked', InternalTrigger::ACTION => 'process' ] as $action => $method ) {
			add_action( 'wp_ajax_nopriv_' . $action, [ $this, $method ] );
			add_action( 'wp_ajax_' . $action, [ $this, $method ] );
		}
	}

	public function lead(): void {
		$this->send( LeadController::handle_create( $this->service, $this->input(), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	public function sync(): void {
		$in = $this->input();
		$this->send( LeadController::handle_sync( $this->service, (int) ( $in['lead_id'] ?? 0 ), (string) ( $in['lead_token'] ?? '' ), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	public function clicked(): void {
		$in = $this->input();
		$this->send( LeadController::handle_clicked( $this->service, (int) ( $in['lead_id'] ?? 0 ), (string) ( $in['lead_token'] ?? '' ), $_SERVER ) ); // phpcs:ignore WordPress.Security
	}

	public function process(): void {
		$in      = $this->input();
		$lead_id = (int) ( $in['lead_id'] ?? 0 );
		if ( ! InternalTrigger::verify( $lead_id, (string) ( $in['ts'] ?? '' ), (string) ( $in['sig'] ?? '' ) ) ) {
			wp_send_json( [ 'code' => 'whatsalp_forbidden' ], 403 );
		}
		@ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		( new Dispatcher() )->process( $lead_id, 10 );
		wp_send_json( [ 'ok' => true ], 200 );
	}

	/**
	 * JSON ou form-urlencoded.
	 *
	 * @return array<string,mixed>
	 */
	private function input(): array {
		$type = isset( $_SERVER['CONTENT_TYPE'] ) ? (string) $_SERVER['CONTENT_TYPE'] : ''; // phpcs:ignore WordPress.Security
		if ( str_contains( $type, 'application/json' ) ) {
			$raw  = (string) file_get_contents( 'php://input' );
			$json = json_decode( $raw, true );
			if ( is_array( $json ) ) {
				return $json;
			}
		}
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security
	}

	/**
	 * @param array<string,mixed>|\WP_Error $result
	 */
	private function send( $result ): void {
		nocache_headers();
		if ( is_wp_error( $result ) ) {
			$data   = $result->get_error_data();
			$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 400;
			wp_send_json( [ 'code' => $result->get_error_code(), 'message' => $result->get_error_message() ], $status );
		}
		$status = (int) ( $result['status'] ?? 200 );
		unset( $result['status'] );
		if ( 204 === $status ) {
			status_header( 204 );
			InternalTrigger::run_after();
			exit;
		}
		// wp_send_json chama wp_die → shutdown roda e dispara o InternalTrigger.
		wp_send_json( $result, $status );
	}
}
