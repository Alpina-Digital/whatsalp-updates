<?php
declare(strict_types=1);

namespace WhatsAlp\Http;

/**
 * Origin obrigatório nos POST públicos, com período de observação de 14 dias.
 */
final class OriginCheck {

	/**
	 * @param array<string,string> $server
	 * @return bool true = permitido.
	 */
	public static function allowed( array $server ): bool {
		$origin = isset( $server['HTTP_ORIGIN'] ) ? trim( (string) $server['HTTP_ORIGIN'] ) : '';
		$ok     = '' !== $origin && self::matches( $origin );
		if ( $ok ) {
			return true;
		}
		if ( ! self::enforcing() ) {
			self::count_block();
			return true;
		}
		self::count_block();
		return false;
	}

	public static function enforcing(): bool {
		$default = (int) get_option( 'whatsalp_origin_enforce_from', 0 );
		if ( 0 === $default ) {
			$default = (int) get_option( 'whatsalp_installed_at', time() ) + 14 * DAY_IN_SECONDS;
			update_option( 'whatsalp_origin_enforce_from', $default, false );
		}
		return (bool) apply_filters( 'whatsalp_enforce_origin', time() >= $default );
	}

	public static function matches( string $origin ): bool {
		$host = strtolower( (string) wp_parse_url( $origin, PHP_URL_HOST ) );
		if ( '' === $host ) {
			return false;
		}
		$allowed = [];
		foreach ( [ home_url(), site_url() ] as $url ) {
			$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
			if ( $h ) {
				$allowed[] = $h;
				$allowed[] = str_starts_with( $h, 'www.' ) ? substr( $h, 4 ) : 'www.' . $h;
			}
		}
		foreach ( (array) get_allowed_http_origins() as $o ) {
			$h = strtolower( (string) wp_parse_url( (string) $o, PHP_URL_HOST ) );
			if ( $h ) {
				$allowed[] = $h;
			}
		}
		$allowed = array_merge( $allowed, (array) apply_filters( 'whatsalp_allowed_origins', [] ) );
		return in_array( $host, array_unique( $allowed ), true );
	}

	/**
	 * Um contador por dia em transient de 48 h: sem reescrever option a cada request.
	 */
	private static function count_block(): void {
		$key = 'whatsalp_origin_blk_' . gmdate( 'Ymd' );
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, 'whatsalp', 2 * DAY_IN_SECONDS );
			wp_cache_incr( $key, 1, 'whatsalp' );
			return;
		}
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, 2 * DAY_IN_SECONDS );
	}

	public static function blocks_last_24h(): int {
		$total = 0;
		foreach ( [ gmdate( 'Ymd' ), gmdate( 'Ymd', time() - DAY_IN_SECONDS ) ] as $day ) {
			$key    = 'whatsalp_origin_blk_' . $day;
			$total += wp_using_ext_object_cache() ? (int) wp_cache_get( $key, 'whatsalp' ) : (int) get_transient( $key );
		}
		return $total;
	}
}
