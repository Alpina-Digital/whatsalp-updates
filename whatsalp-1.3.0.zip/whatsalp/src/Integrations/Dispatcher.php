<?php
declare(strict_types=1);

namespace WhatsAlp\Integrations;

use WhatsAlp\Leads\Lead;
use WhatsAlp\Leads\LeadRepository;
use WhatsAlp\Settings\OptionsMenu;
use WhatsAlp\Support\Logger;

/**
 * Processa linhas pending de sync_log com claim atômico e orçamento de tempo.
 */
final class Dispatcher {

	public const BUDGET_SECONDS = 20;
	private const BACKOFF       = [ 60, 600, 3600, 21600, 86400 ];
	private const MAX_ATTEMPTS  = 6; // 5 backoffs (1 min … 24 h) + a tentativa inicial
	private const MAX_429       = 20;

	private SyncLogRepository $log;
	private LeadRepository $leads;

	public function __construct( ?SyncLogRepository $log = null, ?LeadRepository $leads = null ) {
		$this->log   = $log ?? new SyncLogRepository();
		$this->leads = $leads ?? new LeadRepository();
	}

	/**
	 * Cria as linhas pending para o lead e devolve o sync_status inicial.
	 *
	 * @param array<string,mixed>|null $option Opção escolhida, quando já há uma.
	 * @param int|null $delay Segundos até a primeira tentativa (null = padrão).
	 */
	public function enqueue( Lead $lead, ?array $option = null, ?int $delay = null ): string {
		$active  = $this->integrations_for( $option );
		$seconds = null === $delay ? 90 : $delay;
		foreach ( $active as $integration ) {
			$this->log->enqueue( $lead->id, $integration->id(), $seconds );
		}
		$external = array_filter( $active, static fn( IntegrationInterface $i ) => ! $i->is_internal() );
		return $external ? SyncLogRepository::PENDING : 'none';
	}

	/**
	 * Integrações ativas que devem receber este lead, respeitando a opção escolhida.
	 *
	 * @param array<string,mixed>|null $option
	 * @return array<string,IntegrationInterface>
	 */
	private function integrations_for( ?array $option ): array {
		$active  = IntegrationRegistry::active();
		$allowed = OptionsMenu::allowed_integrations( $option );
		if ( null === $allowed ) {
			return $active;
		}
		return array_filter(
			$active,
			static fn( IntegrationInterface $i ) => $i->is_internal() || in_array( $i->id(), $allowed, true )
		);
	}

	/**
	 * Aplica a opção escolhida depois que o lead já existe (menu depois do formulário):
	 * descarta o que a opção não autoriza e antecipa o que ela autoriza.
	 *
	 * @param array<string,mixed>|null $option
	 */
	public function apply_option( Lead $lead, ?array $option ): void {
		$allowed = OptionsMenu::allowed_integrations( $option );
		$keep    = array_keys( $this->integrations_for( $option ) );
		foreach ( $this->log->for_lead( $lead->id ) as $row ) {
			if ( SyncLogRepository::PENDING !== $row['status'] ) {
				continue;
			}
			$id = (string) $row['integration'];
			if ( null !== $allowed && ! in_array( $id, $keep, true ) ) {
				$this->log->update( (int) $row['id'], [ 'status' => SyncLogRepository::SKIPPED, 'last_error' => 'option_excluded', 'locked_at' => null ] );
				continue;
			}
			// Autorizada: pode ir agora, com a escolha já gravada no lead.
			$this->log->update( (int) $row['id'], [ 'next_attempt_at' => gmdate( 'Y-m-d H:i:s' ) ] );
		}
		// Integração que não existia na fila (ativada depois) entra agora.
		foreach ( $this->integrations_for( $option ) as $integration ) {
			$this->log->enqueue( $lead->id, $integration->id(), 0 );
		}
		$this->refresh_lead_status( $lead->id );
	}

	/**
	 * Com lead_id: todas as pending do lead (caminho rápido). Sem: só vencidas (sweeper).
	 *
	 * @return int Linhas processadas.
	 */
	public function process( ?int $lead_id = null, int $limit = 10, ?float $deadline = null ): int {
		$deadline  = $deadline ?? microtime( true ) + self::BUDGET_SECONDS;
		$processed = 0;
		foreach ( $this->log->pending( $lead_id, $limit ) as $row ) {
			if ( microtime( true ) >= $deadline - 1 ) {
				break;
			}
			if ( $this->process_row( $row, $deadline ) ) {
				++$processed;
			}
		}
		return $processed;
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function process_row( array $row, float $deadline ): bool {
		$id          = (int) $row['id'];
		$integration = IntegrationRegistry::get( (string) $row['integration'] );

		// Sem HTTP: integração sumiu, desligada, não configurada ou com auth_failed.
		$skip = null;
		if ( ! $integration ) {
			$skip = 'missing';
		} elseif ( ! $integration->is_enabled() ) {
			$skip = 'disabled';
		} elseif ( ! $integration->is_configured() ) {
			$skip = 'unconfigured';
		} elseif ( $integration instanceof AbstractIntegration && $integration->auth_failed() ) {
			$skip = 'auth_failed';
		}
		if ( $skip ) {
			$this->log->update( $id, [ 'status' => SyncLogRepository::SKIPPED, 'last_error' => $skip, 'locked_at' => null ] );
			$this->refresh_lead_status( (int) $row['lead_id'] );
			return true;
		}

		if ( ! $this->log->claim( $id ) ) {
			return false;
		}

		$lead = $this->leads->find( (int) $row['lead_id'] );
		if ( ! $lead ) {
			$this->log->update( $id, [ 'status' => SyncLogRepository::ERROR, 'last_error' => 'lead_missing', 'locked_at' => null ] );
			return true;
		}

		$attempt = (int) $row['attempts'] + 1;
		$state   = array_filter(
			[
				'step'               => $row['step'],
				'external_person_id' => $row['external_person_id'],
				'external_id'        => $row['external_id'],
			],
			static fn( $v ) => null !== $v && '' !== $v
		);
			$ctx     = new SyncContext( $id, $attempt, $state, $deadline, fn( array $s ) => $this->log->save_state( $id, $s ) );

			do_action( 'whatsalp_before_push_lead', $lead, $integration, $ctx );
			try {
				$result = $integration->push_lead( $lead, $ctx );
			} catch ( \Throwable $e ) {
				Logger::error( 'push_lead exception', [ 'integration' => $integration->id(), 'lead' => $lead->id, 'error' => $e->getMessage() ] );
				$result = PushResult::retry( 'exception', substr( $e->getMessage(), 0, 500 ) );
			}
			do_action( 'whatsalp_after_push_lead', $lead, $integration, $result );

			$this->apply_result( $id, $row, $attempt, $integration, $result );
			$this->refresh_lead_status( $lead->id );
			return true;
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function apply_result( int $id, array $row, int $attempt, IntegrationInterface $integration, PushResult $result ): void {
		$excerpt = null === $result->response_excerpt ? null : Logger::mask( mb_substr( $result->response_excerpt, 0, 1000 ) );
		$state   = $result->state;
		$base    = [
			'locked_at'        => null,
			'response_excerpt' => $excerpt,
		];
		if ( isset( $state['step'] ) ) {
			$base['step'] = (string) $state['step'];
		}
		if ( isset( $state['external_person_id'] ) ) {
			$base['external_person_id'] = (string) $state['external_person_id'];
		}

		if ( $result->ok ) {
			$this->log->update(
				$id,
				$base + [
					'status'      => SyncLogRepository::SUCCESS,
					'external_id' => $result->external_id ?? $row['external_id'],
					'last_error'  => $state['warning'] ?? null,
					'attempts'    => $attempt,
				]
			);
			Logger::info( 'push ok', [ 'integration' => $integration->id(), 'log' => $id ] );
			return;
		}

		if ( $result->retryable ) {
			if ( $result->is_rate_limited() ) {
				$rate_limited = (int) $row['rate_limited'] + 1;
				if ( $rate_limited >= self::MAX_429 ) {
					$this->log->update( $id, $base + [ 'status' => SyncLogRepository::ERROR, 'last_error' => 'rate_limited', 'rate_limited' => $rate_limited ] );
					return;
				}
				$delay = $result->retry_after ?? 60;
				$this->log->update(
					$id,
					$base + [
						'status'          => SyncLogRepository::PENDING,
						'rate_limited'    => $rate_limited,
						'next_attempt_at' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
						'last_error'      => '429',
					]
				);
				return;
			}
			if ( 'budget' === $result->error_code ) {
				// Estourou o orçamento: retoma no próximo gatilho, sem contar tentativa.
				$this->log->update( $id, $base + [ 'status' => SyncLogRepository::PENDING, 'next_attempt_at' => gmdate( 'Y-m-d H:i:s' ) ] );
				return;
			}
			if ( $attempt >= self::MAX_ATTEMPTS ) {
				$this->log->update( $id, $base + [ 'status' => SyncLogRepository::ERROR, 'last_error' => $result->error_code, 'attempts' => $attempt ] );
				return;
			}
			$delay = $result->retry_after ?? self::BACKOFF[ min( $attempt - 1, count( self::BACKOFF ) - 1 ) ];
			$this->log->update(
				$id,
				$base + [
					'status'          => SyncLogRepository::PENDING,
					'attempts'        => $attempt,
					'next_attempt_at' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
					'last_error'      => $result->error_code,
				]
			);
			return;
		}

		$this->log->update( $id, $base + [ 'status' => SyncLogRepository::ERROR, 'last_error' => $result->error_code, 'attempts' => $attempt ] );
		if ( $result->auth_failed && $integration instanceof AbstractIntegration ) {
			$integration->set_auth_failed( true );
			do_action( 'whatsalp_integration_auth_failed', $integration );
			Logger::error( 'auth failed', [ 'integration' => $integration->id() ] );
		}
	}

	/**
	 * Recalcula sync_status do lead ignorando skipped e integrações internas.
	 */
	public function refresh_lead_status( int $lead_id ): void {
		$statuses = [];
		foreach ( $this->log->for_lead( $lead_id ) as $row ) {
			$integration = IntegrationRegistry::get( (string) $row['integration'] );
			if ( $integration && $integration->is_internal() ) {
				continue;
			}
			if ( SyncLogRepository::SKIPPED === $row['status'] ) {
				continue;
			}
			$statuses[] = $row['status'];
		}
		if ( ! $statuses ) {
			$status = 'none';
		} elseif ( in_array( SyncLogRepository::ERROR, $statuses, true ) ) {
			$status = SyncLogRepository::ERROR;
		} elseif ( count( array_unique( $statuses ) ) === 1 && SyncLogRepository::SUCCESS === $statuses[0] ) {
			$status = SyncLogRepository::SUCCESS;
		} else {
			$status = SyncLogRepository::PENDING;
		}
		$this->leads->update( $lead_id, [ 'sync_status' => $status ] );
	}

	/**
	 * "Reenviar": só error/skipped; mantém step/external_* para retomar.
	 */
	public function resend( int $log_id ): bool {
		$row = $this->log->find( $log_id );
		if ( ! $row || ! in_array( $row['status'], [ SyncLogRepository::ERROR, SyncLogRepository::SKIPPED ], true ) ) {
			return false;
		}
		$this->log->update(
			$log_id,
			[
				'status'          => SyncLogRepository::PENDING,
				'attempts'        => 0,
				'rate_limited'    => 0,
				'last_error'      => null,
				'locked_at'       => null,
				'next_attempt_at' => gmdate( 'Y-m-d H:i:s' ),
			]
		);
		$this->refresh_lead_status( (int) $row['lead_id'] );
		return true;
	}

	/**
	 * "Enviar novamente como novo": zera o estado e cria outro item no CRM.
	 */
	public function resend_as_new( int $log_id ): bool {
		$row = $this->log->find( $log_id );
		if ( ! $row ) {
			return false;
		}
		$this->log->update(
			$log_id,
			[
				'status'             => SyncLogRepository::PENDING,
				'attempts'           => 0,
				'rate_limited'       => 0,
				'step'               => null,
				'external_id'        => null,
				'last_error'         => null,
				'locked_at'          => null,
				'next_attempt_at'    => gmdate( 'Y-m-d H:i:s' ),
			]
		);
		$this->refresh_lead_status( (int) $row['lead_id'] );
		return true;
	}

	/**
	 * Garante linhas para integrações ativadas depois do lead (ação em massa "reenviar").
	 */
	public function enqueue_missing( int $lead_id ): void {
		$lead   = $this->leads->find( $lead_id );
		$option = $lead ? OptionsMenu::for_lead( $lead ) : null;
		foreach ( $this->integrations_for( $option ) as $integration ) {
			$this->log->enqueue( $lead_id, $integration->id(), 0 );
		}
	}
}
