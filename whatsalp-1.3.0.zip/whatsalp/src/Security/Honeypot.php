<?php
declare(strict_types=1);

namespace WhatsAlp\Security;

final class Honeypot {

	/** Nome não autofillável pelo navegador. */
	public const FIELD = 'website_url';

	/**
	 * @param array<string,mixed> $input
	 */
	public static function triggered( array $input ): bool {
		return isset( $input[ self::FIELD ] ) && '' !== trim( (string) $input[ self::FIELD ] );
	}
}
