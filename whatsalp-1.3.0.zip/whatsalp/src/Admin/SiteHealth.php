<?php
declare(strict_types=1);

namespace WhatsAlp\Admin;

use WhatsAlp\Http\OriginCheck;
use WhatsAlp\Integrations\AbstractIntegration;
use WhatsAlp\Integrations\IntegrationRegistry;

final class SiteHealth {

	public function register(): void {
		add_filter( 'site_status_tests', [ $this, 'tests' ] );
	}

	/**
	 * @param array<string, array<string, array<string,mixed>>> $tests
	 * @return array<string, array<string, array<string,mixed>>>
	 */
	public function tests( array $tests ): array {
		$tests['direct']['whatsalp_endpoint'] = [ 'label' => 'WhatsAlp: endpoint público', 'test' => [ $this, 'endpoint' ] ];
		$tests['direct']['whatsalp_sweeper']  = [ 'label' => 'WhatsAlp: processamento de leads', 'test' => [ $this, 'sweeper' ] ];
		$tests['direct']['whatsalp_secrets']  = [ 'label' => 'WhatsAlp: segredos das integrações', 'test' => [ $this, 'secrets' ] ];
		$tests['direct']['whatsalp_origin']   = [ 'label' => 'WhatsAlp: bloqueios por Origin', 'test' => [ $this, 'origin' ] ];
		return $tests;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function result( string $slug, string $label, string $status, string $description ): array {
		return [
			'label'       => $label,
			'status'      => $status,
			'badge'       => [ 'label' => 'WhatsAlp', 'color' => 'good' === $status ? 'green' : ( 'critical' === $status ? 'red' : 'orange' ) ],
			'description' => '<p>' . esc_html( $description ) . '</p>',
			'actions'     => '',
			'test'        => $slug,
		];
	}

	/**
	 * @return array<string,mixed>
	 */
	public function endpoint(): array {
		// Sonda com telefone inválido: 400 whatsalp_* conta como acessível e não entra no rate limit.
		$res = wp_remote_post(
			rest_url( 'whatsalp/v1/leads' ),
			[
				'timeout'   => 8,
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				'headers'   => [ 'Content-Type' => 'application/json', 'Origin' => home_url() ],
				'body'      => wp_json_encode( [ 'phone' => '0', 'form_token' => 'probe' ] ),
			]
		);
		$label = __( 'O endpoint público do WhatsAlp está acessível', 'whatsalp' );
		if ( is_wp_error( $res ) ) {
			// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
			return $this->result( 'whatsalp_endpoint', $label, 'recommended', sprintf( __( 'O servidor não conseguiu chamar a si mesmo (%s). Isso pode ser só uma limitação de loopback do host; os visitantes não são afetados necessariamente. Teste o formulário no site.', 'whatsalp' ), $res->get_error_message() ) );
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$code = is_array( $body ) ? (string) ( $body['code'] ?? '' ) : '';
		if ( str_starts_with( $code, 'whatsalp_' ) ) {
			return $this->result( 'whatsalp_endpoint', $label, 'good', __( 'O endpoint REST responde normalmente para visitantes.', 'whatsalp' ) );
		}
		// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
		return $this->result( 'whatsalp_endpoint', __( 'O endpoint REST do WhatsAlp parece bloqueado', 'whatsalp' ), 'recommended', sprintf( __( 'Resposta HTTP %d sem o formato esperado. Algum plugin de segurança pode estar bloqueando a REST API para visitantes. O widget usa o fallback por admin-ajax automaticamente, mas confira o formulário no site.', 'whatsalp' ), (int) wp_remote_retrieve_response_code( $res ) ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function sweeper(): array {
		$last  = (int) get_option( 'whatsalp_last_sweep', 0 );
		// Nunca rodou: só é problema se o plugin está instalado há mais de 24 h.
		$since = $last ?: (int) get_option( 'whatsalp_installed_at', time() );
		$age   = time() - $since;
		$label = __( 'O processamento de leads do WhatsAlp está em dia', 'whatsalp' );
		$cron  = defined( 'DISABLE_WP_CRON' ) && constant( 'DISABLE_WP_CRON' ) ? ' ' . __( 'DISABLE_WP_CRON está ativo: confirme que há um cron de sistema chamando wp-cron.php.', 'whatsalp' ) : '';
		if ( $age > DAY_IN_SECONDS ) {
			return $this->result( 'whatsalp_sweeper', __( 'O processamento de leads do WhatsAlp não roda há mais de 24 horas', 'whatsalp' ), 'critical', __( 'Leads que falharam no primeiro envio ao CRM não estão sendo reprocessados.', 'whatsalp' ) . $cron );
		}
		if ( $age > HOUR_IN_SECONDS ) {
			// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
			return $this->result( 'whatsalp_sweeper', __( 'O processamento de leads do WhatsAlp está atrasado', 'whatsalp' ), 'recommended', sprintf( __( 'Última execução há %s. O esperado é a cada 5 minutos.', 'whatsalp' ), human_time_diff( $last ) ) . $cron );
		}
		// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
		return $this->result( 'whatsalp_sweeper', $label, 'good', sprintf( __( 'Última execução há %s.', 'whatsalp' ), $last ? human_time_diff( $last ) : '—' ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function secrets(): array {
		foreach ( IntegrationRegistry::all() as $integration ) {
			if ( ! $integration instanceof AbstractIntegration ) {
				continue;
			}
			foreach ( $integration->settings_schema() as $key => $field ) {
				if ( ! empty( $field['secret'] ) && $integration->secret_unreadable( $key ) ) {
					// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
					return $this->result( 'whatsalp_secrets', __( 'Um segredo de integração do WhatsAlp não pôde ser decifrado', 'whatsalp' ), 'critical', sprintf( __( 'As chaves de segurança do site mudaram e o token de %s precisa ser inserido de novo em WhatsAlp › Integrações.', 'whatsalp' ), $integration->label() ) );
				}
			}
		}
		return $this->result( 'whatsalp_secrets', __( 'Os segredos das integrações do WhatsAlp estão legíveis', 'whatsalp' ), 'good', __( 'Tokens cifrados e decifráveis com as chaves atuais.', 'whatsalp' ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function origin(): array {
		$blocks = OriginCheck::blocks_last_24h();
		if ( $blocks > 0 ) {
			$mode = OriginCheck::enforcing() ? __( 'bloqueados', 'whatsalp' ) : __( 'apenas contados (período de observação)', 'whatsalp' );
			// translators: %s/%d = detalhe do teste (tempo decorrido, código HTTP, nome da integração ou quantidade).
			return $this->result( 'whatsalp_origin', __( 'Envios ao WhatsAlp sem Origin válido nas últimas 24 horas', 'whatsalp' ), 'recommended', sprintf( __( '%1$d envios %2$s. Se o site é acessado por mais de um domínio, adicione-os pelo filtro whatsalp_allowed_origins.', 'whatsalp' ), $blocks, $mode ) );
		}
		return $this->result( 'whatsalp_origin', __( 'Nenhum envio ao WhatsAlp bloqueado por Origin', 'whatsalp' ), 'good', '' );
	}
}
